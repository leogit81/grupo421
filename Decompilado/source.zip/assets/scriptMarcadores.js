function addMarkers(map) {
}