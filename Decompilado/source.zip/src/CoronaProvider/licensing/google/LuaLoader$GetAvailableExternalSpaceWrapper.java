// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;
import java.io.File;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

public class this._cls0
    implements NamedJavaFunction
{

    final LuaLoader this$0;

    public String getName()
    {
        return "getAvailableExternalSpace";
    }

    public int invoke(LuaState luastate)
    {
        double d1;
        int i;
        StatFs statfs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
        d1 = statfs.getBlockSize();
        i = statfs.getAvailableBlocks();
        double d = d1 * (double)i;
_L2:
        luastate.pushNumber(d);
        return 1;
        Exception exception;
        exception;
        Log.w("Corona", (new StringBuilder()).append("Could not retrieve the available free space for: ").append(Environment.getExternalStorageDirectory().getAbsolutePath()).toString());
        d = 1.7976931348623157E+308D;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public ()
    {
        this$0 = LuaLoader.this;
        super();
    }
}
