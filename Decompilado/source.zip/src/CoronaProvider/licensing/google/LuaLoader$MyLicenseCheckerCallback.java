// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import com.google.android.vending.licensing.LicenseCheckerCallback;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

private class <init>
    implements LicenseCheckerCallback
{

    final LuaLoader this$0;

    private String translateResponse(int i)
    {
        switch (i)
        {
        default:
            return "";

        case 5: // '\005'
            return "Invalid public key";

        case 6: // '\006'
            return "Missing permission";

        case 1: // '\001'
            return "Invalid package name";

        case 2: // '\002'
            return "Non matching UID";

        case 3: // '\003'
            return "Not market managed";

        case 291: 
            return "Error contacting server";

        case 256: 
            return "Licensed";

        case 561: 
            return "Not licensed";
        }
    }

    public void allow(int i)
    {
        LuaLoader.setLastCheckedAppVersion();
        LuaLoader.access$700(LuaLoader.this, true, translateResponse(i), false, "");
    }

    public void applicationError(int i)
    {
        LuaLoader.access$700(LuaLoader.this, false, translateResponse(i), true, "configuration");
    }

    public void dontAllow(int i)
    {
        boolean flag;
        String s;
        if (291 == i)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            s = "network";
        } else
        {
            s = "";
        }
        LuaLoader.access$700(LuaLoader.this, false, translateResponse(i), flag, s);
    }

    private ()
    {
        this$0 = LuaLoader.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
