// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

private class <init>
    implements NamedJavaFunction
{

    final LuaLoader this$0;

    public String getName()
    {
        return "init";
    }

    public int invoke(LuaState luastate)
    {
        return init(luastate);
    }

    private ()
    {
        this$0 = LuaLoader.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
