// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import com.google.android.vending.licensing.Policy;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

public class this._cls0
    implements NamedJavaFunction
{

    final LuaLoader this$0;

    public String getName()
    {
        return "getFileNamesFromPreferences";
    }

    public int invoke(LuaState luastate)
    {
        luastate.newTable(LuaLoader.access$500(LuaLoader.this).getExpansionFileNameCount(), 0);
        int i = luastate.getTop();
        for (int j = 0; j < LuaLoader.access$500(LuaLoader.this).getExpansionFileNameCount(); j++)
        {
            luastate.pushString(LuaLoader.access$500(LuaLoader.this).getExpansionFileName(j));
            luastate.rawSet(i, j + 1);
        }

        return 1;
    }

    public ()
    {
        this$0 = LuaLoader.this;
        super();
    }
}
