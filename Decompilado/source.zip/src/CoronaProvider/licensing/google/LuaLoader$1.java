// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.google.android.vending.licensing.Policy;
import com.naef.jnlua.LuaState;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

class val.response
    implements CoronaRuntimeTask
{

    final LuaLoader this$0;
    final String val$errorType;
    final boolean val$isError;
    final boolean val$isVerified;
    final String val$response;

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        LuaState luastate;
        luastate = coronaruntime.getLuaState();
        CoronaLua.newEvent(luastate, "licensing");
        luastate.pushBoolean(val$isVerified);
        luastate.setField(-2, "isVerified");
        if (!val$isError) goto _L2; else goto _L1
_L1:
        luastate.pushBoolean(val$isError);
_L5:
        luastate.setField(-2, "isError");
        if (!val$isError) goto _L4; else goto _L3
_L3:
        luastate.pushString(val$errorType);
_L6:
        luastate.setField(-2, "errorType");
        luastate.pushString(val$response);
        luastate.setField(-2, "response");
        luastate.pushString("google");
        luastate.setField(-2, "provider");
        luastate.pushNumber(LuaLoader.access$500(LuaLoader.this).getValidityTimestamp());
        luastate.setField(-2, "expiration");
        luastate.newTable(LuaLoader.access$500(LuaLoader.this).getExpansionURLCount(), 0);
        int i = 0;
        do
        {
            try
            {
                if (i >= LuaLoader.access$500(LuaLoader.this).getExpansionURLCount())
                {
                    break;
                }
                luastate.newTable(0, 3);
                luastate.pushString(LuaLoader.access$500(LuaLoader.this).getExpansionURL(i));
                luastate.setField(-2, "url");
                luastate.pushString(LuaLoader.access$500(LuaLoader.this).getExpansionFileName(i));
                luastate.setField(-2, "fileName");
                luastate.pushNumber(LuaLoader.access$500(LuaLoader.this).getExpansionFileSize(i));
                luastate.setField(-2, "fileSize");
                luastate.setField(-2, Integer.toString(i + 1));
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
                return;
            }
            i++;
        } while (true);
        break MISSING_BLOCK_LABEL_277;
_L2:
        luastate.pushNil();
          goto _L5
_L4:
        luastate.pushNil();
          goto _L6
        luastate.setField(-2, "expansionFiles");
        CoronaLua.dispatchEvent(luastate, LuaLoader.access$600(LuaLoader.this), 0);
        return;
          goto _L5
    }

    ()
    {
        this$0 = final_lualoader;
        val$isVerified = flag;
        val$isError = flag1;
        val$errorType = s;
        val$response = String.this;
        super();
    }
}
