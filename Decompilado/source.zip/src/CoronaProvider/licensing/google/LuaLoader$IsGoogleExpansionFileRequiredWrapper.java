// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.purchasing.StoreServices;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;

// Referenced classes of package CoronaProvider.licensing.google:
//            LuaLoader

private class <init>
    implements NamedJavaFunction
{

    final LuaLoader this$0;

    public String getName()
    {
        return "isGoogleExpansionFileRequired";
    }

    public int invoke(LuaState luastate)
    {
        boolean flag2;
        String s = StoreServices.getTargetedAppStoreName();
        if ("google".equals(s))
        {
            break MISSING_BLOCK_LABEL_32;
        }
        flag2 = "none".equals(s);
        boolean flag;
        flag = false;
        if (!flag2)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        ApplicationInfo applicationinfo;
        Context context = CoronaEnvironment.getApplicationContext();
        applicationinfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
        flag = false;
        if (applicationinfo == null)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        Bundle bundle = applicationinfo.metaData;
        flag = false;
        if (bundle == null)
        {
            break MISSING_BLOCK_LABEL_95;
        }
        boolean flag1 = applicationinfo.metaData.getBoolean("usesExpansionFile", false);
        flag = flag1;
_L2:
        luastate.pushBoolean(flag);
        return 1;
        Exception exception;
        exception;
        Log.e("Corona", "isGoogleExpansionFileRequired", exception);
        flag = false;
        if (true) goto _L2; else goto _L1
_L1:
    }

    private ()
    {
        this$0 = LuaLoader.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
