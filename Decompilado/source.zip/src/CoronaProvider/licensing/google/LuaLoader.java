// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package CoronaProvider.licensing.google;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.ansca.corona.purchasing.StoreServices;
import com.ansca.corona.storage.FileServices;
import com.google.android.vending.licensing.AESObfuscator;
import com.google.android.vending.licensing.APKExpansionPolicy;
import com.google.android.vending.licensing.LicenseChecker;
import com.google.android.vending.licensing.LicenseCheckerCallback;
import com.google.android.vending.licensing.Policy;
import com.google.android.vending.licensing.StrictPolicy;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;
import java.io.File;
import java.util.Random;

public class LuaLoader
    implements JavaFunction
{
    public class GetAvailableExternalSpaceWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "getAvailableExternalSpace";
        }

        public int invoke(LuaState luastate)
        {
            double d1;
            int i;
            StatFs statfs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
            d1 = statfs.getBlockSize();
            i = statfs.getAvailableBlocks();
            double d = d1 * (double)i;
_L2:
            luastate.pushNumber(d);
            return 1;
            Exception exception;
            exception;
            Log.w("Corona", (new StringBuilder()).append("Could not retrieve the available free space for: ").append(Environment.getExternalStorageDirectory().getAbsolutePath()).toString());
            d = 1.7976931348623157E+308D;
            if (true) goto _L2; else goto _L1
_L1:
        }

        public GetAvailableExternalSpaceWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }
    }

    private class GetExternalStorageStateWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "getExternalStorageState";
        }

        public int invoke(LuaState luastate)
        {
            luastate.pushString(Environment.getExternalStorageState());
            return 1;
        }

        private GetExternalStorageStateWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }

    }

    public class GetFileNamesFromPreferencesWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "getFileNamesFromPreferences";
        }

        public int invoke(LuaState luastate)
        {
            luastate.newTable(licenseCheckPolicy.getExpansionFileNameCount(), 0);
            int i = luastate.getTop();
            for (int j = 0; j < licenseCheckPolicy.getExpansionFileNameCount(); j++)
            {
                luastate.pushString(licenseCheckPolicy.getExpansionFileName(j));
                luastate.rawSet(i, j + 1);
            }

            return 1;
        }

        public GetFileNamesFromPreferencesWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }
    }

    private class InitWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "init";
        }

        public int invoke(LuaState luastate)
        {
            return init(luastate);
        }

        private InitWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }

    }

    private class IsGoogleExpansionFileRequiredWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "isGoogleExpansionFileRequired";
        }

        public int invoke(LuaState luastate)
        {
            boolean flag2;
            String s = StoreServices.getTargetedAppStoreName();
            if ("google".equals(s))
            {
                break MISSING_BLOCK_LABEL_32;
            }
            flag2 = "none".equals(s);
            boolean flag;
            flag = false;
            if (!flag2)
            {
                break MISSING_BLOCK_LABEL_95;
            }
            ApplicationInfo applicationinfo;
            Context context = CoronaEnvironment.getApplicationContext();
            applicationinfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            flag = false;
            if (applicationinfo == null)
            {
                break MISSING_BLOCK_LABEL_95;
            }
            Bundle bundle = applicationinfo.metaData;
            flag = false;
            if (bundle == null)
            {
                break MISSING_BLOCK_LABEL_95;
            }
            boolean flag1 = applicationinfo.metaData.getBoolean("usesExpansionFile", false);
            flag = flag1;
_L2:
            luastate.pushBoolean(flag);
            return 1;
            Exception exception;
            exception;
            Log.e("Corona", "isGoogleExpansionFileRequired", exception);
            flag = false;
            if (true) goto _L2; else goto _L1
_L1:
        }

        private IsGoogleExpansionFileRequiredWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }

    }

    public class IsNewAppVersionWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "isNewAppVersion";
        }

        public int invoke(LuaState luastate)
        {
            luastate.pushBoolean(LuaLoader.isNewAppVersion());
            return 1;
        }

        public IsNewAppVersionWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }
    }

    public class LoadExpansionFilesWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "loadExpansionFiles";
        }

        public int invoke(LuaState luastate)
        {
            setExpansionFileNames();
            return 0;
        }

        public LoadExpansionFilesWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }
    }

    private class MyLicenseCheckerCallback
        implements LicenseCheckerCallback
    {

        final LuaLoader this$0;

        private String translateResponse(int i)
        {
            switch (i)
            {
            default:
                return "";

            case 5: // '\005'
                return "Invalid public key";

            case 6: // '\006'
                return "Missing permission";

            case 1: // '\001'
                return "Invalid package name";

            case 2: // '\002'
                return "Non matching UID";

            case 3: // '\003'
                return "Not market managed";

            case 291: 
                return "Error contacting server";

            case 256: 
                return "Licensed";

            case 561: 
                return "Not licensed";
            }
        }

        public void allow(int i)
        {
            LuaLoader.setLastCheckedAppVersion();
            callLuaCallback(true, translateResponse(i), false, "");
        }

        public void applicationError(int i)
        {
            callLuaCallback(false, translateResponse(i), true, "configuration");
        }

        public void dontAllow(int i)
        {
            boolean flag;
            String s;
            if (291 == i)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                s = "network";
            } else
            {
                s = "";
            }
            callLuaCallback(false, translateResponse(i), flag, s);
        }

        private MyLicenseCheckerCallback()
        {
            this$0 = LuaLoader.this;
            super();
        }

    }

    private class VerifyWrapper
        implements NamedJavaFunction
    {

        final LuaLoader this$0;

        public String getName()
        {
            return "verify";
        }

        public int invoke(LuaState luastate)
        {
            return verify(luastate);
        }

        private VerifyWrapper()
        {
            this$0 = LuaLoader.this;
            super();
        }

    }


    private static final String LAST_VERSION_CHECKED = "LAST_VERSION_CHECKED";
    public static final String PREFS_FILE = "CoronaProvider.licensing.google.lualoader";
    private static byte SALT[];
    private static final String SALT_STRING = "salt";
    private CoronaRuntimeTaskDispatcher fDispatcher;
    private int fListener;
    private Policy licenseCheckPolicy;
    private String licenseKey;
    private LicenseChecker mChecker;
    private LicenseCheckerCallback mLicenseCheckerCallback;

    public LuaLoader()
    {
        initialize();
    }

    private void callLuaCallback(final boolean isVerified, final String response, final boolean isError, final String errorType)
    {
        fDispatcher.send(new CoronaRuntimeTask() {

            final LuaLoader this$0;
            final String val$errorType;
            final boolean val$isError;
            final boolean val$isVerified;
            final String val$response;

            public void executeUsing(CoronaRuntime coronaruntime)
            {
                LuaState luastate;
                luastate = coronaruntime.getLuaState();
                CoronaLua.newEvent(luastate, "licensing");
                luastate.pushBoolean(isVerified);
                luastate.setField(-2, "isVerified");
                if (!isError) goto _L2; else goto _L1
_L1:
                luastate.pushBoolean(isError);
_L5:
                luastate.setField(-2, "isError");
                if (!isError) goto _L4; else goto _L3
_L3:
                luastate.pushString(errorType);
_L6:
                luastate.setField(-2, "errorType");
                luastate.pushString(response);
                luastate.setField(-2, "response");
                luastate.pushString("google");
                luastate.setField(-2, "provider");
                luastate.pushNumber(licenseCheckPolicy.getValidityTimestamp());
                luastate.setField(-2, "expiration");
                luastate.newTable(licenseCheckPolicy.getExpansionURLCount(), 0);
                int i = 0;
                do
                {
                    try
                    {
                        if (i >= licenseCheckPolicy.getExpansionURLCount())
                        {
                            break;
                        }
                        luastate.newTable(0, 3);
                        luastate.pushString(licenseCheckPolicy.getExpansionURL(i));
                        luastate.setField(-2, "url");
                        luastate.pushString(licenseCheckPolicy.getExpansionFileName(i));
                        luastate.setField(-2, "fileName");
                        luastate.pushNumber(licenseCheckPolicy.getExpansionFileSize(i));
                        luastate.setField(-2, "fileSize");
                        luastate.setField(-2, Integer.toString(i + 1));
                    }
                    catch (Exception exception)
                    {
                        exception.printStackTrace();
                        return;
                    }
                    i++;
                } while (true);
                break MISSING_BLOCK_LABEL_277;
_L2:
                luastate.pushNil();
                  goto _L5
_L4:
                luastate.pushNil();
                  goto _L6
                luastate.setField(-2, "expansionFiles");
                CoronaLua.dispatchEvent(luastate, fListener, 0);
                return;
                  goto _L5
            }

            
            {
                this$0 = LuaLoader.this;
                isVerified = flag;
                isError = flag1;
                errorType = s;
                response = s1;
                super();
            }
        });
    }

    private boolean initLicenseChecker(String s, String s1)
    {
        mLicenseCheckerCallback = new MyLicenseCheckerCallback();
        String s2 = android.provider.Settings.Secure.getString(CoronaEnvironment.getApplicationContext().getContentResolver(), "android_id");
        String s3 = CoronaEnvironment.getApplicationContext().getPackageName();
        AESObfuscator aesobfuscator = new AESObfuscator(SALT, s3, s2);
        if (s1.equals("strict"))
        {
            licenseCheckPolicy = new StrictPolicy();
        } else
        {
            licenseCheckPolicy = new APKExpansionPolicy(CoronaEnvironment.getApplicationContext(), aesobfuscator);
        }
        try
        {
            mChecker = new LicenseChecker(CoronaEnvironment.getApplicationContext(), licenseCheckPolicy, s);
        }
        catch (IllegalArgumentException illegalargumentexception)
        {
            Log.e("Corona", "Invalid public key", illegalargumentexception);
            return false;
        }
        return true;
    }

    public static boolean isNewAppVersion()
    {
        Context context = CoronaEnvironment.getApplicationContext();
        int i = context.getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0).getInt("LAST_VERSION_CHECKED", 0);
        int j;
        boolean flag;
        try
        {
            j = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        }
        catch (Exception exception)
        {
            j = 0;
        }
        flag = false;
        if (j > i)
        {
            flag = true;
        }
        return flag;
    }

    private void setExpansionFileNames()
    {
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null)
        {
            FileServices fileservices = new FileServices(context);
            int i = 0;
            while (i < licenseCheckPolicy.getExpansionFileNameCount()) 
            {
                String s = licenseCheckPolicy.getExpansionFileName(i);
                if (s != null)
                {
                    if (s.startsWith("main"))
                    {
                        fileservices.setMainExpansionFileName(s);
                    } else
                    if (s.startsWith("patch"))
                    {
                        fileservices.setPatchExpansionFileName(s);
                    }
                }
                i++;
            }
            fileservices.loadExpansionFiles();
        }
    }

    public static void setLastCheckedAppVersion()
    {
        Context context = CoronaEnvironment.getApplicationContext();
        android.content.SharedPreferences.Editor editor = context.getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0).edit();
        int i;
        try
        {
            i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        }
        catch (Exception exception)
        {
            i = 0;
        }
        editor.putInt("LAST_VERSION_CHECKED", i);
        editor.commit();
    }

    public int init(LuaState luastate)
    {
        int i = luastate.getTop();
        String s = "";
        String s1 = "";
        luastate.getGlobal("require");
        luastate.pushString("config");
        luastate.call(1, -1);
        luastate.getGlobal("application");
        if (luastate.isTable(-1))
        {
            luastate.getField(-1, "license");
            if (luastate.isTable(-1))
            {
                luastate.getField(-1, "google");
                if (luastate.isTable(-1))
                {
                    luastate.getField(-1, "key");
                    if (luastate.isString(-1))
                    {
                        s = luastate.toString(-1);
                    }
                    luastate.getField(-2, "policy");
                    if (luastate.isString(-1))
                    {
                        s1 = luastate.toString(-1);
                    }
                }
            }
        }
        boolean flag;
        if (!s.equals("") && (StoreServices.getTargetedAppStoreName().equals("google") || StoreServices.getTargetedAppStoreName().equals("none")))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            flag = initLicenseChecker(s, s1);
        }
        luastate.setTop(i);
        luastate.pushBoolean(flag);
        return 1;
    }

    protected void initialize()
    {
        SharedPreferences sharedpreferences = CoronaEnvironment.getApplicationContext().getSharedPreferences("CoronaProvider.licensing.google.lualoader", 0);
        String s = sharedpreferences.getString("salt", null);
        if (s == null)
        {
            SALT = new byte[20];
            (new Random()).nextBytes(SALT);
            s = new String(SALT);
            android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString("salt", s);
            editor.commit();
        }
        SALT = s.getBytes();
    }

    public int invoke(LuaState luastate)
    {
        initialize();
        fDispatcher = new CoronaRuntimeTaskDispatcher(luastate);
        NamedJavaFunction anamedjavafunction[] = new NamedJavaFunction[8];
        anamedjavafunction[0] = new InitWrapper();
        anamedjavafunction[1] = new VerifyWrapper();
        anamedjavafunction[2] = new IsGoogleExpansionFileRequiredWrapper();
        anamedjavafunction[3] = new GetExternalStorageStateWrapper();
        anamedjavafunction[4] = new GetAvailableExternalSpaceWrapper();
        anamedjavafunction[5] = new IsNewAppVersionWrapper();
        anamedjavafunction[6] = new GetFileNamesFromPreferencesWrapper();
        anamedjavafunction[7] = new LoadExpansionFilesWrapper();
        luastate.register(luastate.toString(1), anamedjavafunction);
        return 1;
    }

    public int verify(LuaState luastate)
    {
        boolean flag1;
label0:
        {
            Context context = CoronaEnvironment.getApplicationContext();
            if (context != null)
            {
                context.enforceCallingOrSelfPermission("com.android.vending.CHECK_LICENSE", null);
            }
            if (!CoronaLua.isListener(luastate, 1, "licensing") || mChecker == null || !StoreServices.getTargetedAppStoreName().equals("google"))
            {
                boolean flag = StoreServices.getTargetedAppStoreName().equals("none");
                flag1 = false;
                if (!flag)
                {
                    break label0;
                }
            }
            fListener = CoronaLua.newRef(luastate, 1);
            boolean flag2 = luastate.isBoolean(2);
            boolean flag3 = false;
            if (flag2)
            {
                flag3 = luastate.toBoolean(2);
            }
            mChecker.checkAccess(mLicenseCheckerCallback, flag3);
            flag1 = true;
        }
        luastate.pushBoolean(flag1);
        return 1;
    }




}
