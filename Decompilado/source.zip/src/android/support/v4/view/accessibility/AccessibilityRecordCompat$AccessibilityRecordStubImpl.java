// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.os.Parcelable;
import android.view.View;
import java.util.Collections;
import java.util.List;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityRecordCompat, AccessibilityNodeInfoCompat

static class a
    implements a
{

    public int getAddedCount(Object obj)
    {
        return 0;
    }

    public CharSequence getBeforeText(Object obj)
    {
        return null;
    }

    public CharSequence getClassName(Object obj)
    {
        return null;
    }

    public CharSequence getContentDescription(Object obj)
    {
        return null;
    }

    public int getCurrentItemIndex(Object obj)
    {
        return 0;
    }

    public int getFromIndex(Object obj)
    {
        return 0;
    }

    public int getItemCount(Object obj)
    {
        return 0;
    }

    public int getMaxScrollX(Object obj)
    {
        return 0;
    }

    public int getMaxScrollY(Object obj)
    {
        return 0;
    }

    public Parcelable getParcelableData(Object obj)
    {
        return null;
    }

    public int getRemovedCount(Object obj)
    {
        return 0;
    }

    public int getScrollX(Object obj)
    {
        return 0;
    }

    public int getScrollY(Object obj)
    {
        return 0;
    }

    public AccessibilityNodeInfoCompat getSource(Object obj)
    {
        return null;
    }

    public List getText(Object obj)
    {
        return Collections.emptyList();
    }

    public int getToIndex(Object obj)
    {
        return 0;
    }

    public int getWindowId(Object obj)
    {
        return 0;
    }

    public boolean isChecked(Object obj)
    {
        return false;
    }

    public boolean isEnabled(Object obj)
    {
        return false;
    }

    public boolean isFullScreen(Object obj)
    {
        return false;
    }

    public boolean isPassword(Object obj)
    {
        return false;
    }

    public boolean isScrollable(Object obj)
    {
        return false;
    }

    public Object obtain()
    {
        return null;
    }

    public Object obtain(Object obj)
    {
        return null;
    }

    public void recycle(Object obj)
    {
    }

    public void setAddedCount(Object obj, int i)
    {
    }

    public void setBeforeText(Object obj, CharSequence charsequence)
    {
    }

    public void setChecked(Object obj, boolean flag)
    {
    }

    public void setClassName(Object obj, CharSequence charsequence)
    {
    }

    public void setContentDescription(Object obj, CharSequence charsequence)
    {
    }

    public void setCurrentItemIndex(Object obj, int i)
    {
    }

    public void setEnabled(Object obj, boolean flag)
    {
    }

    public void setFromIndex(Object obj, int i)
    {
    }

    public void setFullScreen(Object obj, boolean flag)
    {
    }

    public void setItemCount(Object obj, int i)
    {
    }

    public void setMaxScrollX(Object obj, int i)
    {
    }

    public void setMaxScrollY(Object obj, int i)
    {
    }

    public void setParcelableData(Object obj, Parcelable parcelable)
    {
    }

    public void setPassword(Object obj, boolean flag)
    {
    }

    public void setRemovedCount(Object obj, int i)
    {
    }

    public void setScrollX(Object obj, int i)
    {
    }

    public void setScrollY(Object obj, int i)
    {
    }

    public void setScrollable(Object obj, boolean flag)
    {
    }

    public void setSource(Object obj, View view)
    {
    }

    public void setSource(Object obj, View view, int i)
    {
    }

    public void setToIndex(Object obj, int i)
    {
    }

    a()
    {
    }
}
