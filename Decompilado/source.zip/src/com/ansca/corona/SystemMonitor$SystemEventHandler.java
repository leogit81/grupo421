// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

// Referenced classes of package com.ansca.corona:
//            SystemMonitor, CoronaActivity

private static class fMonitor extends BroadcastReceiver
{

    private SystemMonitor fMonitor;

    public void dispose()
    {
        fMonitor.getActivity().unregisterReceiver(this);
    }

    public void onReceive(Context context, Intent intent)
    {
        String s;
        if (intent != null)
        {
            if ((s = intent.getAction()) != null && s.length() > 0)
            {
                if (s.equals("android.intent.action.SCREEN_OFF"))
                {
                    SystemMonitor.access$002(fMonitor, false);
                    fMonitor.getActivity().onScreenLockStateChanged(true);
                    return;
                }
                if (s.equals("android.intent.action.SCREEN_ON"))
                {
                    SystemMonitor.access$002(fMonitor, true);
                    fMonitor.getActivity().onScreenLockStateChanged(fMonitor.isScreenLocked());
                    return;
                }
                if (s.equals("android.intent.action.USER_PRESENT"))
                {
                    fMonitor.getActivity().onScreenLockStateChanged(false);
                    return;
                }
                if (s.equals("android.media.RINGER_MODE_CHANGED"))
                {
                    fMonitor.isSilentModeEnabled();
                    return;
                }
            }
        }
    }

    public (SystemMonitor systemmonitor)
    {
        if (systemmonitor == null)
        {
            throw new NullPointerException();
        } else
        {
            fMonitor = systemmonitor;
            IntentFilter intentfilter = new IntentFilter();
            intentfilter.addAction("android.intent.action.SCREEN_OFF");
            intentfilter.addAction("android.intent.action.SCREEN_ON");
            intentfilter.addAction("android.intent.action.USER_PRESENT");
            intentfilter.addAction("android.media.RINGER_MODE_CHANGED");
            fMonitor.getActivity().registerReceiver(this, intentfilter);
            return;
        }
    }
}
