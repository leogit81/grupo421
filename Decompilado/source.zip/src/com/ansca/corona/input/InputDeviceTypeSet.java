// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.Iterator;
import java.util.LinkedHashSet;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceType

public class InputDeviceTypeSet
    implements Iterable, Cloneable
{

    private LinkedHashSet fCollection;

    public InputDeviceTypeSet()
    {
        fCollection = new LinkedHashSet();
    }

    public void add(InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            return;
        } else
        {
            fCollection.add(inputdevicetype);
            return;
        }
    }

    public void addAll(Iterable iterable)
    {
        if (iterable != null)
        {
            Iterator iterator1 = iterable.iterator();
            while (iterator1.hasNext()) 
            {
                add((InputDeviceType)iterator1.next());
            }
        }
    }

    public void clear()
    {
        fCollection.clear();
    }

    public InputDeviceTypeSet clone()
    {
        InputDeviceTypeSet inputdevicetypeset;
        try
        {
            inputdevicetypeset = (InputDeviceTypeSet)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return inputdevicetypeset;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean contains(InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            return false;
        } else
        {
            return fCollection.contains(inputdevicetype);
        }
    }

    public boolean equals(InputDeviceTypeSet inputdevicetypeset)
    {
        if (inputdevicetypeset == null)
        {
            return false;
        } else
        {
            return fCollection.equals(inputdevicetypeset.fCollection);
        }
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof InputDeviceTypeSet))
        {
            return false;
        } else
        {
            return equals((InputDeviceTypeSet)obj);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public boolean remove(InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            return false;
        } else
        {
            return fCollection.remove(inputdevicetype);
        }
    }

    public boolean removeAll(Iterable iterable)
    {
        boolean flag;
        if (iterable == null)
        {
            flag = false;
        } else
        {
            flag = false;
            Iterator iterator1 = iterable.iterator();
            while (iterator1.hasNext()) 
            {
                flag |= remove((InputDeviceType)iterator1.next());
            }
        }
        return flag;
    }

    public int size()
    {
        return fCollection.size();
    }

    public int toAndroidSourcesBitField()
    {
        int i = 0;
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            i |= ((InputDeviceType)iterator1.next()).toAndroidSourceId();
        }

        return i;
    }
}
