// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceInterface, InputDeviceInfo, ReadOnlyInputDeviceTypeSet, ConnectionState, 
//            InputDeviceType

public class InputDeviceInterfaceCollection
    implements Iterable, Cloneable
{

    private ArrayList fCollection;

    public InputDeviceInterfaceCollection()
    {
        fCollection = new ArrayList();
    }

    public void add(InputDeviceInterface inputdeviceinterface)
    {
        while (inputdeviceinterface == null || fCollection.indexOf(inputdeviceinterface) >= 0) 
        {
            return;
        }
        fCollection.add(inputdeviceinterface);
    }

    public void addAll(Iterable iterable)
    {
        if (iterable != null)
        {
            Iterator iterator1 = iterable.iterator();
            while (iterator1.hasNext()) 
            {
                add((InputDeviceInterface)iterator1.next());
            }
        }
    }

    public void clear()
    {
        fCollection.clear();
    }

    public InputDeviceInterfaceCollection clone()
    {
        InputDeviceInterfaceCollection inputdeviceinterfacecollection;
        try
        {
            inputdeviceinterfacecollection = (InputDeviceInterfaceCollection)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return inputdeviceinterfacecollection;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean contains(InputDeviceInterface inputdeviceinterface)
    {
        if (inputdeviceinterface == null)
        {
            return false;
        } else
        {
            return fCollection.contains(inputdeviceinterface);
        }
    }

    public boolean containsAndroidDeviceId(int i)
    {
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            InputDeviceInfo inputdeviceinfo = ((InputDeviceInterface)iterator1.next()).getDeviceInfo();
            if (inputdeviceinfo.hasAndroidDeviceId() && inputdeviceinfo.getAndroidDeviceId() == i)
            {
                return true;
            }
        }

        return false;
    }

    public InputDeviceInterfaceCollection getBy(ConnectionState connectionstate)
    {
        if (connectionstate == null)
        {
            throw new NullPointerException();
        }
        InputDeviceInterfaceCollection inputdeviceinterfacecollection = new InputDeviceInterfaceCollection();
        Iterator iterator1 = fCollection.iterator();
        do
        {
            if (!iterator1.hasNext())
            {
                break;
            }
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator1.next();
            if (inputdeviceinterface.getConnectionState() == connectionstate)
            {
                inputdeviceinterfacecollection.add(inputdeviceinterface);
            }
        } while (true);
        return inputdeviceinterfacecollection;
    }

    public InputDeviceInterface getByAndroidDeviceIdAndType(int i, InputDeviceType inputdevicetype)
    {
label0:
        {
            if (inputdevicetype == null)
            {
                break label0;
            }
            Iterator iterator1 = fCollection.iterator();
            InputDeviceInterface inputdeviceinterface;
            InputDeviceInfo inputdeviceinfo;
            do
            {
                if (!iterator1.hasNext())
                {
                    break label0;
                }
                inputdeviceinterface = (InputDeviceInterface)iterator1.next();
                inputdeviceinfo = inputdeviceinterface.getDeviceInfo();
            } while (!inputdeviceinfo.hasAndroidDeviceId() || inputdeviceinfo.getAndroidDeviceId() != i || !inputdeviceinfo.getInputSources().contains(inputdevicetype));
            return inputdeviceinterface;
        }
        return null;
    }

    public InputDeviceInterface getByCoronaDeviceId(int i)
    {
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator1.next();
            if (inputdeviceinterface.getCoronaDeviceId() == i)
            {
                return inputdeviceinterface;
            }
        }

        return null;
    }

    public InputDeviceInterface getByIndex(int i)
    {
        if (i < 0 || i >= fCollection.size())
        {
            return null;
        } else
        {
            return (InputDeviceInterface)fCollection.get(i);
        }
    }

    public InputDeviceInterface getByPermanentStringIdAndType(String s, InputDeviceType inputdevicetype)
    {
label0:
        {
            if (s == null || s.length() <= 0 || inputdevicetype == null)
            {
                break label0;
            }
            Iterator iterator1 = fCollection.iterator();
            InputDeviceInterface inputdeviceinterface;
            InputDeviceInfo inputdeviceinfo;
            do
            {
                if (!iterator1.hasNext())
                {
                    break label0;
                }
                inputdeviceinterface = (InputDeviceInterface)iterator1.next();
                inputdeviceinfo = inputdeviceinterface.getDeviceInfo();
            } while (!inputdeviceinfo.hasPermanentStringId() || !inputdeviceinfo.getPermanentStringId().equals(s) || !inputdeviceinfo.getInputSources().contains(inputdevicetype));
            return inputdeviceinterface;
        }
        return null;
    }

    public InputDeviceInterface getByPermanentStringIdAndTypeAndDisplayName(String s, InputDeviceType inputdevicetype, String s1)
    {
        if (s == null || s.length() <= 0)
        {
            return null;
        }
        if (inputdevicetype == null)
        {
            return null;
        }
        if (s1 == null || s1.length() <= 0)
        {
            return null;
        }
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator1.next();
            InputDeviceInfo inputdeviceinfo = inputdeviceinterface.getDeviceInfo();
            if (inputdeviceinfo.hasPermanentStringId() && inputdeviceinfo.getPermanentStringId().equals(s) && inputdeviceinfo.getInputSources().contains(inputdevicetype) && inputdeviceinfo.getDisplayName().equals(s1))
            {
                return inputdeviceinterface;
            }
        }

        return null;
    }

    public InputDeviceInterface getByTypeAndDisplayName(InputDeviceType inputdevicetype, String s)
    {
        if (inputdevicetype == null)
        {
            return null;
        }
        if (s == null || s.length() <= 0)
        {
            return null;
        }
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator1.next();
            InputDeviceInfo inputdeviceinfo = inputdeviceinterface.getDeviceInfo();
            if (inputdeviceinfo.getInputSources().contains(inputdevicetype) && inputdeviceinfo.getDisplayName().equals(s))
            {
                return inputdeviceinterface;
            }
        }

        return null;
    }

    public int indexOf(InputDeviceInterface inputdeviceinterface)
    {
        if (inputdeviceinterface == null)
        {
            return -1;
        } else
        {
            return fCollection.indexOf(inputdeviceinterface);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public boolean remove(InputDeviceInterface inputdeviceinterface)
    {
        if (inputdeviceinterface == null)
        {
            return false;
        } else
        {
            return fCollection.remove(inputdeviceinterface);
        }
    }

    public int size()
    {
        return fCollection.size();
    }
}
