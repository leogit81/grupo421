// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceServices, InputDeviceInterfaceCollection, InputDeviceInterface, InputDeviceInfo, 
//            ConnectionState, InputDeviceContext

private static class 
    implements 
{

    public void onInputDeviceConnected(int i)
    {
        InputDeviceServices.access$200(i);
    }

    public void onInputDeviceDisconnected(int i)
    {
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterfaceCollection inputdeviceinterfacecollection = InputDeviceServices.access$300().clone();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        if (inputdeviceinterfacecollection == null)
        {
            return;
        }
        break MISSING_BLOCK_LABEL_24;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        Iterator iterator = inputdeviceinterfacecollection.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator.next();
            if (inputdeviceinterface.getDeviceInfo().getAndroidDeviceId() == i)
            {
                inputdeviceinterface.getContext().update(ConnectionState.DISCONNECTED);
            }
        } while (true);
        return;
    }

    public void onInputDeviceReconfigured(int i)
    {
        InputDeviceServices.access$200(i);
    }

    public ()
    {
    }
}
