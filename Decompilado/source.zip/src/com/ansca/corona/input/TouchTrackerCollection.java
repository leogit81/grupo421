// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            TouchTracker

public class TouchTrackerCollection
    implements Iterable, Cloneable
{

    private ArrayList fCollection;

    public TouchTrackerCollection()
    {
        fCollection = new ArrayList();
    }

    public void add(TouchTracker touchtracker)
    {
        while (touchtracker == null || fCollection.indexOf(touchtracker) >= 0) 
        {
            return;
        }
        fCollection.add(touchtracker);
    }

    public void clear()
    {
        fCollection.clear();
    }

    public TouchTrackerCollection clone()
    {
        TouchTrackerCollection touchtrackercollection = new TouchTrackerCollection();
        TouchTracker touchtracker;
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext(); touchtrackercollection.fCollection.add(touchtracker.clone()))
        {
            touchtracker = (TouchTracker)iterator1.next();
        }

        return touchtrackercollection;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean contains(TouchTracker touchtracker)
    {
        if (touchtracker == null)
        {
            return false;
        } else
        {
            return fCollection.contains(touchtracker);
        }
    }

    public boolean containsDeviceAndPointerId(int i, int j)
    {
        return getByDeviceAndPointerId(i, j) != null;
    }

    public boolean containsTouchId(int i)
    {
        return getByTouchId(i) != null;
    }

    public TouchTracker getByDeviceAndPointerId(int i, int j)
    {
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            TouchTracker touchtracker = (TouchTracker)iterator1.next();
            if (touchtracker != null && touchtracker.getDeviceId() == i && touchtracker.getPointerId() == j)
            {
                return touchtracker;
            }
        }

        return null;
    }

    public TouchTracker getByIndex(int i)
    {
        if (i < 0 || i >= fCollection.size())
        {
            return null;
        } else
        {
            return (TouchTracker)fCollection.get(i);
        }
    }

    public TouchTracker getByTouchId(int i)
    {
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            TouchTracker touchtracker = (TouchTracker)iterator1.next();
            if (touchtracker != null && touchtracker.getTouchId() == i)
            {
                return touchtracker;
            }
        }

        return null;
    }

    public int indexOf(TouchTracker touchtracker)
    {
        if (touchtracker == null)
        {
            return -1;
        } else
        {
            return fCollection.indexOf(touchtracker);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public boolean remove(TouchTracker touchtracker)
    {
        if (touchtracker == null)
        {
            return false;
        } else
        {
            return fCollection.remove(touchtracker);
        }
    }

    public boolean removeByDeviceAndPointerId(int i, int j)
    {
        boolean flag;
        for (flag = false; remove(getByDeviceAndPointerId(i, j)); flag = true) { }
        return flag;
    }

    public boolean removeByDeviceId(int i)
    {
        boolean flag = false;
        for (int j = -1 + fCollection.size(); j >= 0; j--)
        {
            if (((TouchTracker)fCollection.get(j)).getDeviceId() == i)
            {
                fCollection.remove(j);
                flag = true;
            }
        }

        return flag;
    }

    public boolean removeByTouchId(int i)
    {
        boolean flag;
        for (flag = false; remove(getByTouchId(i)); flag = true) { }
        return flag;
    }

    public int size()
    {
        return fCollection.size();
    }
}
