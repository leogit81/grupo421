// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.SystemClock;

public class TouchPoint
{

    private float fPointX;
    private float fPointY;
    private long fTimestamp;

    public TouchPoint(float f, float f1)
    {
        this(f, f1, SystemClock.uptimeMillis());
    }

    public TouchPoint(float f, float f1, long l)
    {
        fPointX = f;
        fPointY = f1;
        fTimestamp = l;
    }

    public long getTimestamp()
    {
        return fTimestamp;
    }

    public float getX()
    {
        return fPointX;
    }

    public float getY()
    {
        return fPointY;
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("(");
        stringbuilder.append(Float.toString(fPointX));
        stringbuilder.append(", ");
        stringbuilder.append(Float.toString(fPointY));
        stringbuilder.append(", ");
        stringbuilder.append(Long.toString(fTimestamp));
        stringbuilder.append(")");
        return stringbuilder.toString();
    }
}
