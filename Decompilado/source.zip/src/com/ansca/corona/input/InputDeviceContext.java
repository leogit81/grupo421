// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            ConnectionState, InputDeviceStatusEventInfo, AxisDataEventInfo, AxisDataPoint, 
//            InputDeviceInfo, ReadOnlyAxisInfoCollection, AxisInfo, InputDeviceSettings, 
//            VibrationSettings

public class InputDeviceContext
{
    public static interface Listener
    {
    }

    public static interface OnAxisDataReceivedListener
        extends Listener
    {

        public abstract void onAxisDataReceived(InputDeviceContext inputdevicecontext, AxisDataEventInfo axisdataeventinfo);
    }

    public static interface OnStatusChangedListener
        extends Listener
    {

        public abstract void onStatusChanged(InputDeviceContext inputdevicecontext, InputDeviceStatusEventInfo inputdevicestatuseventinfo);
    }

    public static interface VibrateRequestHandler
    {

        public abstract void onHandleVibrateRequest(InputDeviceContext inputdevicecontext, VibrationSettings vibrationsettings);
    }


    private HashMap fAxisData;
    private ArrayList fAxisEvents;
    private ConnectionState fConnectionState;
    private int fCoronaDeviceId;
    private InputDeviceInfo fDeviceInfo;
    private boolean fIsConnected;
    private ArrayList fListeners;
    private InputDeviceStatusEventInfo.Settings fStatusEventSettings;
    private VibrateRequestHandler fVibrateRequestHandler;

    InputDeviceContext(int i, InputDeviceInfo inputdeviceinfo)
    {
        if (inputdeviceinfo == null)
        {
            throw new NullPointerException();
        } else
        {
            fCoronaDeviceId = i;
            fDeviceInfo = inputdeviceinfo;
            fIsConnected = false;
            fConnectionState = ConnectionState.DISCONNECTED;
            fAxisData = new HashMap();
            fAxisEvents = new ArrayList();
            fVibrateRequestHandler = null;
            fListeners = new ArrayList();
            fStatusEventSettings = null;
            return;
        }
    }

    public void addListener(Listener listener)
    {
        this;
        JVM INSTR monitorenter ;
        if (listener != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (!fListeners.contains(listener))
        {
            fListeners.add(listener);
        }
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void beginUpdate()
    {
        if (fStatusEventSettings != null)
        {
            return;
        } else
        {
            fStatusEventSettings = new InputDeviceStatusEventInfo.Settings();
            return;
        }
    }

    public void endUpdate()
    {
        InputDeviceStatusEventInfo.Settings settings = fStatusEventSettings;
        if (settings != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        fStatusEventSettings = null;
        boolean flag;
        boolean flag1;
        ArrayList arraylist;
        ArrayList arraylist1;
        InputDeviceStatusEventInfo inputdevicestatuseventinfo;
        Iterator iterator;
        Listener listener;
        Iterator iterator1;
        AxisDataEventInfo axisdataeventinfo;
        if (fAxisEvents.size() > 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        flag1 = settings.hasConnectionStateChanged() | settings.wasReconfigured();
        if (!flag && !flag1)
        {
            continue; /* Loop/switch isn't completed */
        }
        this;
        JVM INSTR monitorenter ;
        arraylist = (ArrayList)fAxisEvents.clone();
        fAxisEvents.clear();
        arraylist1 = (ArrayList)fListeners.clone();
        this;
        JVM INSTR monitorexit ;
        if (arraylist1.size() > 0)
        {
            inputdevicestatuseventinfo = new InputDeviceStatusEventInfo(settings);
            iterator = arraylist1.iterator();
            while (iterator.hasNext()) 
            {
                listener = (Listener)iterator.next();
                if (flag1 && (listener instanceof OnStatusChangedListener))
                {
                    ((OnStatusChangedListener)listener).onStatusChanged(this, inputdevicestatuseventinfo);
                }
                if (flag && (listener instanceof OnAxisDataReceivedListener))
                {
                    iterator1 = arraylist.iterator();
                    while (iterator1.hasNext()) 
                    {
                        axisdataeventinfo = (AxisDataEventInfo)iterator1.next();
                        ((OnAxisDataReceivedListener)listener).onAxisDataReceived(this, axisdataeventinfo);
                    }
                }
            }
        }
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public AxisDataPoint getAxisDataByIndex(int i)
    {
        this;
        JVM INSTR monitorenter ;
        AxisDataPoint axisdatapoint = (AxisDataPoint)fAxisData.get(Integer.valueOf(i));
        this;
        JVM INSTR monitorexit ;
        return axisdatapoint;
        Exception exception;
        exception;
        throw exception;
    }

    public ConnectionState getConnectionState()
    {
        return fConnectionState;
    }

    public int getCoronaDeviceId()
    {
        return fCoronaDeviceId;
    }

    public InputDeviceInfo getDeviceInfo()
    {
        return fDeviceInfo;
    }

    public VibrateRequestHandler getVibrateRequestHandler()
    {
        return fVibrateRequestHandler;
    }

    public boolean isConnected()
    {
        return fConnectionState.isConnected();
    }

    public boolean isUpdating()
    {
        return fStatusEventSettings != null;
    }

    public void removeListener(Listener listener)
    {
        this;
        JVM INSTR monitorenter ;
        if (listener != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        fListeners.remove(listener);
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void setVibrateRequestHandler(VibrateRequestHandler vibraterequesthandler)
    {
        fVibrateRequestHandler = vibraterequesthandler;
    }

    public void update(int i, AxisDataPoint axisdatapoint)
    {
_L2:
        return;
        AxisInfo axisinfo;
        if (axisdatapoint == null || (axisinfo = fDeviceInfo.getAxes().getByIndex(i)) == null) goto _L2; else goto _L1
_L1:
        Integer integer;
        AxisDataPoint axisdatapoint1;
        boolean flag;
        float f;
        if (axisdatapoint.getValue() > axisinfo.getMaxValue())
        {
            axisdatapoint = new AxisDataPoint(axisinfo.getMaxValue(), axisdatapoint.getTimestamp());
        } else
        if (axisdatapoint.getValue() < axisinfo.getMinValue())
        {
            axisdatapoint = new AxisDataPoint(axisinfo.getMinValue(), axisdatapoint.getTimestamp());
        }
        integer = Integer.valueOf(i);
        this;
        JVM INSTR monitorenter ;
        axisdatapoint1 = (AxisDataPoint)fAxisData.get(integer);
        this;
        JVM INSTR monitorexit ;
        if (axisdatapoint1 == null)
        {
            break; /* Loop/switch isn't completed */
        }
        f = axisinfo.getAccuracy();
        if (f <= 0.0F)
        {
            f = 0.01F;
        }
        if (axisdatapoint.getValue() < f + axisdatapoint1.getValue() && axisdatapoint.getValue() > axisdatapoint1.getValue() - f) goto _L2; else goto _L3
_L3:
        flag = isUpdating();
        if (!flag)
        {
            beginUpdate();
        }
        this;
        JVM INSTR monitorenter ;
        fAxisData.put(integer, axisdatapoint);
        fAxisEvents.add(new AxisDataEventInfo(fDeviceInfo, i, axisdatapoint));
        this;
        JVM INSTR monitorexit ;
        if (flag) goto _L2; else goto _L4
_L4:
        endUpdate();
        return;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        Exception exception1;
        exception1;
        this;
        JVM INSTR monitorexit ;
        throw exception1;
    }

    public void update(ConnectionState connectionstate)
    {
        if (connectionstate == null)
        {
            throw new NullPointerException();
        }
        if (connectionstate != fConnectionState)
        {
            fConnectionState = connectionstate;
            boolean flag = isUpdating();
            if (!flag)
            {
                beginUpdate();
            }
            fStatusEventSettings.setHasConnectionStateChanged(true);
            if (!flag)
            {
                endUpdate();
                return;
            }
        }
    }

    void update(InputDeviceInfo inputdeviceinfo)
    {
        if (inputdeviceinfo == null)
        {
            throw new NullPointerException();
        }
        if (!fDeviceInfo.equals(inputdeviceinfo))
        {
            fDeviceInfo = inputdeviceinfo;
            boolean flag = isUpdating();
            if (!flag)
            {
                beginUpdate();
            }
            fStatusEventSettings.setWasReconfigured(true);
            if (!flag)
            {
                endUpdate();
                return;
            }
        }
    }

    public void update(InputDeviceSettings inputdevicesettings)
    {
        update(InputDeviceInfo.from(inputdevicesettings));
    }

    public void vibrate()
    {
        VibrateRequestHandler vibraterequesthandler;
        if (fDeviceInfo.canVibrate())
        {
            if ((vibraterequesthandler = fVibrateRequestHandler) != null)
            {
                vibraterequesthandler.onHandleVibrateRequest(this, null);
                return;
            }
        }
    }
}
