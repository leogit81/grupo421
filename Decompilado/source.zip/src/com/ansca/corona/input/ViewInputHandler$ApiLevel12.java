// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;
import android.view.View;

// Referenced classes of package com.ansca.corona.input:
//            ViewInputHandler

private static class r
{
    private static class EventHandler extends ViewInputHandler.EventHandler
        implements android.view.View.OnGenericMotionListener
    {

        public boolean onGenericMotion(View view, MotionEvent motionevent)
        {
            return getInputHandler().handle(motionevent);
        }

        protected void setViewListenersTo(ViewInputHandler.EventHandler eventhandler)
        {
            super.setViewListenersTo(eventhandler);
            View view = getInputHandler().getView();
            if (view != null)
            {
                view.setOnGenericMotionListener((EventHandler)eventhandler);
            }
        }

        public EventHandler(ViewInputHandler viewinputhandler)
        {
            super(viewinputhandler);
        }
    }


    public static r createEventHandlerWith(ViewInputHandler viewinputhandler)
    {
        return new EventHandler(viewinputhandler);
    }

    private r()
    {
    }
}
