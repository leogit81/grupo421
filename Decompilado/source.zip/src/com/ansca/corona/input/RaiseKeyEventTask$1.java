// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaEnvironment;

// Referenced classes of package com.ansca.corona.input:
//            RaiseKeyEventTask, CoronaKeyEvent

class this._cls0
    implements Runnable
{

    final RaiseKeyEventTask this$0;

    public void run()
    {
        CoronaActivity coronaactivity;
        for (coronaactivity = CoronaEnvironment.getCoronaActivity(); coronaactivity == null || coronaactivity.isFinishing();)
        {
            return;
        }

        coronaactivity.dispatchKeyEvent(new CoronaKeyEvent(RaiseKeyEventTask.access$000(RaiseKeyEventTask.this)));
    }

    ()
    {
        this$0 = RaiseKeyEventTask.this;
        super();
    }
}
