// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;
import android.view.MotionEvent;
import com.ansca.corona.Controller;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;

// Referenced classes of package com.ansca.corona.input:
//            TouchTrackerCollection, TapTrackerCollection, InputDeviceServices, InputDeviceInterface, 
//            InputDeviceContext, InputDeviceInfo, ReadOnlyAxisInfoCollection, AxisInfo, 
//            AxisType, AxisDataPoint, InputDeviceType, TouchPoint, 
//            RaiseMouseEventTask, TouchTracker, TouchPhase, RaiseMultitouchEventTask, 
//            RaiseTouchEventTask, TapTracker, RaiseTapEventTask, KeyPhase, 
//            CoronaKeyEvent, ConnectionState, RaiseKeyEventTask

public class InputHandler
{
    private static class ApiLevel12
    {

        public static float getAxisValueFrom(MotionEvent motionevent, int i)
        {
            if (motionevent == null)
            {
                throw new NullPointerException();
            } else
            {
                return motionevent.getAxisValue(i);
            }
        }

        private ApiLevel12()
        {
        }
    }

    private static class ApiLevel14
    {

        public static boolean isMiddleMouseButtonPressedFor(MotionEvent motionevent)
        {
            while (motionevent == null || (4 & motionevent.getButtonState()) == 0) 
            {
                return false;
            }
            return true;
        }

        public static boolean isPrimaryMouseButtonPressedFor(MotionEvent motionevent)
        {
            while (motionevent == null || (1 & motionevent.getButtonState()) == 0) 
            {
                return false;
            }
            return true;
        }

        public static boolean isSecondaryMouseButtonPressedFor(MotionEvent motionevent)
        {
            while (motionevent == null || (2 & motionevent.getButtonState()) == 0) 
            {
                return false;
            }
            return true;
        }

        private ApiLevel14()
        {
        }
    }


    private TapTrackerCollection fTapTrackers;
    private CoronaRuntimeTaskDispatcher fTaskDispatcher;
    private TouchTrackerCollection fTouchTrackers;

    public InputHandler()
    {
        fTaskDispatcher = null;
        fTouchTrackers = new TouchTrackerCollection();
        fTapTrackers = new TapTrackerCollection();
    }

    private boolean handleAxisEvent(MotionEvent motionevent)
    {
        if (motionevent != null && android.os.Build.VERSION.SDK_INT >= 12)
        {
            int i = motionevent.getDeviceId();
            InputDeviceInterface inputdeviceinterface = null;
            if (i > 0)
            {
                android.content.Context context = CoronaEnvironment.getApplicationContext();
                inputdeviceinterface = null;
                if (context != null)
                {
                    inputdeviceinterface = (new InputDeviceServices(context)).fetchDeviceFrom(motionevent);
                }
            }
            if (inputdeviceinterface != null)
            {
                inputdeviceinterface.getContext().beginUpdate();
                ReadOnlyAxisInfoCollection readonlyaxisinfocollection = inputdeviceinterface.getDeviceInfo().getAxes();
                int j = 0;
                while (j < readonlyaxisinfocollection.size()) 
                {
                    AxisInfo axisinfo = readonlyaxisinfocollection.getByIndex(j);
                    if (axisinfo != null)
                    {
                        try
                        {
                            float f = ApiLevel12.getAxisValueFrom(motionevent, axisinfo.getType().toAndroidIntegerId());
                            inputdeviceinterface.getContext().update(j, new AxisDataPoint(f, motionevent.getEventTime()));
                        }
                        catch (Exception exception) { }
                    }
                    j++;
                }
                inputdeviceinterface.getContext().endUpdate();
                return false;
            }
        }
        return false;
    }

    private boolean handleMouseEvent(MotionEvent motionevent)
    {
        int i;
        TouchPoint touchpoint;
        if (motionevent == null)
        {
            return false;
        }
        if (InputDeviceType.from(motionevent) != InputDeviceType.MOUSE)
        {
            return false;
        }
        if (motionevent.getPointerCount() <= 0)
        {
            return false;
        }
        i = 0xff & motionevent.getAction();
        touchpoint = new TouchPoint(motionevent.getX(), motionevent.getY(), motionevent.getEventTime());
        if (android.os.Build.VERSION.SDK_INT < 14) goto _L2; else goto _L1
_L1:
        boolean flag;
        boolean flag1;
        boolean flag2;
        flag = ApiLevel14.isPrimaryMouseButtonPressedFor(motionevent);
        flag1 = ApiLevel14.isSecondaryMouseButtonPressedFor(motionevent);
        flag2 = ApiLevel14.isMiddleMouseButtonPressedFor(motionevent);
_L7:
        TouchTracker touchtracker;
        if (fTaskDispatcher != null)
        {
            RaiseMouseEventTask raisemouseeventtask = new RaiseMouseEventTask(touchpoint.getX(), touchpoint.getY(), touchpoint.getTimestamp(), flag, flag1, flag2);
            fTaskDispatcher.send(raisemouseeventtask);
        }
        int j = motionevent.getDeviceId();
        int k = motionevent.getPointerId(0);
        touchtracker = fTouchTrackers.getByDeviceAndPointerId(j, k);
        if (touchtracker == null)
        {
            touchtracker = new TouchTracker(j, k);
            fTouchTrackers.add(touchtracker);
        }
        if (!flag || i == 3)
        {
            break MISSING_BLOCK_LABEL_397;
        }
        if (!touchtracker.hasNotStarted()) goto _L4; else goto _L3
_L3:
        boolean flag4;
        TouchPhase touchphase3 = TouchPhase.BEGAN;
        touchtracker.updateWith(touchpoint, touchphase3);
        flag4 = true;
_L10:
        boolean flag3;
        TouchPhase touchphase;
        TouchPhase touchphase1;
        float f;
        float f1;
        TouchPhase touchphase2;
        int l;
        if (flag4 && fTaskDispatcher != null)
        {
            if (Controller.isMultitouchEnabled())
            {
                TouchTrackerCollection touchtrackercollection = new TouchTrackerCollection();
                touchtrackercollection.add(touchtracker);
                fTaskDispatcher.send(new RaiseMultitouchEventTask(touchtrackercollection));
            } else
            {
                fTaskDispatcher.send(new RaiseTouchEventTask(touchtracker));
            }
        }
        if (touchtracker.getPhase() == TouchPhase.ENDED || touchtracker.getPhase() == TouchPhase.CANCELED)
        {
            touchtracker.reset();
        }
        return true;
_L2:
        if (i == 0) goto _L6; else goto _L5
_L5:
        flag = false;
        flag1 = false;
        flag2 = false;
        if (i != 2) goto _L7; else goto _L6
_L6:
        flag = true;
        flag1 = false;
        flag2 = false;
          goto _L7
_L4:
        f = Math.abs(touchpoint.getX() - touchtracker.getLastPoint().getX());
        f1 = Math.abs(touchpoint.getY() - touchtracker.getLastPoint().getY());
        if (f >= 1.0F) goto _L9; else goto _L8
_L8:
        l = f1 != 1.0F;
        flag4 = false;
        if (l < 0) goto _L10; else goto _L9
_L9:
        touchphase2 = TouchPhase.MOVED;
        touchtracker.updateWith(touchpoint, touchphase2);
        flag4 = true;
          goto _L10
        flag3 = touchtracker.hasStarted();
        flag4 = false;
        if (flag3)
        {
            if (i == 3)
            {
                touchphase1 = TouchPhase.CANCELED;
                touchtracker.updateWith(touchpoint, touchphase1);
            } else
            {
                touchphase = TouchPhase.ENDED;
                touchtracker.updateWith(touchpoint, touchphase);
            }
            flag4 = true;
        }
          goto _L10
    }

    private boolean handleTapEvent(MotionEvent motionevent)
    {
        InputDeviceType inputdevicetype;
        if (motionevent != null)
        {
            if ((inputdevicetype = InputDeviceType.from(motionevent)) == InputDeviceType.TOUCHSCREEN || inputdevicetype == InputDeviceType.STYLUS || inputdevicetype == InputDeviceType.MOUSE)
            {
                TapTracker taptracker = fTapTrackers.getByDeviceId(motionevent.getDeviceId());
                if (taptracker == null)
                {
                    taptracker = new TapTracker(motionevent.getDeviceId());
                    fTapTrackers.add(taptracker);
                }
                taptracker.updateWith(motionevent);
                if (taptracker.hasTapOccurred() && fTaskDispatcher != null)
                {
                    fTaskDispatcher.send(new RaiseTapEventTask(taptracker.getTapPoint(), taptracker.getTapCount()));
                }
                return true;
            }
        }
        return false;
    }

    private boolean handleTouchEvent(MotionEvent motionevent)
    {
        TouchTrackerCollection touchtrackercollection;
        TouchPhase touchphase;
        if (motionevent == null)
        {
            return false;
        }
        InputDeviceType inputdevicetype = InputDeviceType.from(motionevent);
        if (inputdevicetype != InputDeviceType.TOUCHSCREEN && inputdevicetype != InputDeviceType.STYLUS)
        {
            return false;
        }
        boolean flag = Controller.isMultitouchEnabled();
        touchtrackercollection = null;
        if (flag)
        {
            touchtrackercollection = new TouchTrackerCollection();
        }
        touchphase = TouchPhase.from(motionevent);
        0xff & motionevent.getAction();
        JVM INSTR tableswitch 0 6: default 104
    //                   0 150
    //                   1 265
    //                   2 265
    //                   3 265
    //                   4 104
    //                   5 499
    //                   6 600;
           goto _L1 _L2 _L3 _L3 _L3 _L1 _L4 _L5
_L1:
        if (touchtrackercollection != null && touchtrackercollection.size() > 0 && fTaskDispatcher != null)
        {
            CoronaRuntimeTaskDispatcher coronaruntimetaskdispatcher = fTaskDispatcher;
            RaiseMultitouchEventTask raisemultitoucheventtask = new RaiseMultitouchEventTask(touchtrackercollection);
            coronaruntimetaskdispatcher.send(raisemultitoucheventtask);
        }
        return true;
_L2:
        fTouchTrackers.removeByDeviceId(motionevent.getDeviceId());
        TouchTracker touchtracker3 = new TouchTracker(motionevent.getDeviceId(), motionevent.getPointerId(0));
        touchtracker3.updateWith(new TouchPoint(motionevent.getX(), motionevent.getY(), motionevent.getEventTime()), TouchPhase.BEGAN);
        fTouchTrackers.add(touchtracker3);
        if (touchtrackercollection != null)
        {
            touchtrackercollection.add(touchtracker3);
        } else
        if (fTaskDispatcher != null)
        {
            CoronaRuntimeTaskDispatcher coronaruntimetaskdispatcher3 = fTaskDispatcher;
            RaiseTouchEventTask raisetoucheventtask2 = new RaiseTouchEventTask(touchtracker3);
            coronaruntimetaskdispatcher3.send(raisetoucheventtask2);
        }
        continue; /* Loop/switch isn't completed */
_L3:
        int i1;
        int j1;
        i1 = motionevent.getPointerCount();
        j1 = 0;
_L10:
        if (j1 >= i1) goto _L7; else goto _L6
_L6:
        TouchTracker touchtracker2;
        int k1 = motionevent.getDeviceId();
        int l1 = motionevent.getPointerId(j1);
        touchtracker2 = fTouchTrackers.getByDeviceAndPointerId(k1, l1);
        if (touchtracker2 != null && !touchtracker2.hasNotStarted()) goto _L9; else goto _L8
_L8:
        j1++;
          goto _L10
_L9:
        float f;
        float f1;
        f = motionevent.getX(j1);
        f1 = motionevent.getY(j1);
        if (touchphase != TouchPhase.MOVED) goto _L12; else goto _L11
_L11:
        float f2;
        float f3;
        f2 = Math.abs(f - touchtracker2.getLastPoint().getX());
        f3 = Math.abs(f1 - touchtracker2.getLastPoint().getY());
        if (f2 < 1.0F && f3 < 1.0F) goto _L8; else goto _L12
_L12:
        touchtracker2.updateWith(new TouchPoint(f, f1, motionevent.getEventTime()), touchphase);
        if (touchtrackercollection != null)
        {
            touchtrackercollection.add(touchtracker2);
        } else
        if (fTaskDispatcher != null)
        {
            CoronaRuntimeTaskDispatcher coronaruntimetaskdispatcher2 = fTaskDispatcher;
            RaiseTouchEventTask raisetoucheventtask1 = new RaiseTouchEventTask(touchtracker2);
            coronaruntimetaskdispatcher2.send(raisetoucheventtask1);
        }
          goto _L8
_L7:
        if (touchphase == TouchPhase.ENDED || touchphase == TouchPhase.CANCELED)
        {
            fTouchTrackers.removeByDeviceId(motionevent.getDeviceId());
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (touchtrackercollection != null)
        {
            int k = motionevent.getActionIndex();
            int l = motionevent.getPointerId(k);
            fTouchTrackers.removeByDeviceAndPointerId(motionevent.getDeviceId(), l);
            TouchPoint touchpoint = new TouchPoint(motionevent.getX(k), motionevent.getY(k), motionevent.getEventTime());
            TouchTracker touchtracker1 = new TouchTracker(motionevent.getDeviceId(), l);
            touchtracker1.updateWith(touchpoint, touchphase);
            fTouchTrackers.add(touchtracker1);
            touchtrackercollection.add(touchtracker1);
        }
        continue; /* Loop/switch isn't completed */
_L5:
        int i = motionevent.getActionIndex();
        int j = motionevent.getPointerId(i);
        TouchTracker touchtracker = fTouchTrackers.getByDeviceAndPointerId(motionevent.getDeviceId(), j);
        if (touchtracker != null)
        {
            touchtracker.updateWith(new TouchPoint(motionevent.getX(i), motionevent.getY(i), motionevent.getEventTime()), touchphase);
            if (touchtrackercollection != null)
            {
                touchtrackercollection.add(touchtracker);
                fTouchTrackers.removeByDeviceAndPointerId(motionevent.getDeviceId(), j);
            } else
            {
                if (fTaskDispatcher != null)
                {
                    CoronaRuntimeTaskDispatcher coronaruntimetaskdispatcher1 = fTaskDispatcher;
                    RaiseTouchEventTask raisetoucheventtask = new RaiseTouchEventTask(touchtracker);
                    coronaruntimetaskdispatcher1.send(raisetoucheventtask);
                }
                fTouchTrackers.removeByDeviceId(motionevent.getDeviceId());
            }
        }
        if (true) goto _L1; else goto _L13
_L13:
    }

    public CoronaRuntimeTaskDispatcher getDispatcher()
    {
        return fTaskDispatcher;
    }

    public boolean handle(KeyEvent keyevent)
    {
        if (keyevent != null)
        {
            if (KeyPhase.from(keyevent) == KeyPhase.DOWN && keyevent.getRepeatCount() > 0)
            {
                return true;
            }
            if (!(keyevent instanceof CoronaKeyEvent))
            {
                int i = keyevent.getDeviceId();
                InputDeviceInterface inputdeviceinterface = null;
                if (i > 0)
                {
                    android.content.Context context = CoronaEnvironment.getApplicationContext();
                    inputdeviceinterface = null;
                    if (context != null)
                    {
                        inputdeviceinterface = (new InputDeviceServices(context)).fetchDeviceFrom(keyevent);
                    }
                }
                if (inputdeviceinterface != null)
                {
                    inputdeviceinterface.getContext().update(ConnectionState.CONNECTED);
                }
                if (keyevent.getKeyCode() != 3 && keyevent.getKeyCode() != 26 && fTaskDispatcher != null)
                {
                    fTaskDispatcher.send(new RaiseKeyEventTask(inputdeviceinterface, keyevent));
                    return true;
                }
            }
        }
        return false;
    }

    public boolean handle(MotionEvent motionevent)
    {
        if (motionevent == null)
        {
            return false;
        } else
        {
            return false | handleAxisEvent(motionevent) | handleMouseEvent(motionevent) | handleTouchEvent(motionevent) | handleTapEvent(motionevent);
        }
    }

    public void setDispatcher(CoronaRuntimeTaskDispatcher coronaruntimetaskdispatcher)
    {
        fTaskDispatcher = coronaruntimetaskdispatcher;
    }
}
