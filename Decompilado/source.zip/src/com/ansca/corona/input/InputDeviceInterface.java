// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            InputDeviceContext, ConnectionState, InputDeviceInfo

public class InputDeviceInterface
{

    private InputDeviceContext fDeviceContext;

    InputDeviceInterface(InputDeviceContext inputdevicecontext)
    {
        if (inputdevicecontext == null)
        {
            throw new NullPointerException();
        } else
        {
            fDeviceContext = inputdevicecontext;
            return;
        }
    }

    public ConnectionState getConnectionState()
    {
        return fDeviceContext.getConnectionState();
    }

    InputDeviceContext getContext()
    {
        return fDeviceContext;
    }

    public int getCoronaDeviceId()
    {
        return fDeviceContext.getCoronaDeviceId();
    }

    public InputDeviceInfo getDeviceInfo()
    {
        return fDeviceContext.getDeviceInfo();
    }

    public boolean isConnected()
    {
        return fDeviceContext.isConnected();
    }

    public void vibrate()
    {
        fDeviceContext.vibrate();
    }
}
