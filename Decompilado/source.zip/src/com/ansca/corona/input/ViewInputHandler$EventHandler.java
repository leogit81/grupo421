// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

// Referenced classes of package com.ansca.corona.input:
//            ViewInputHandler

private static class fInputHandler
    implements android.view.ntHandler, android.view.ntHandler
{

    private ViewInputHandler fInputHandler;

    public ViewInputHandler getInputHandler()
    {
        return fInputHandler;
    }

    public boolean onKey(View view, int i, KeyEvent keyevent)
    {
        return fInputHandler.handle(keyevent);
    }

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        return fInputHandler.handle(motionevent);
    }

    protected void setViewListenersTo(fInputHandler finputhandler)
    {
        View view = fInputHandler.getView();
        if (view != null)
        {
            view.setOnKeyListener(finputhandler);
            view.setOnTouchListener(finputhandler);
        }
    }

    public void subscribe()
    {
        setViewListenersTo(this);
    }

    public void unsubscribe()
    {
        setViewListenersTo(null);
    }

    public (ViewInputHandler viewinputhandler)
    {
        if (viewinputhandler == null)
        {
            throw new NullPointerException();
        } else
        {
            fInputHandler = viewinputhandler;
            return;
        }
    }
}
