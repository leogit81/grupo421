// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;

// Referenced classes of package com.ansca.corona.input:
//            TouchTracker

public class RaiseTouchEventTask
    implements CoronaRuntimeTask
{

    private TouchTracker fTouchTracker;

    public RaiseTouchEventTask(TouchTracker touchtracker)
    {
        fTouchTracker = touchtracker.clone();
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        if (fTouchTracker != null)
        {
            JavaToNativeShim.touchEvent(fTouchTracker);
        }
    }
}
