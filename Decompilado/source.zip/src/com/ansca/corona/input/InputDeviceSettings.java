// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceType, AxisSettings

public class InputDeviceSettings
    implements Cloneable
{

    private ArrayList fAxisCollection;
    private InputDeviceType fDeviceType;
    private String fDisplayName;
    private String fPermanentStringId;
    private String fProductName;

    public InputDeviceSettings()
    {
        fDeviceType = InputDeviceType.UNKNOWN;
        fPermanentStringId = null;
        fProductName = "";
        fDisplayName = "";
        fAxisCollection = new ArrayList();
    }

    public InputDeviceSettings clone()
    {
        InputDeviceSettings inputdevicesettings = null;
        Iterator iterator;
        inputdevicesettings = (InputDeviceSettings)super.clone();
        inputdevicesettings.fAxisCollection.clear();
        iterator = fAxisCollection.iterator();
_L1:
        AxisSettings axissettings;
        if (!iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_79;
        }
        axissettings = (AxisSettings)iterator.next();
        if (axissettings == null)
        {
            break MISSING_BLOCK_LABEL_66;
        }
        inputdevicesettings.fAxisCollection.add(axissettings.clone());
          goto _L1
        inputdevicesettings.fAxisCollection.add(null);
          goto _L1
        Exception exception;
        exception;
        return inputdevicesettings;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public List getAxes()
    {
        return fAxisCollection;
    }

    public String getDisplayName()
    {
        return fDisplayName;
    }

    public String getPermanentStringId()
    {
        return fPermanentStringId;
    }

    public String getProductName()
    {
        return fProductName;
    }

    public InputDeviceType getType()
    {
        return fDeviceType;
    }

    public boolean hasPermanentStringId()
    {
        return fPermanentStringId != null && fPermanentStringId.length() > 0;
    }

    public void setDisplayName(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fDisplayName = s;
    }

    public void setPermanentStringId(String s)
    {
        if (s != null && s.length() <= 0)
        {
            s = null;
        }
        fPermanentStringId = s;
    }

    public void setProductName(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fProductName = s;
    }

    public void setType(InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            inputdevicetype = InputDeviceType.UNKNOWN;
        }
        fDeviceType = inputdevicetype;
    }
}
