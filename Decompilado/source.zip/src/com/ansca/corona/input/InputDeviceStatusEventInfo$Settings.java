// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            InputDeviceStatusEventInfo

public static class fWasReconfigured
    implements Cloneable
{

    private boolean fHasConnectionStateChanged;
    private boolean fWasReconfigured;

    public fWasReconfigured clone()
    {
        fWasReconfigured fwasreconfigured;
        try
        {
            fwasreconfigured = (fWasReconfigured)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return fwasreconfigured;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean hasConnectionStateChanged()
    {
        return fHasConnectionStateChanged;
    }

    public void setHasConnectionStateChanged(boolean flag)
    {
        fHasConnectionStateChanged = flag;
    }

    public void setWasReconfigured(boolean flag)
    {
        fWasReconfigured = flag;
    }

    public boolean wasReconfigured()
    {
        return fWasReconfigured;
    }

    public ()
    {
        fHasConnectionStateChanged = false;
        fWasReconfigured = false;
    }
}
