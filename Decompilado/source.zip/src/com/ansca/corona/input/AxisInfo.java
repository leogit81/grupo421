// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            AxisSettings, AxisType

public class AxisInfo
{

    private AxisSettings fSettings;

    private AxisInfo(AxisSettings axissettings)
    {
        if (axissettings == null)
        {
            throw new NullPointerException();
        } else
        {
            fSettings = axissettings.clone();
            return;
        }
    }

    public static AxisInfo from(AxisSettings axissettings)
    {
        if (axissettings == null)
        {
            return null;
        } else
        {
            return new AxisInfo(axissettings);
        }
    }

    public boolean equals(AxisInfo axisinfo)
    {
        if (axisinfo == null)
        {
            return false;
        } else
        {
            return fSettings.equals(axisinfo.fSettings);
        }
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof AxisInfo))
        {
            return false;
        } else
        {
            return equals((AxisInfo)obj);
        }
    }

    public float getAccuracy()
    {
        return fSettings.getAccuracy();
    }

    public float getMaxValue()
    {
        return fSettings.getMaxValue();
    }

    public float getMinValue()
    {
        return fSettings.getMinValue();
    }

    public AxisType getType()
    {
        return fSettings.getType();
    }

    public boolean isProvidingAbsoluteValues()
    {
        return fSettings.isProvidingAbsoluteValues();
    }
}
