// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            InputDeviceMonitor

private static abstract class fDeviceMonitor
{

    private InputDeviceMonitor fDeviceMonitor;

    public InputDeviceMonitor getDeviceMonitor()
    {
        return fDeviceMonitor;
    }

    public abstract void subscribe();

    public abstract void unsubscribe();

    public (InputDeviceMonitor inputdevicemonitor)
    {
        if (inputdevicemonitor == null)
        {
            throw new NullPointerException();
        } else
        {
            fDeviceMonitor = inputdevicemonitor;
            return;
        }
    }
}
