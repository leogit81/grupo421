// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.Looper;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceMonitor

private static class fHandler extends fHandler
    implements android.hardware.input.fHandler
{

    private Handler fHandler;

    private InputManager getInputManager()
    {
        return (InputManager)(InputManager)getDeviceMonitor().getContext().getSystemService("input");
    }

    public void onInputDeviceAdded(int i)
    {
        InputDeviceMonitor.access$000(getDeviceMonitor(), i);
    }

    public void onInputDeviceChanged(int i)
    {
        InputDeviceMonitor.access$200(getDeviceMonitor(), i);
    }

    public void onInputDeviceRemoved(int i)
    {
        InputDeviceMonitor.access$100(getDeviceMonitor(), i);
    }

    public void subscribe()
    {
        InputManager inputmanager = getInputManager();
        if (inputmanager != null)
        {
            inputmanager.registerInputDeviceListener(this, fHandler);
        }
    }

    public void unsubscribe()
    {
        InputManager inputmanager = getInputManager();
        if (inputmanager != null)
        {
            inputmanager.unregisterInputDeviceListener(this);
        }
    }

    public (InputDeviceMonitor inputdevicemonitor)
    {
        super(inputdevicemonitor);
        fHandler = new Handler(Looper.getMainLooper());
    }
}
