// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

// Referenced classes of package com.ansca.corona.input:
//            InputHandler

public class ViewInputHandler extends InputHandler
{
    private static class ApiLevel12
    {

        public static EventHandler createEventHandlerWith(ViewInputHandler viewinputhandler)
        {
            return new EventHandler(viewinputhandler);
        }

        private ApiLevel12()
        {
        }
    }

    private static class ApiLevel12.EventHandler extends EventHandler
        implements android.view.View.OnGenericMotionListener
    {

        public boolean onGenericMotion(View view, MotionEvent motionevent)
        {
            return getInputHandler().handle(motionevent);
        }

        protected void setViewListenersTo(EventHandler eventhandler)
        {
            super.setViewListenersTo(eventhandler);
            View view = getInputHandler().getView();
            if (view != null)
            {
                view.setOnGenericMotionListener((ApiLevel12.EventHandler)eventhandler);
            }
        }

        public ApiLevel12.EventHandler(ViewInputHandler viewinputhandler)
        {
            super(viewinputhandler);
        }
    }

    private static class EventHandler
        implements android.view.View.OnKeyListener, android.view.View.OnTouchListener
    {

        private ViewInputHandler fInputHandler;

        public ViewInputHandler getInputHandler()
        {
            return fInputHandler;
        }

        public boolean onKey(View view, int i, KeyEvent keyevent)
        {
            return fInputHandler.handle(keyevent);
        }

        public boolean onTouch(View view, MotionEvent motionevent)
        {
            return fInputHandler.handle(motionevent);
        }

        protected void setViewListenersTo(EventHandler eventhandler)
        {
            View view = fInputHandler.getView();
            if (view != null)
            {
                view.setOnKeyListener(eventhandler);
                view.setOnTouchListener(eventhandler);
            }
        }

        public void subscribe()
        {
            setViewListenersTo(this);
        }

        public void unsubscribe()
        {
            setViewListenersTo(null);
        }

        public EventHandler(ViewInputHandler viewinputhandler)
        {
            if (viewinputhandler == null)
            {
                throw new NullPointerException();
            } else
            {
                fInputHandler = viewinputhandler;
                return;
            }
        }
    }


    private EventHandler fEventHandler;
    private View fView;

    public ViewInputHandler()
    {
        if (android.os.Build.VERSION.SDK_INT >= 12)
        {
            fEventHandler = ApiLevel12.createEventHandlerWith(this);
        } else
        {
            fEventHandler = new EventHandler(this);
        }
        fView = null;
    }

    public View getView()
    {
        return fView;
    }

    public void setView(View view)
    {
        if (view != fView)
        {
            if (fView != null)
            {
                fEventHandler.unsubscribe();
            }
            fView = view;
            if (fView != null)
            {
                fEventHandler.subscribe();
                return;
            }
        }
    }
}
