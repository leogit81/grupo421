// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            AxisInfo

public class AxisInfoCollection
    implements Iterable
{

    private ArrayList fCollection;

    public AxisInfoCollection()
    {
        fCollection = new ArrayList();
    }

    public void add(AxisInfo axisinfo)
    {
        while (axisinfo == null || fCollection.indexOf(axisinfo) >= 0) 
        {
            return;
        }
        fCollection.add(axisinfo);
    }

    public void addAll(Iterable iterable)
    {
        if (iterable != null)
        {
            Iterator iterator1 = iterable.iterator();
            while (iterator1.hasNext()) 
            {
                add((AxisInfo)iterator1.next());
            }
        }
    }

    public void clear()
    {
        fCollection.clear();
    }

    public boolean contains(AxisInfo axisinfo)
    {
        if (axisinfo == null)
        {
            return false;
        } else
        {
            return fCollection.contains(axisinfo);
        }
    }

    public AxisInfo getByIndex(int i)
    {
        if (i < 0 || i >= fCollection.size())
        {
            return null;
        } else
        {
            return (AxisInfo)fCollection.get(i);
        }
    }

    public int indexOf(AxisInfo axisinfo)
    {
        if (axisinfo == null)
        {
            return -1;
        } else
        {
            return fCollection.indexOf(axisinfo);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public boolean remove(AxisInfo axisinfo)
    {
        if (axisinfo == null)
        {
            return false;
        } else
        {
            return fCollection.remove(axisinfo);
        }
    }

    public int size()
    {
        return fCollection.size();
    }
}
