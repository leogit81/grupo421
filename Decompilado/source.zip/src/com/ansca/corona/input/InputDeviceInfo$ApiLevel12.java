// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.InputDevice;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ansca.corona.input:
//            AxisInfoCollection, AxisSettings, InputDeviceType, AxisType, 
//            AxisInfo, InputDeviceTypeSet, InputDeviceInfo

private static class 
{

    public static AxisInfoCollection getAxisInfoFrom(InputDevice inputdevice, InputDeviceType inputdevicetype)
    {
        AxisInfoCollection axisinfocollection = new AxisInfoCollection();
        if (inputdevice != null && inputdevicetype != null)
        {
            AxisSettings axissettings = new AxisSettings();
            for (Iterator iterator = inputdevice.getMotionRanges().iterator(); iterator.hasNext();)
            {
                android.view.n n = (android.view.)iterator.next();
                if (n.Source() == inputdevicetype.toAndroidSourceId())
                {
                    AxisType axistype = AxisType.fromAndroidIntegerId(n.Axis());
                    boolean flag = true;
                    if (axistype == AxisType.VERTICAL_SCROLL || axistype == AxisType.HORIZONTAL_SCROLL)
                    {
                        flag = false;
                    } else
                    if (inputdevicetype == InputDeviceType.TRACKBALL && (axistype == AxisType.X || axistype == AxisType.Y))
                    {
                        flag = false;
                    }
                    axissettings.setType(AxisType.fromAndroidIntegerId(n.Axis()));
                    axissettings.setMinValue(n.Min());
                    axissettings.setMaxValue(n.Max());
                    axissettings.setAccuracy(n.Fuzz());
                    axissettings.setIsProvidingAbsoluteValues(flag);
                    axisinfocollection.add(AxisInfo.from(axissettings));
                }
            }

        }
        return axisinfocollection;
    }

    public static InputDeviceTypeSet getAxisSourcesFrom(InputDevice inputdevice)
    {
        InputDeviceTypeSet inputdevicetypeset = new InputDeviceTypeSet();
        if (inputdevice != null)
        {
            for (Iterator iterator = inputdevice.getMotionRanges().iterator(); iterator.hasNext(); inputdevicetypeset.add(InputDeviceType.fromAndroidSourceId(((android.view.romAndroidSourceId)iterator.next()).Source()))) { }
        }
        return inputdevicetypeset;
    }

    private ()
    {
    }
}
