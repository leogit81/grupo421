// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;

public class KeyPhase
{

    public static final KeyPhase DOWN = new KeyPhase(0, 0, "down");
    public static final KeyPhase UP = new KeyPhase(1, 1, "up");
    private int fAndroidNumericId;
    private int fCoronaNumericId;
    private String fCoronaStringId;

    private KeyPhase(int i, int j, String s)
    {
        fAndroidNumericId = i;
        fCoronaNumericId = j;
        fCoronaStringId = s;
    }

    public static KeyPhase from(KeyEvent keyevent)
    {
        if (keyevent == null)
        {
            throw new NullPointerException();
        } else
        {
            return fromKeyEventAction(keyevent.getAction());
        }
    }

    public static KeyPhase fromKeyEventAction(int i)
    {
        if (i == 1)
        {
            return UP;
        } else
        {
            return DOWN;
        }
    }

    public int toCoronaNumericId()
    {
        return fCoronaNumericId;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public int toKeyEventAction()
    {
        return fAndroidNumericId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

}
