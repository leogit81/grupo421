// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.lang.reflect.Field;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceTypeSet, ReadOnlyInputDeviceTypeSet

public class InputDeviceType
{
    private static class ApiLevel9
    {

        public static int getSourceIdFrom(InputEvent inputevent)
        {
            if (inputevent == null)
            {
                throw new NullPointerException();
            } else
            {
                return inputevent.getSource();
            }
        }

        private ApiLevel9()
        {
        }
    }


    public static final InputDeviceType DPAD;
    public static final InputDeviceType GAMEPAD;
    public static final InputDeviceType JOYSTICK;
    public static final InputDeviceType KEYBOARD;
    public static final InputDeviceType MOUSE;
    public static final InputDeviceType STYLUS;
    public static final InputDeviceType TOUCHPAD;
    public static final InputDeviceType TOUCHSCREEN;
    public static final InputDeviceType TRACKBALL;
    public static final InputDeviceType UNKNOWN;
    private static ReadOnlyInputDeviceTypeSet sTypeCollection;
    private int fAndroidSourceId;
    private int fCoronaIntegerId;
    private String fCoronaStringId;

    private InputDeviceType(int i, int j, String s)
    {
        fAndroidSourceId = i;
        fCoronaIntegerId = j;
        fCoronaStringId = s;
    }

    public static InputDeviceTypeSet collectionFromAndroidSourcesBitField(int i)
    {
        InputDeviceTypeSet inputdevicetypeset = new InputDeviceTypeSet();
        Iterator iterator = sTypeCollection.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            InputDeviceType inputdevicetype = (InputDeviceType)iterator.next();
            if (inputdevicetype != UNKNOWN && (i & inputdevicetype.toAndroidSourceId()) == inputdevicetype.toAndroidSourceId())
            {
                inputdevicetypeset.add(inputdevicetype);
            }
        } while (true);
        if (inputdevicetypeset.size() <= 0)
        {
            inputdevicetypeset.add(UNKNOWN);
        }
        return inputdevicetypeset;
    }

    public static InputDeviceType from(KeyEvent keyevent)
    {
        if (keyevent == null)
        {
            return null;
        }
        if (android.os.Build.VERSION.SDK_INT >= 9)
        {
            return fromAndroidSourceId(ApiLevel9.getSourceIdFrom(keyevent));
        } else
        {
            return KEYBOARD;
        }
    }

    public static InputDeviceType from(MotionEvent motionevent)
    {
        if (motionevent == null)
        {
            return null;
        }
        if (android.os.Build.VERSION.SDK_INT >= 9)
        {
            return fromAndroidSourceId(ApiLevel9.getSourceIdFrom(motionevent));
        } else
        {
            return TOUCHSCREEN;
        }
    }

    public static InputDeviceType fromAndroidSourceId(int i)
    {
        InputDeviceType inputdevicetype = UNKNOWN;
        Iterator iterator = sTypeCollection.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            InputDeviceType inputdevicetype1 = (InputDeviceType)iterator.next();
            if (inputdevicetype1 != UNKNOWN && (i & inputdevicetype1.toAndroidSourceId()) == inputdevicetype1.toAndroidSourceId() && inputdevicetype1.toAndroidSourceId() > inputdevicetype.toAndroidSourceId())
            {
                inputdevicetype = inputdevicetype1;
            }
        } while (true);
        return inputdevicetype;
    }

    public static ReadOnlyInputDeviceTypeSet getCollection()
    {
        return sTypeCollection;
    }

    public int hashCode()
    {
        return fAndroidSourceId;
    }

    public int toAndroidSourceId()
    {
        return fAndroidSourceId;
    }

    public int toCoronaIntegerId()
    {
        return fCoronaIntegerId;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

    static 
    {
        InputDeviceTypeSet inputdevicetypeset;
        UNKNOWN = new InputDeviceType(0, 0, "unknown");
        KEYBOARD = new InputDeviceType(257, 1, "keyboard");
        MOUSE = new InputDeviceType(8194, 2, "mouse");
        STYLUS = new InputDeviceType(16386, 3, "stylus");
        TRACKBALL = new InputDeviceType(0x10004, 4, "trackball");
        TOUCHPAD = new InputDeviceType(0x100008, 5, "touchpad");
        TOUCHSCREEN = new InputDeviceType(4098, 6, "touchscreen");
        JOYSTICK = new InputDeviceType(0x1000010, 7, "joystick");
        GAMEPAD = new InputDeviceType(1025, 8, "gamepad");
        DPAD = new InputDeviceType(513, 9, "directionalPad");
        sTypeCollection = null;
        inputdevicetypeset = new InputDeviceTypeSet();
        Field afield[];
        int i;
        int j;
        Field field;
        InputDeviceType inputdevicetype;
        try
        {
            afield = com/ansca/corona/input/InputDeviceType.getDeclaredFields();
            i = afield.length;
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        j = 0;
_L2:
        if (j >= i)
        {
            break; /* Loop/switch isn't completed */
        }
        field = afield[j];
        if (!field.getType().equals(com/ansca/corona/input/InputDeviceType))
        {
            break MISSING_BLOCK_LABEL_230;
        }
        inputdevicetype = (InputDeviceType)field.get(null);
        if (inputdevicetype == null)
        {
            break MISSING_BLOCK_LABEL_230;
        }
        inputdevicetypeset.add(inputdevicetype);
        j++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
        sTypeCollection = new ReadOnlyInputDeviceTypeSet(inputdevicetypeset);
    }
}
