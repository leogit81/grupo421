// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;
import com.ansca.corona.JavaToNativeShim;

public class KeyCode
{
    private static class ApiLevel12
    {

        public static String getSymbolicNameFromKeyCode(int i)
        {
            return KeyEvent.keyCodeToString(i);
        }

        private ApiLevel12()
        {
        }
    }


    private int fAndroidNumericId;
    private String fCoronaStringId;

    private KeyCode(int i)
    {
        fAndroidNumericId = i;
        fCoronaStringId = null;
    }

    public static KeyCode from(KeyEvent keyevent)
    {
        if (keyevent == null)
        {
            throw new NullPointerException();
        } else
        {
            return fromAndroidKeyCode(keyevent.getKeyCode());
        }
    }

    public static KeyCode fromAndroidKeyCode(int i)
    {
        return new KeyCode(i);
    }

    public int toAndroidKeyCode()
    {
        return fAndroidNumericId;
    }

    public String toAndroidSymbolicName()
    {
        if (android.os.Build.VERSION.SDK_INT >= 12)
        {
            return ApiLevel12.getSymbolicNameFromKeyCode(fAndroidNumericId);
        }
        if (fAndroidNumericId > 0 && fAndroidNumericId <= KeyEvent.getMaxKeyCode())
        {
            return Integer.toString(fAndroidNumericId);
        } else
        {
            return "KEYCODE_UNKNOWN";
        }
    }

    public String toCoronaStringId()
    {
        if (fCoronaStringId == null)
        {
            fCoronaStringId = JavaToNativeShim.getKeyNameFromKeyCode(fAndroidNumericId);
            if (fCoronaStringId == null)
            {
                fCoronaStringId = "unknown";
            }
        }
        return fCoronaStringId;
    }

    public String toString()
    {
        return toCoronaStringId();
    }
}
