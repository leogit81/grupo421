// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            TouchPhase, TouchPoint

public class TouchTracker
    implements Cloneable
{

    private static int sNextTouchId = 0;
    private int fDeviceId;
    private TouchPoint fLastPoint;
    private TouchPhase fPhase;
    private int fPointerId;
    private TouchPoint fStartPoint;
    private int fTouchId;

    public TouchTracker(int i, int j)
    {
        sNextTouchId = 1 + sNextTouchId;
        fTouchId = sNextTouchId;
        fDeviceId = i;
        fPointerId = j;
        reset();
    }

    public TouchTracker clone()
    {
        TouchTracker touchtracker;
        try
        {
            touchtracker = (TouchTracker)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return touchtracker;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public int getDeviceId()
    {
        return fDeviceId;
    }

    public TouchPoint getLastPoint()
    {
        return fLastPoint;
    }

    public TouchPhase getPhase()
    {
        return fPhase;
    }

    public int getPointerId()
    {
        return fPointerId;
    }

    public TouchPoint getStartPoint()
    {
        return fStartPoint;
    }

    public int getTouchId()
    {
        return fTouchId;
    }

    public boolean hasNotStarted()
    {
        return !hasStarted();
    }

    public boolean hasStarted()
    {
        return fStartPoint != null;
    }

    public void reset()
    {
        fStartPoint = null;
        fLastPoint = null;
        fPhase = null;
    }

    public void updateWith(TouchPoint touchpoint, TouchPhase touchphase)
    {
        if (touchpoint == null || touchphase == null)
        {
            throw new NullPointerException();
        }
        if (fStartPoint == null || touchphase == TouchPhase.BEGAN)
        {
            fStartPoint = touchpoint;
        }
        fLastPoint = touchpoint;
        fPhase = touchphase;
    }

}
