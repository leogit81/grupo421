// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            AxisType

public class AxisSettings
    implements Cloneable
{

    private float fAccuracy;
    private boolean fIsProvidingAbsoluteValues;
    private float fMaxValue;
    private float fMinValue;
    private AxisType fType;

    public AxisSettings()
    {
        fType = AxisType.UNKNOWN;
        fMinValue = -1F;
        fMaxValue = 1.0F;
        fAccuracy = 0.0F;
        fIsProvidingAbsoluteValues = true;
    }

    public AxisSettings clone()
    {
        AxisSettings axissettings;
        try
        {
            axissettings = (AxisSettings)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return axissettings;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean equals(AxisSettings axissettings)
    {
        while (axissettings == null || !axissettings.fType.equals(fType) || Math.abs(axissettings.fMinValue - fMinValue) > 0.001F || Math.abs(axissettings.fMaxValue - fMaxValue) > 0.001F || Math.abs(axissettings.fAccuracy - fAccuracy) > 0.001F || axissettings.fIsProvidingAbsoluteValues != fIsProvidingAbsoluteValues) 
        {
            return false;
        }
        return true;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof AxisSettings))
        {
            return false;
        } else
        {
            return equals((AxisSettings)obj);
        }
    }

    public float getAccuracy()
    {
        return fAccuracy;
    }

    public float getMaxValue()
    {
        return fMaxValue;
    }

    public float getMinValue()
    {
        return fMinValue;
    }

    public AxisType getType()
    {
        return fType;
    }

    public boolean isProvidingAbsoluteValues()
    {
        return fIsProvidingAbsoluteValues;
    }

    public void setAccuracy(float f)
    {
        fAccuracy = f;
    }

    public void setIsProvidingAbsoluteValues(boolean flag)
    {
        fIsProvidingAbsoluteValues = flag;
    }

    public void setMaxValue(float f)
    {
        fMaxValue = f;
    }

    public void setMinValue(float f)
    {
        fMinValue = f;
    }

    public void setType(AxisType axistype)
    {
        if (axistype == null)
        {
            axistype = AxisType.UNKNOWN;
        }
        fType = axistype;
    }
}
