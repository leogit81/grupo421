// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.InputDevice;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceServices

private static class 
{

    public static int[] fetchAndroidDeviceIds()
    {
        int ai[] = InputDevice.getDeviceIds();
        if (ai == null)
        {
            ai = new int[0];
        }
        return ai;
    }

    private ()
    {
    }
}
