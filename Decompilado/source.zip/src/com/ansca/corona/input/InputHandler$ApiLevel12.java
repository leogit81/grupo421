// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;

// Referenced classes of package com.ansca.corona.input:
//            InputHandler

private static class 
{

    public static float getAxisValueFrom(MotionEvent motionevent, int i)
    {
        if (motionevent == null)
        {
            throw new NullPointerException();
        } else
        {
            return motionevent.getAxisValue(i);
        }
    }

    private ()
    {
    }
}
