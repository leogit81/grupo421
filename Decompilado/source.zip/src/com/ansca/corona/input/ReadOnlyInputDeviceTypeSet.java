// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceTypeSet, InputDeviceType

public class ReadOnlyInputDeviceTypeSet
    implements Iterable
{

    private InputDeviceTypeSet fCollection;

    public ReadOnlyInputDeviceTypeSet(InputDeviceTypeSet inputdevicetypeset)
    {
        if (inputdevicetypeset == null)
        {
            inputdevicetypeset = new InputDeviceTypeSet();
        }
        fCollection = inputdevicetypeset;
    }

    public boolean contains(InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            return false;
        } else
        {
            return fCollection.contains(inputdevicetype);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public int size()
    {
        return fCollection.size();
    }

    public int toAndroidSourcesBitField()
    {
        return fCollection.toAndroidSourcesBitField();
    }
}
