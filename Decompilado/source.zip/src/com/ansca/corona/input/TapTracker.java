// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;

// Referenced classes of package com.ansca.corona.input:
//            TouchPoint, InputDeviceType, TouchPhase

public class TapTracker
    implements Cloneable
{
    private static class ApiLevel14
    {

        public static boolean isNonPrimaryMouseButtonDownFor(MotionEvent motionevent)
        {
            while (motionevent == null || (-2 & motionevent.getButtonState()) == 0) 
            {
                return false;
            }
            return true;
        }

        private ApiLevel14()
        {
        }
    }


    private int fDeviceId;
    private TouchPoint fFirstTouchBeganPoint;
    private long fLastTapTimestamp;
    private TouchPoint fLastTouchBeganPoint;
    private int fTapCount;
    private TouchPoint fTapPoint;

    public TapTracker(int i)
    {
        fDeviceId = i;
        reset();
    }

    private boolean areCoordinatesWithinTapBounds(TouchPoint touchpoint, TouchPoint touchpoint1)
    {
        if (touchpoint != null && touchpoint1 != null)
        {
            float f = Math.abs(touchpoint1.getX() - touchpoint.getX());
            float f1 = Math.abs(touchpoint1.getY() - touchpoint.getY());
            if (f <= 40F && f1 <= 40F)
            {
                return true;
            }
        }
        return false;
    }

    public TapTracker clone()
    {
        TapTracker taptracker;
        try
        {
            taptracker = (TapTracker)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return taptracker;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public int getDeviceId()
    {
        return fDeviceId;
    }

    public int getTapCount()
    {
        if (fTapPoint == null)
        {
            return 0;
        } else
        {
            return fTapCount;
        }
    }

    public TouchPoint getTapPoint()
    {
        return fTapPoint;
    }

    public boolean hasTapOccurred()
    {
        return fTapPoint != null;
    }

    public void reset()
    {
        fFirstTouchBeganPoint = null;
        fLastTouchBeganPoint = null;
        fLastTapTimestamp = 0L;
        fTapPoint = null;
        fTapCount = 0;
    }

    public void updateWith(MotionEvent motionevent)
    {
        if (motionevent == null)
        {
            throw new NullPointerException();
        }
        fTapPoint = null;
        if (motionevent.getDeviceId() == fDeviceId)
        {
            if (motionevent.getPointerCount() > 1)
            {
                reset();
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= 14 && InputDeviceType.from(motionevent) == InputDeviceType.MOUSE && ApiLevel14.isNonPrimaryMouseButtonDownFor(motionevent))
            {
                reset();
                return;
            }
            TouchPhase touchphase = TouchPhase.from(motionevent);
            if (touchphase != null)
            {
                updateWith(new TouchPoint(motionevent.getX(), motionevent.getY(), motionevent.getEventTime()), touchphase);
                return;
            }
        }
    }

    public void updateWith(TouchPoint touchpoint, TouchPhase touchphase)
    {
        if (touchpoint == null || touchphase == null)
        {
            throw new NullPointerException();
        }
        fTapPoint = null;
        if (touchphase != TouchPhase.BEGAN) goto _L2; else goto _L1
_L1:
        if (fFirstTouchBeganPoint == null)
        {
            fFirstTouchBeganPoint = touchpoint;
        }
        fLastTouchBeganPoint = touchpoint;
        if (!areCoordinatesWithinTapBounds(fLastTouchBeganPoint, fFirstTouchBeganPoint))
        {
            fTapCount = 0;
            fFirstTouchBeganPoint = fLastTouchBeganPoint;
        }
_L4:
        return;
_L2:
        if (fLastTouchBeganPoint == null || touchphase != TouchPhase.ENDED || !areCoordinatesWithinTapBounds(touchpoint, fLastTouchBeganPoint)) goto _L4; else goto _L3
_L3:
        if (touchpoint.getTimestamp() - fLastTapTimestamp <= 500L) goto _L6; else goto _L5
_L5:
        fTapCount = 1;
_L8:
        fLastTapTimestamp = touchpoint.getTimestamp();
        fTapPoint = touchpoint;
        fLastTouchBeganPoint = null;
        return;
_L6:
        if (fTapCount < 0x7fffffff)
        {
            fTapCount = 1 + fTapCount;
        }
        if (true) goto _L8; else goto _L7
_L7:
    }
}
