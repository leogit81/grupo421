// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceServices, InputDeviceMonitor, InputDeviceContext, InputDeviceInterfaceCollection, 
//            RaiseAxisEventTask, InputDeviceInfo, RaiseInputDeviceStatusChangedEventTask, AxisDataEventInfo, 
//            VibrationSettings, InputDeviceStatusEventInfo

private static class 
    implements , , 
{

    public static ing INSTANCE = new <init>();

    public void onAxisDataReceived(InputDeviceContext inputdevicecontext, AxisDataEventInfo axisdataeventinfo)
    {
_L2:
        return;
        if (inputdevicecontext == null || axisdataeventinfo == null || !InputDeviceServices.access$100().isRunning()) goto _L2; else goto _L1
_L1:
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterface inputdeviceinterface = InputDeviceServices.access$300().getByCoronaDeviceId(inputdevicecontext.getCoronaDeviceId());
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        if (inputdeviceinterface == null) goto _L2; else goto _L3
_L3:
        RaiseAxisEventTask raiseaxiseventtask = new RaiseAxisEventTask(inputdeviceinterface, axisdataeventinfo);
        HashMap hashmap = InputDeviceServices.access$000();
        hashmap;
        JVM INSTR monitorenter ;
        for (Iterator iterator = InputDeviceServices.access$000().values().iterator(); iterator.hasNext(); ((CoronaRuntimeTaskDispatcher)iterator.next()).send(raiseaxiseventtask)) { }
        break MISSING_BLOCK_LABEL_116;
        Exception exception1;
        exception1;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        hashmap;
        JVM INSTR monitorexit ;
    }

    public void onHandleVibrateRequest(InputDeviceContext inputdevicecontext, VibrationSettings vibrationsettings)
    {
        while (inputdevicecontext == null || android.os.ventHandler < 16 || !inputdevicecontext.getDeviceInfo().hasAndroidDeviceId()) 
        {
            return;
        }
        ing(inputdevicecontext.getDeviceInfo().getAndroidDeviceId(), vibrationsettings);
    }

    public void onStatusChanged(InputDeviceContext inputdevicecontext, InputDeviceStatusEventInfo inputdevicestatuseventinfo)
    {
_L2:
        return;
        if (inputdevicecontext == null || inputdevicestatuseventinfo == null || !InputDeviceServices.access$100().isRunning()) goto _L2; else goto _L1
_L1:
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterface inputdeviceinterface = InputDeviceServices.access$300().getByCoronaDeviceId(inputdevicecontext.getCoronaDeviceId());
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        if (inputdeviceinterface == null) goto _L2; else goto _L3
_L3:
        RaiseInputDeviceStatusChangedEventTask raiseinputdevicestatuschangedeventtask = new RaiseInputDeviceStatusChangedEventTask(inputdeviceinterface, inputdevicestatuseventinfo);
        HashMap hashmap = InputDeviceServices.access$000();
        hashmap;
        JVM INSTR monitorenter ;
        for (Iterator iterator = InputDeviceServices.access$000().values().iterator(); iterator.hasNext(); ((CoronaRuntimeTaskDispatcher)iterator.next()).send(raiseinputdevicestatuschangedeventtask)) { }
        break MISSING_BLOCK_LABEL_116;
        Exception exception1;
        exception1;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        hashmap;
        JVM INSTR monitorexit ;
    }


    public ()
    {
    }
}
