// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;

// Referenced classes of package com.ansca.corona.input:
//            TapTracker

private static class 
{

    public static boolean isNonPrimaryMouseButtonDownFor(MotionEvent motionevent)
    {
        while (motionevent == null || (-2 & motionevent.getButtonState()) == 0) 
        {
            return false;
        }
        return true;
    }

    private ()
    {
    }
}
