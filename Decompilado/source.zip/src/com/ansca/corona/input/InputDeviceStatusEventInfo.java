// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


public class InputDeviceStatusEventInfo
{
    public static class Settings
        implements Cloneable
    {

        private boolean fHasConnectionStateChanged;
        private boolean fWasReconfigured;

        public Settings clone()
        {
            Settings settings;
            try
            {
                settings = (Settings)super.clone();
            }
            catch (Exception exception)
            {
                return null;
            }
            return settings;
        }

        public volatile Object clone()
            throws CloneNotSupportedException
        {
            return clone();
        }

        public boolean hasConnectionStateChanged()
        {
            return fHasConnectionStateChanged;
        }

        public void setHasConnectionStateChanged(boolean flag)
        {
            fHasConnectionStateChanged = flag;
        }

        public void setWasReconfigured(boolean flag)
        {
            fWasReconfigured = flag;
        }

        public boolean wasReconfigured()
        {
            return fWasReconfigured;
        }

        public Settings()
        {
            fHasConnectionStateChanged = false;
            fWasReconfigured = false;
        }
    }


    private Settings fSettings;

    public InputDeviceStatusEventInfo(Settings settings)
    {
        if (settings == null)
        {
            throw new NullPointerException();
        } else
        {
            fSettings = settings.clone();
            return;
        }
    }

    public boolean hasConnectionStateChanged()
    {
        return fSettings.hasConnectionStateChanged();
    }

    public boolean wasReconfigured()
    {
        return fSettings.wasReconfigured();
    }
}
