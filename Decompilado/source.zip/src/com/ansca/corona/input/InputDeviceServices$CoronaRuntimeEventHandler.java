// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeListener;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import java.util.HashMap;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceServices, InputDeviceMonitor

private static class 
    implements CoronaRuntimeListener
{

    public void onExiting(CoronaRuntime coronaruntime)
    {
        synchronized (InputDeviceServices.access$000())
        {
            InputDeviceServices.access$000().remove(coronaruntime);
        }
        InputDeviceServices.access$100().stop();
        return;
        exception;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void onLoaded(CoronaRuntime coronaruntime)
    {
        synchronized (InputDeviceServices.access$000())
        {
            InputDeviceServices.access$000().put(coronaruntime, new CoronaRuntimeTaskDispatcher(coronaruntime));
        }
        return;
        exception;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void onResumed(CoronaRuntime coronaruntime)
    {
        InputDeviceServices.access$100().start();
    }

    public void onStarted(CoronaRuntime coronaruntime)
    {
        InputDeviceServices.access$100().start();
    }

    public void onSuspended(CoronaRuntime coronaruntime)
    {
        InputDeviceServices.access$100().stop();
    }

    public ()
    {
    }
}
