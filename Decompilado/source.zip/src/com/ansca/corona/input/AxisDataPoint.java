// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.SystemClock;

public class AxisDataPoint
{

    private long fTimestamp;
    private float fValue;

    public AxisDataPoint(float f)
    {
        this(f, SystemClock.uptimeMillis());
    }

    public AxisDataPoint(float f, long l)
    {
        fValue = f;
        fTimestamp = l;
    }

    public long getTimestamp()
    {
        return fTimestamp;
    }

    public float getValue()
    {
        return fValue;
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("(");
        stringbuilder.append(Float.toString(fValue));
        stringbuilder.append(", ");
        stringbuilder.append(Long.toString(fTimestamp));
        stringbuilder.append(")");
        return stringbuilder.toString();
    }
}
