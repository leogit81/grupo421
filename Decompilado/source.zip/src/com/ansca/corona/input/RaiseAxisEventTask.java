// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;

// Referenced classes of package com.ansca.corona.input:
//            AxisDataEventInfo, InputDeviceInterface

public class RaiseAxisEventTask
    implements CoronaRuntimeTask
{

    private AxisDataEventInfo fDataEventInfo;
    private InputDeviceInterface fDevice;

    public RaiseAxisEventTask(InputDeviceInterface inputdeviceinterface, AxisDataEventInfo axisdataeventinfo)
    {
        if (inputdeviceinterface == null || axisdataeventinfo == null)
        {
            throw new NullPointerException();
        } else
        {
            fDevice = inputdeviceinterface;
            fDataEventInfo = axisdataeventinfo;
            return;
        }
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        JavaToNativeShim.axisEvent(fDevice, fDataEventInfo);
    }
}
