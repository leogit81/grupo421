// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;

public class RaiseMouseEventTask
    implements CoronaRuntimeTask
{

    private boolean fIsMiddleButtonDown;
    private boolean fIsPrimaryButtonDown;
    private boolean fIsSecondaryButtonDown;
    private float fPointX;
    private float fPointY;
    private long fTimestamp;

    public RaiseMouseEventTask(float f, float f1, long l, boolean flag, boolean flag1, boolean flag2)
    {
        fPointX = f;
        fPointY = f1;
        fTimestamp = l;
        fIsPrimaryButtonDown = flag;
        fIsSecondaryButtonDown = flag1;
        fIsMiddleButtonDown = flag2;
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        JavaToNativeShim.mouseEvent((int)fPointX, (int)fPointY, fTimestamp, fIsPrimaryButtonDown, fIsSecondaryButtonDown, fIsMiddleButtonDown);
    }
}
