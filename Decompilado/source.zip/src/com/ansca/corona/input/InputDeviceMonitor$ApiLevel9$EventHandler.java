// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.Handler;
import android.os.Looper;
import android.view.InputDevice;
import com.ansca.corona.MessageBasedTimer;
import com.ansca.corona.TimeSpan;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceMonitor

private static class fLastAndroidDeviceIdArray extends fLastAndroidDeviceIdArray
    implements com.ansca.corona.ndler
{

    private int fLastAndroidDeviceIdArray[];
    private MessageBasedTimer fTimer;

    public void onTimerElapsed()
    {
        int ai[];
        int ai1[];
        int i;
        int j;
        ai = InputDevice.getDeviceIds();
        if (ai == null)
        {
            ai = new int[0];
        }
        ai1 = ai;
        i = ai1.length;
        j = 0;
_L2:
        if (j < i)
        {
            int l1 = ai1[j];
            boolean flag1 = true;
            int ai4[] = fLastAndroidDeviceIdArray;
            int i2 = ai4.length;
            int j2 = 0;
            do
            {
label0:
                {
                    if (j2 < i2)
                    {
                        if (l1 != ai4[j2])
                        {
                            break label0;
                        }
                        flag1 = false;
                    }
                    if (flag1)
                    {
                        InputDeviceMonitor.access$000(getDeviceMonitor(), l1);
                    }
                    j++;
                    continue; /* Loop/switch isn't completed */
                }
                j2++;
            } while (true);
        } else
        {
            int ai2[] = fLastAndroidDeviceIdArray;
            int k = ai2.length;
            int l = 0;
            do
            {
label1:
                {
                    if (l >= k)
                    {
                        break label1;
                    }
                    int i1 = ai2[l];
                    boolean flag = true;
                    int ai3[] = ai;
                    int j1 = ai3.length;
                    int k1 = 0;
                    do
                    {
label2:
                        {
                            if (k1 < j1)
                            {
                                if (ai3[k1] != i1)
                                {
                                    break label2;
                                }
                                flag = false;
                            }
                            if (flag)
                            {
                                InputDeviceMonitor.access$100(getDeviceMonitor(), i1);
                            }
                            l++;
                        }
                        if (true)
                        {
                            break;
                        }
                        k1++;
                    } while (true);
                }
            } while (true);
        }
        fLastAndroidDeviceIdArray = ai;
        return;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void subscribe()
    {
        fLastAndroidDeviceIdArray = InputDevice.getDeviceIds();
        if (fLastAndroidDeviceIdArray == null)
        {
            fLastAndroidDeviceIdArray = new int[0];
        }
        fTimer.start();
    }

    public void unsubscribe()
    {
        fTimer.stop();
    }

    public (InputDeviceMonitor inputdevicemonitor)
    {
        super(inputdevicemonitor);
        fTimer = new MessageBasedTimer();
        fTimer.setHandler(new Handler(Looper.getMainLooper()));
        fTimer.setInterval(TimeSpan.fromSeconds(1L));
        fTimer.setListener(this);
        fLastAndroidDeviceIdArray = new int[0];
    }
}
