// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.Vibrator;
import android.view.InputDevice;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceType, InputDeviceTypeSet, ReadOnlyInputDeviceTypeSet, AxisInfoCollection, 
//            ReadOnlyAxisInfoCollection, InputDeviceSettings, AxisSettings, AxisInfo, 
//            AxisType

public class InputDeviceInfo
{
    private static class ApiLevel12
    {

        public static AxisInfoCollection getAxisInfoFrom(InputDevice inputdevice, InputDeviceType inputdevicetype)
        {
            AxisInfoCollection axisinfocollection = new AxisInfoCollection();
            if (inputdevice != null && inputdevicetype != null)
            {
                AxisSettings axissettings = new AxisSettings();
                for (Iterator iterator = inputdevice.getMotionRanges().iterator(); iterator.hasNext();)
                {
                    android.view.InputDevice.MotionRange motionrange = (android.view.InputDevice.MotionRange)iterator.next();
                    if (motionrange.getSource() == inputdevicetype.toAndroidSourceId())
                    {
                        AxisType axistype = AxisType.fromAndroidIntegerId(motionrange.getAxis());
                        boolean flag = true;
                        if (axistype == AxisType.VERTICAL_SCROLL || axistype == AxisType.HORIZONTAL_SCROLL)
                        {
                            flag = false;
                        } else
                        if (inputdevicetype == InputDeviceType.TRACKBALL && (axistype == AxisType.X || axistype == AxisType.Y))
                        {
                            flag = false;
                        }
                        axissettings.setType(AxisType.fromAndroidIntegerId(motionrange.getAxis()));
                        axissettings.setMinValue(motionrange.getMin());
                        axissettings.setMaxValue(motionrange.getMax());
                        axissettings.setAccuracy(motionrange.getFuzz());
                        axissettings.setIsProvidingAbsoluteValues(flag);
                        axisinfocollection.add(AxisInfo.from(axissettings));
                    }
                }

            }
            return axisinfocollection;
        }

        public static InputDeviceTypeSet getAxisSourcesFrom(InputDevice inputdevice)
        {
            InputDeviceTypeSet inputdevicetypeset = new InputDeviceTypeSet();
            if (inputdevice != null)
            {
                for (Iterator iterator = inputdevice.getMotionRanges().iterator(); iterator.hasNext(); inputdevicetypeset.add(InputDeviceType.fromAndroidSourceId(((android.view.InputDevice.MotionRange)iterator.next()).getSource()))) { }
            }
            return inputdevicetypeset;
        }

        private ApiLevel12()
        {
        }
    }

    private static class ApiLevel16
    {

        public static String getPermanentStringIdFrom(InputDevice inputdevice)
        {
            String s = null;
            if (inputdevice != null)
            {
                s = inputdevice.getDescriptor();
            }
            if (s != null && s.length() <= 0)
            {
                s = null;
            }
            return s;
        }

        public static boolean isVibrationSupportedFor(InputDevice inputdevice)
        {
            if (inputdevice != null)
            {
                Vibrator vibrator = inputdevice.getVibrator();
                if (vibrator != null)
                {
                    return vibrator.hasVibrator();
                }
            }
            return false;
        }

        private ApiLevel16()
        {
        }
    }

    private static class ApiLevel9
    {

        private static InputDeviceInfo createDeviceInfoFor(InputDevice inputdevice, InputDeviceType inputdevicetype)
        {
            InputDeviceInfo inputdeviceinfo;
            if (inputdevice == null || inputdevicetype == null)
            {
                inputdeviceinfo = null;
            } else
            {
                inputdeviceinfo = new InputDeviceInfo();
                inputdeviceinfo.fAndroidDeviceId = inputdevice.getId();
                inputdeviceinfo.fDeviceType = inputdevicetype;
                inputdeviceinfo.fInputSources.add(inputdevicetype);
                inputdeviceinfo.fProductName = "";
                inputdeviceinfo.fDisplayName = inputdevice.getName();
                if (android.os.Build.VERSION.SDK_INT >= 16)
                {
                    inputdeviceinfo.fPermanentStringId = ApiLevel16.getPermanentStringIdFrom(inputdevice);
                    inputdeviceinfo.fCanVibrate = ApiLevel16.isVibrationSupportedFor(inputdevice);
                    return inputdeviceinfo;
                }
            }
            return inputdeviceinfo;
        }

        public static int[] fetchAndroidDeviceIds()
        {
            int ai[] = InputDevice.getDeviceIds();
            if (ai == null)
            {
                ai = new int[0];
            }
            return ai;
        }

        public static List fetchDeviceInfoFromAndroidDeviceId(int i)
        {
            ArrayList arraylist = new ArrayList();
            if (i > 0) goto _L2; else goto _L1
_L1:
            InputDevice inputdevice;
            return arraylist;
_L2:
            InputDeviceTypeSet inputdevicetypeset1;
            InputDeviceType inputdevicetype;
            InputDeviceInfo inputdeviceinfo;
            if ((inputdevice = InputDevice.getDevice(i)) == null)
            {
                continue; /* Loop/switch isn't completed */
            }
            int j = inputdevice.getSources();
            if (j == 0)
            {
                break; /* Loop/switch isn't completed */
            }
            InputDeviceTypeSet inputdevicetypeset = InputDeviceType.collectionFromAndroidSourcesBitField(j);
            Iterator iterator1;
            InputDeviceType inputdevicetype2;
            if (android.os.Build.VERSION.SDK_INT >= 12)
            {
                inputdevicetypeset1 = ApiLevel12.getAxisSourcesFrom(inputdevice);
                inputdevicetypeset.addAll(inputdevicetypeset1);
            } else
            {
                inputdevicetypeset1 = new InputDeviceTypeSet();
            }
            if (inputdevicetypeset1.size() <= 1) goto _L4; else goto _L3
_L3:
            inputdevicetype = InputDeviceType.fromAndroidSourceId(inputdevicetypeset1.toAndroidSourcesBitField());
            inputdevicetypeset1.remove(inputdevicetype);
_L6:
            if (inputdevicetype == null)
            {
                inputdevicetype = InputDeviceType.fromAndroidSourceId(j);
            }
            inputdevicetypeset.removeAll(inputdevicetypeset1);
            if (inputdevicetypeset.contains(InputDeviceType.KEYBOARD) && inputdevice.getKeyboardType() == 2)
            {
                inputdevicetypeset.remove(InputDeviceType.KEYBOARD);
                arraylist.add(createDeviceInfoFor(inputdevice, InputDeviceType.KEYBOARD));
            }
            inputdeviceinfo = createDeviceInfoFor(inputdevice, inputdevicetype);
            inputdeviceinfo.fInputSources.addAll(inputdevicetypeset);
            if (android.os.Build.VERSION.SDK_INT >= 12)
            {
                for (iterator1 = inputdevicetypeset.iterator(); iterator1.hasNext(); inputdeviceinfo.fAxisCollection.addAll(ApiLevel12.getAxisInfoFrom(inputdevice, inputdevicetype2)))
                {
                    inputdevicetype2 = (InputDeviceType)iterator1.next();
                }

            }
            break; /* Loop/switch isn't completed */
_L4:
            int k = inputdevicetypeset1.size();
            inputdevicetype = null;
            if (k == 1)
            {
                inputdevicetype = (InputDeviceType)inputdevicetypeset1.iterator().next();
                inputdevicetypeset1.clear();
            }
            if (true) goto _L6; else goto _L5
_L5:
            arraylist.add(inputdeviceinfo);
            Iterator iterator = inputdevicetypeset1.iterator();
            while (iterator.hasNext()) 
            {
                InputDeviceType inputdevicetype1 = (InputDeviceType)iterator.next();
                InputDeviceInfo inputdeviceinfo1 = createDeviceInfoFor(inputdevice, inputdevicetype1);
                if (android.os.Build.VERSION.SDK_INT >= 12)
                {
                    inputdeviceinfo1.fAxisCollection.addAll(ApiLevel12.getAxisInfoFrom(inputdevice, inputdevicetype1));
                }
                arraylist.add(inputdeviceinfo1);
            }
            if (true) goto _L1; else goto _L7
_L7:
            arraylist.add(createDeviceInfoFor(inputdevice, InputDeviceType.UNKNOWN));
            return arraylist;
        }

        private ApiLevel9()
        {
        }
    }


    private int fAndroidDeviceId;
    private AxisInfoCollection fAxisCollection;
    private boolean fCanVibrate;
    private InputDeviceType fDeviceType;
    private String fDisplayName;
    private InputDeviceTypeSet fInputSources;
    private String fPermanentStringId;
    private String fProductName;
    private ReadOnlyAxisInfoCollection fReadOnlyAxisCollection;
    private ReadOnlyInputDeviceTypeSet fReadOnlyInputSources;

    private InputDeviceInfo()
    {
        fDeviceType = InputDeviceType.UNKNOWN;
        fAndroidDeviceId = -1;
        fPermanentStringId = null;
        fProductName = "";
        fDisplayName = "";
        fCanVibrate = false;
        fInputSources = new InputDeviceTypeSet();
        fReadOnlyInputSources = new ReadOnlyInputDeviceTypeSet(fInputSources);
        fAxisCollection = new AxisInfoCollection();
        fReadOnlyAxisCollection = new ReadOnlyAxisInfoCollection(fAxisCollection);
    }


    static List collectionFromAllAndroidDevices()
    {
        ArrayList arraylist = new ArrayList();
        if (android.os.Build.VERSION.SDK_INT >= 9)
        {
            int ai[] = ApiLevel9.fetchAndroidDeviceIds();
            int i = ai.length;
            for (int j = 0; j < i; j++)
            {
                arraylist.addAll(ApiLevel9.fetchDeviceInfoFromAndroidDeviceId(ai[j]));
            }

        }
        return arraylist;
    }

    static List collectionFromAndroidDeviceId(int i)
    {
        if (android.os.Build.VERSION.SDK_INT >= 9)
        {
            return ApiLevel9.fetchDeviceInfoFromAndroidDeviceId(i);
        } else
        {
            return new ArrayList();
        }
    }

    public static InputDeviceInfo from(InputDeviceSettings inputdevicesettings)
    {
        InputDeviceInfo inputdeviceinfo;
        if (inputdevicesettings == null)
        {
            inputdeviceinfo = null;
        } else
        {
            inputdeviceinfo = new InputDeviceInfo();
            inputdeviceinfo.fDeviceType = inputdevicesettings.getType();
            inputdeviceinfo.fInputSources.add(inputdeviceinfo.fDeviceType);
            inputdeviceinfo.fPermanentStringId = inputdevicesettings.getPermanentStringId();
            inputdeviceinfo.fProductName = inputdevicesettings.getProductName();
            inputdeviceinfo.fDisplayName = inputdevicesettings.getDisplayName();
            Iterator iterator = inputdevicesettings.getAxes().iterator();
            while (iterator.hasNext()) 
            {
                AxisSettings axissettings = (AxisSettings)iterator.next();
                inputdeviceinfo.fAxisCollection.add(AxisInfo.from(axissettings));
            }
        }
        return inputdeviceinfo;
    }

    public boolean canVibrate()
    {
        return fCanVibrate;
    }

    public boolean equals(InputDeviceInfo inputdeviceinfo)
    {
_L2:
        return false;
        if (inputdeviceinfo == null || fPermanentStringId == null && inputdeviceinfo.fPermanentStringId != null || fPermanentStringId != null && inputdeviceinfo.fPermanentStringId == null || fPermanentStringId != null && !fPermanentStringId.equals(inputdeviceinfo.fPermanentStringId) || inputdeviceinfo.fDeviceType != fDeviceType || inputdeviceinfo.fAndroidDeviceId != fAndroidDeviceId || !inputdeviceinfo.fProductName.equals(fProductName) || !inputdeviceinfo.fDisplayName.equals(fDisplayName) || inputdeviceinfo.fCanVibrate != fCanVibrate || !inputdeviceinfo.fInputSources.equals(fInputSources) || inputdeviceinfo.fAxisCollection.size() != fAxisCollection.size()) goto _L2; else goto _L1
_L1:
        int i = 0;
label0:
        do
        {
label1:
            {
                if (i >= fAxisCollection.size())
                {
                    break label1;
                }
                if (!inputdeviceinfo.fAxisCollection.getByIndex(i).equals(fAxisCollection.getByIndex(i)))
                {
                    break label0;
                }
                i++;
            }
        } while (true);
        if (true) goto _L2; else goto _L3
_L3:
        return true;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof InputDeviceInfo))
        {
            return false;
        } else
        {
            return equals((InputDeviceInfo)obj);
        }
    }

    public int getAndroidDeviceId()
    {
        return fAndroidDeviceId;
    }

    public ReadOnlyAxisInfoCollection getAxes()
    {
        return fReadOnlyAxisCollection;
    }

    public String getDisplayName()
    {
        return fDisplayName;
    }

    public ReadOnlyInputDeviceTypeSet getInputSources()
    {
        return fReadOnlyInputSources;
    }

    public String getPermanentStringId()
    {
        return fPermanentStringId;
    }

    public String getProductName()
    {
        return fProductName;
    }

    public InputDeviceType getType()
    {
        return fDeviceType;
    }

    public boolean hasAndroidDeviceId()
    {
        return fAndroidDeviceId >= 0;
    }

    public boolean hasPermanentStringId()
    {
        return fPermanentStringId != null && fPermanentStringId.length() > 0;
    }




/*
    static int access$302(InputDeviceInfo inputdeviceinfo, int i)
    {
        inputdeviceinfo.fAndroidDeviceId = i;
        return i;
    }

*/


/*
    static InputDeviceType access$402(InputDeviceInfo inputdeviceinfo, InputDeviceType inputdevicetype)
    {
        inputdeviceinfo.fDeviceType = inputdevicetype;
        return inputdevicetype;
    }

*/


/*
    static String access$502(InputDeviceInfo inputdeviceinfo, String s)
    {
        inputdeviceinfo.fProductName = s;
        return s;
    }

*/


/*
    static String access$602(InputDeviceInfo inputdeviceinfo, String s)
    {
        inputdeviceinfo.fDisplayName = s;
        return s;
    }

*/


/*
    static String access$702(InputDeviceInfo inputdeviceinfo, String s)
    {
        inputdeviceinfo.fPermanentStringId = s;
        return s;
    }

*/


/*
    static boolean access$802(InputDeviceInfo inputdeviceinfo, boolean flag)
    {
        inputdeviceinfo.fCanVibrate = flag;
        return flag;
    }

*/
}
