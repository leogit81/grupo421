// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            TapTracker

public class TapTrackerCollection
    implements Iterable, Cloneable
{

    private ArrayList fCollection;

    public TapTrackerCollection()
    {
        fCollection = new ArrayList();
    }

    public void add(TapTracker taptracker)
    {
        while (taptracker == null || fCollection.indexOf(taptracker) >= 0) 
        {
            return;
        }
        fCollection.add(taptracker);
    }

    public void clear()
    {
        fCollection.clear();
    }

    public TapTrackerCollection clone()
    {
        TapTrackerCollection taptrackercollection = new TapTrackerCollection();
        TapTracker taptracker;
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext(); taptrackercollection.fCollection.add(taptracker.clone()))
        {
            taptracker = (TapTracker)iterator1.next();
        }

        return taptrackercollection;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean contains(TapTracker taptracker)
    {
        if (taptracker == null)
        {
            return false;
        } else
        {
            return fCollection.contains(taptracker);
        }
    }

    public boolean containsDeviceId(int i)
    {
        return getByDeviceId(i) != null;
    }

    public TapTracker getByDeviceId(int i)
    {
        for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext();)
        {
            TapTracker taptracker = (TapTracker)iterator1.next();
            if (taptracker != null && taptracker.getDeviceId() == i)
            {
                return taptracker;
            }
        }

        return null;
    }

    public TapTracker getByIndex(int i)
    {
        if (i < 0 || i >= fCollection.size())
        {
            return null;
        } else
        {
            return (TapTracker)fCollection.get(i);
        }
    }

    public int indexOf(TapTracker taptracker)
    {
        if (taptracker == null)
        {
            return -1;
        } else
        {
            return fCollection.indexOf(taptracker);
        }
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public boolean remove(TapTracker taptracker)
    {
        if (taptracker == null)
        {
            return false;
        } else
        {
            return fCollection.remove(taptracker);
        }
    }

    public boolean removeByDeviceId(int i)
    {
        boolean flag;
        for (flag = false; remove(getByDeviceId(i)); flag = true) { }
        return flag;
    }

    public int size()
    {
        return fCollection.size();
    }
}
