// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;

// Referenced classes of package com.ansca.corona.input:
//            KeyPhase, CoronaKeyEvent, InputDeviceInterface

public class RaiseKeyEventTask
    implements CoronaRuntimeTask
{
    private static class ApiLevel11
    {

        public static boolean isCapsLockOnFor(KeyEvent keyevent)
        {
            return keyevent.isCapsLockOn();
        }

        public static boolean isCtrlPressedFor(KeyEvent keyevent)
        {
            return keyevent.isCtrlPressed();
        }

        private ApiLevel11()
        {
        }
    }


    private InputDeviceInterface fDevice;
    private KeyEvent fKeyEvent;

    public RaiseKeyEventTask(InputDeviceInterface inputdeviceinterface, KeyEvent keyevent)
    {
        if (keyevent == null)
        {
            throw new NullPointerException();
        } else
        {
            fDevice = inputdeviceinterface;
            fKeyEvent = keyevent;
            return;
        }
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        CoronaActivity coronaactivity;
        if (fKeyEvent != null)
        {
            if ((coronaactivity = CoronaEnvironment.getCoronaActivity()) != null)
            {
                boolean flag = fKeyEvent.isShiftPressed();
                int i = android.os.Build.VERSION.SDK_INT;
                boolean flag1 = false;
                if (i >= 11)
                {
                    flag1 = ApiLevel11.isCtrlPressedFor(fKeyEvent);
                    flag |= ApiLevel11.isCapsLockOnFor(fKeyEvent);
                }
                if (!JavaToNativeShim.keyEvent(fDevice, KeyPhase.from(fKeyEvent), fKeyEvent.getKeyCode(), flag, fKeyEvent.isAltPressed(), flag1) && !(fKeyEvent instanceof CoronaKeyEvent))
                {
                    coronaactivity.runOnUiThread(new Runnable() {

                        final RaiseKeyEventTask this$0;

                        public void run()
                        {
                            CoronaActivity coronaactivity1;
                            for (coronaactivity1 = CoronaEnvironment.getCoronaActivity(); coronaactivity1 == null || coronaactivity1.isFinishing();)
                            {
                                return;
                            }

                            coronaactivity1.dispatchKeyEvent(new CoronaKeyEvent(fKeyEvent));
                        }

            
            {
                this$0 = RaiseKeyEventTask.this;
                super();
            }
                    });
                    return;
                }
            }
        }
    }

}
