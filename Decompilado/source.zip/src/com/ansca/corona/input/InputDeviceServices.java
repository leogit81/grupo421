// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.content.Context;
import android.os.Vibrator;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import com.ansca.corona.ApplicationContextProvider;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeListener;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceInterfaceCollection, InputDeviceMonitor, InputDeviceInfo, InputDeviceContext, 
//            InputDeviceInterface, ConnectionState, InputDeviceType, InputDeviceSettings, 
//            VibrationSettings, RaiseAxisEventTask, RaiseInputDeviceStatusChangedEventTask, AxisDataEventInfo, 
//            InputDeviceStatusEventInfo

public final class InputDeviceServices extends ApplicationContextProvider
{
    private static class ApiLevel16
    {

        public static void vibrateInputDeviceUsing(int i, VibrationSettings vibrationsettings)
        {
            InputDevice inputdevice = InputDevice.getDevice(i);
            Vibrator vibrator;
            if (inputdevice != null)
            {
                if ((vibrator = inputdevice.getVibrator()) != null && vibrator.hasVibrator())
                {
                    vibrator.vibrate(100L);
                    return;
                }
            }
        }

        private ApiLevel16()
        {
        }
    }

    private static class ApiLevel9
    {

        public static int[] fetchAndroidDeviceIds()
        {
            int ai[] = InputDevice.getDeviceIds();
            if (ai == null)
            {
                ai = new int[0];
            }
            return ai;
        }

        private ApiLevel9()
        {
        }
    }

    private static class CoronaRuntimeEventHandler
        implements CoronaRuntimeListener
    {

        public void onExiting(CoronaRuntime coronaruntime)
        {
            synchronized (InputDeviceServices.sTaskDispatcherMap)
            {
                InputDeviceServices.sTaskDispatcherMap.remove(coronaruntime);
            }
            InputDeviceServices.sDeviceMonitor.stop();
            return;
            exception;
            hashmap;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void onLoaded(CoronaRuntime coronaruntime)
        {
            synchronized (InputDeviceServices.sTaskDispatcherMap)
            {
                InputDeviceServices.sTaskDispatcherMap.put(coronaruntime, new CoronaRuntimeTaskDispatcher(coronaruntime));
            }
            return;
            exception;
            hashmap;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void onResumed(CoronaRuntime coronaruntime)
        {
            InputDeviceServices.sDeviceMonitor.start();
        }

        public void onStarted(CoronaRuntime coronaruntime)
        {
            InputDeviceServices.sDeviceMonitor.start();
        }

        public void onSuspended(CoronaRuntime coronaruntime)
        {
            InputDeviceServices.sDeviceMonitor.stop();
        }

        public CoronaRuntimeEventHandler()
        {
        }
    }

    private static class InputDeviceContextEventHandler
        implements InputDeviceContext.OnStatusChangedListener, InputDeviceContext.OnAxisDataReceivedListener, InputDeviceContext.VibrateRequestHandler
    {

        public static InputDeviceContextEventHandler INSTANCE = new InputDeviceContextEventHandler();

        public void onAxisDataReceived(InputDeviceContext inputdevicecontext, AxisDataEventInfo axisdataeventinfo)
        {
_L2:
            return;
            if (inputdevicecontext == null || axisdataeventinfo == null || !InputDeviceServices.sDeviceMonitor.isRunning()) goto _L2; else goto _L1
_L1:
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorenter ;
            InputDeviceInterface inputdeviceinterface = InputDeviceServices.sDeviceCollection.getByCoronaDeviceId(inputdevicecontext.getCoronaDeviceId());
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            if (inputdeviceinterface == null) goto _L2; else goto _L3
_L3:
            RaiseAxisEventTask raiseaxiseventtask = new RaiseAxisEventTask(inputdeviceinterface, axisdataeventinfo);
            HashMap hashmap = InputDeviceServices.sTaskDispatcherMap;
            hashmap;
            JVM INSTR monitorenter ;
            for (Iterator iterator = InputDeviceServices.sTaskDispatcherMap.values().iterator(); iterator.hasNext(); ((CoronaRuntimeTaskDispatcher)iterator.next()).send(raiseaxiseventtask)) { }
            break MISSING_BLOCK_LABEL_116;
            Exception exception1;
            exception1;
            hashmap;
            JVM INSTR monitorexit ;
            throw exception1;
            Exception exception;
            exception;
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            throw exception;
            hashmap;
            JVM INSTR monitorexit ;
        }

        public void onHandleVibrateRequest(InputDeviceContext inputdevicecontext, VibrationSettings vibrationsettings)
        {
            while (inputdevicecontext == null || android.os.Build.VERSION.SDK_INT < 16 || !inputdevicecontext.getDeviceInfo().hasAndroidDeviceId()) 
            {
                return;
            }
            ApiLevel16.vibrateInputDeviceUsing(inputdevicecontext.getDeviceInfo().getAndroidDeviceId(), vibrationsettings);
        }

        public void onStatusChanged(InputDeviceContext inputdevicecontext, InputDeviceStatusEventInfo inputdevicestatuseventinfo)
        {
_L2:
            return;
            if (inputdevicecontext == null || inputdevicestatuseventinfo == null || !InputDeviceServices.sDeviceMonitor.isRunning()) goto _L2; else goto _L1
_L1:
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorenter ;
            InputDeviceInterface inputdeviceinterface = InputDeviceServices.sDeviceCollection.getByCoronaDeviceId(inputdevicecontext.getCoronaDeviceId());
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            if (inputdeviceinterface == null) goto _L2; else goto _L3
_L3:
            RaiseInputDeviceStatusChangedEventTask raiseinputdevicestatuschangedeventtask = new RaiseInputDeviceStatusChangedEventTask(inputdeviceinterface, inputdevicestatuseventinfo);
            HashMap hashmap = InputDeviceServices.sTaskDispatcherMap;
            hashmap;
            JVM INSTR monitorenter ;
            for (Iterator iterator = InputDeviceServices.sTaskDispatcherMap.values().iterator(); iterator.hasNext(); ((CoronaRuntimeTaskDispatcher)iterator.next()).send(raiseinputdevicestatuschangedeventtask)) { }
            break MISSING_BLOCK_LABEL_116;
            Exception exception1;
            exception1;
            hashmap;
            JVM INSTR monitorexit ;
            throw exception1;
            Exception exception;
            exception;
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            throw exception;
            hashmap;
            JVM INSTR monitorexit ;
        }


        public InputDeviceContextEventHandler()
        {
        }
    }

    private static class InputDeviceMonitorEventHandler
        implements InputDeviceMonitor.Listener
    {

        public void onInputDeviceConnected(int i)
        {
            InputDeviceServices.updateCollectionWithAndroidDeviceId(i);
        }

        public void onInputDeviceDisconnected(int i)
        {
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorenter ;
            InputDeviceInterfaceCollection inputdeviceinterfacecollection = InputDeviceServices.sDeviceCollection.clone();
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            if (inputdeviceinterfacecollection == null)
            {
                return;
            }
            break MISSING_BLOCK_LABEL_24;
            Exception exception;
            exception;
            com/ansca/corona/input/InputDeviceServices;
            JVM INSTR monitorexit ;
            throw exception;
            Iterator iterator = inputdeviceinterfacecollection.iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator.next();
                if (inputdeviceinterface.getDeviceInfo().getAndroidDeviceId() == i)
                {
                    inputdeviceinterface.getContext().update(ConnectionState.DISCONNECTED);
                }
            } while (true);
            return;
        }

        public void onInputDeviceReconfigured(int i)
        {
            InputDeviceServices.updateCollectionWithAndroidDeviceId(i);
        }

        public InputDeviceMonitorEventHandler()
        {
        }
    }


    private static InputDeviceInterfaceCollection sDeviceCollection = new InputDeviceInterfaceCollection();
    private static InputDeviceMonitor sDeviceMonitor = null;
    private static int sNextCoronaDeviceId = 1;
    private static HashMap sTaskDispatcherMap = new HashMap();

    public InputDeviceServices(Context context)
    {
        super(context);
        if (sDeviceMonitor == null)
        {
            sDeviceMonitor = new InputDeviceMonitor(context);
            sDeviceMonitor.setListener(new InputDeviceMonitorEventHandler());
        }
        if (android.os.Build.VERSION.SDK_INT >= 9 && sDeviceCollection.size() <= 0)
        {
            fetchAll();
        }
    }

    private static InputDeviceContext add(InputDeviceInfo inputdeviceinfo)
    {
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        if (inputdeviceinfo != null)
        {
            break MISSING_BLOCK_LABEL_12;
        }
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return null;
        if (!inputdeviceinfo.hasAndroidDeviceId() || sDeviceCollection.getByAndroidDeviceIdAndType(inputdeviceinfo.getAndroidDeviceId(), inputdeviceinfo.getType()) == null)
        {
            break MISSING_BLOCK_LABEL_47;
        }
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return null;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        InputDeviceContext inputdevicecontext;
        int i = sNextCoronaDeviceId;
        sNextCoronaDeviceId = 1 + sNextCoronaDeviceId;
        inputdevicecontext = new InputDeviceContext(i, inputdeviceinfo);
        sDeviceCollection.add(new InputDeviceInterface(inputdevicecontext));
        inputdevicecontext.addListener(InputDeviceContextEventHandler.INSTANCE);
        if (inputdeviceinfo.hasAndroidDeviceId())
        {
            inputdevicecontext.setVibrateRequestHandler(InputDeviceContextEventHandler.INSTANCE);
        }
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return inputdevicecontext;
    }

    private static void updateCollection()
    {
        if (android.os.Build.VERSION.SDK_INT >= 9) goto _L2; else goto _L1
_L1:
        return;
_L2:
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterfaceCollection inputdeviceinterfacecollection = sDeviceCollection.clone();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        int ai[];
        Iterator iterator;
        if (inputdeviceinterfacecollection == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        ai = ApiLevel9.fetchAndroidDeviceIds();
        iterator = inputdeviceinterfacecollection.iterator();
_L4:
        InputDeviceInterface inputdeviceinterface;
        int k;
        int l;
        do
        {
            if (!iterator.hasNext())
            {
                break MISSING_BLOCK_LABEL_136;
            }
            inputdeviceinterface = (InputDeviceInterface)iterator.next();
        } while (!inputdeviceinterface.getDeviceInfo().hasAndroidDeviceId());
        k = ai.length;
        l = 0;
_L5:
        boolean flag = false;
        if (l < k)
        {
            int i1 = ai[l];
            if (inputdeviceinterface.getDeviceInfo().getAndroidDeviceId() != i1)
            {
                break MISSING_BLOCK_LABEL_130;
            }
            flag = true;
        }
        if (!flag)
        {
            inputdeviceinterface.getContext().update(ConnectionState.DISCONNECTED);
        }
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        l++;
          goto _L5
        int i = ai.length;
        int j = 0;
        while (j < i) 
        {
            updateCollectionWithAndroidDeviceId(ai[j]);
            j++;
        }
        if (true) goto _L1; else goto _L6
_L6:
    }

    private static void updateCollectionWithAndroidDeviceId(int i)
    {
        if (android.os.Build.VERSION.SDK_INT >= 9) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Iterator iterator = InputDeviceInfo.collectionFromAndroidDeviceId(i).iterator();
_L4:
        if (!iterator.hasNext())
        {
            break; /* Loop/switch isn't completed */
        }
        InputDeviceInfo inputdeviceinfo = (InputDeviceInfo)iterator.next();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterface inputdeviceinterface = sDeviceCollection.getByAndroidDeviceIdAndType(i, inputdeviceinfo.getType());
        if (inputdeviceinterface != null)
        {
            break MISSING_BLOCK_LABEL_86;
        }
        if (inputdeviceinfo.hasPermanentStringId())
        {
            inputdeviceinterface = sDeviceCollection.getByPermanentStringIdAndTypeAndDisplayName(inputdeviceinfo.getPermanentStringId(), inputdeviceinfo.getType(), inputdeviceinfo.getDisplayName());
        }
        if (inputdeviceinterface != null)
        {
            break MISSING_BLOCK_LABEL_121;
        }
        if (android.os.Build.VERSION.SDK_INT < 16)
        {
            inputdeviceinterface = sDeviceCollection.getBy(ConnectionState.DISCONNECTED).getByTypeAndDisplayName(inputdeviceinfo.getType(), inputdeviceinfo.getDisplayName());
        }
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        InputDeviceContext inputdevicecontext;
        inputdevicecontext = null;
        if (inputdeviceinterface != null)
        {
            inputdevicecontext = inputdeviceinterface.getContext();
        }
        if (inputdevicecontext != null)
        {
            break; /* Loop/switch isn't completed */
        }
        inputdevicecontext = add(inputdeviceinfo);
        if (inputdevicecontext == null) goto _L4; else goto _L3
_L3:
        inputdevicecontext.beginUpdate();
        inputdevicecontext.update(ConnectionState.CONNECTED);
        inputdevicecontext.update(inputdeviceinfo);
        inputdevicecontext.endUpdate();
        if (true) goto _L4; else goto _L5
_L5:
        if (true) goto _L1; else goto _L6
_L6:
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public InputDeviceContext add(InputDeviceSettings inputdevicesettings)
    {
        return add(InputDeviceInfo.from(inputdevicesettings));
    }

    public InputDeviceInterfaceCollection fetchAll()
    {
        updateCollection();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterfaceCollection inputdeviceinterfacecollection = sDeviceCollection.clone();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        if (inputdeviceinterfacecollection == null)
        {
            inputdeviceinterfacecollection = new InputDeviceInterfaceCollection();
        }
        return inputdeviceinterfacecollection;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public InputDeviceInterfaceCollection fetchByAndroidDeviceId(int i)
    {
        updateCollectionWithAndroidDeviceId(i);
        InputDeviceInterfaceCollection inputdeviceinterfacecollection = new InputDeviceInterfaceCollection();
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        Iterator iterator = sDeviceCollection.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            InputDeviceInterface inputdeviceinterface = (InputDeviceInterface)iterator.next();
            if (inputdeviceinterface.getDeviceInfo().hasAndroidDeviceId() && inputdeviceinterface.getDeviceInfo().getAndroidDeviceId() == i)
            {
                inputdeviceinterfacecollection.add(inputdeviceinterface);
            }
        } while (true);
        break MISSING_BLOCK_LABEL_83;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return inputdeviceinterfacecollection;
    }

    public InputDeviceInterface fetchByAndroidDeviceIdAndType(int i, InputDeviceType inputdevicetype)
    {
        if (inputdevicetype == null)
        {
            return null;
        }
        updateCollectionWithAndroidDeviceId(i);
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterface inputdeviceinterface = sDeviceCollection.getByAndroidDeviceIdAndType(i, inputdevicetype);
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return inputdeviceinterface;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public InputDeviceInterface fetchByCoronaDeviceId(int i)
    {
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorenter ;
        InputDeviceInterface inputdeviceinterface = sDeviceCollection.getByCoronaDeviceId(i);
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        return inputdeviceinterface;
        Exception exception;
        exception;
        com/ansca/corona/input/InputDeviceServices;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public InputDeviceInterface fetchDeviceFrom(KeyEvent keyevent)
    {
        if (keyevent == null)
        {
            return null;
        } else
        {
            return fetchByAndroidDeviceIdAndType(keyevent.getDeviceId(), InputDeviceType.from(keyevent));
        }
    }

    public InputDeviceInterface fetchDeviceFrom(MotionEvent motionevent)
    {
        if (motionevent == null)
        {
            return null;
        } else
        {
            return fetchByAndroidDeviceIdAndType(motionevent.getDeviceId(), InputDeviceType.from(motionevent));
        }
    }

    static 
    {
        CoronaEnvironment.addRuntimeListener(new CoronaRuntimeEventHandler());
    }




}
