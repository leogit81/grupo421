// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.KeyEvent;

// Referenced classes of package com.ansca.corona.input:
//            RaiseKeyEventTask

private static class _cls9
{

    public static boolean isCapsLockOnFor(KeyEvent keyevent)
    {
        return keyevent.isCapsLockOn();
    }

    public static boolean isCtrlPressedFor(KeyEvent keyevent)
    {
        return keyevent.isCtrlPressed();
    }

    private _cls9()
    {
    }
}
