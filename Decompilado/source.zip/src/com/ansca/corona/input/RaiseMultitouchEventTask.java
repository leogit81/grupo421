// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            TouchTrackerCollection, TouchTracker

public class RaiseMultitouchEventTask
    implements CoronaRuntimeTask
{

    private TouchTrackerCollection fTouchTrackers;

    public RaiseMultitouchEventTask(TouchTrackerCollection touchtrackercollection)
    {
        fTouchTrackers = touchtrackercollection.clone();
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        JavaToNativeShim.multitouchEventBegin();
        for (Iterator iterator = fTouchTrackers.iterator(); iterator.hasNext(); JavaToNativeShim.multitouchEventAdd((TouchTracker)iterator.next())) { }
        JavaToNativeShim.multitouchEventEnd();
    }
}
