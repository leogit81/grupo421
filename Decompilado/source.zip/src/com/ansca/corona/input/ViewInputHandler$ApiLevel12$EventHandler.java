// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;
import android.view.View;

// Referenced classes of package com.ansca.corona.input:
//            ViewInputHandler

private static class  extends 
    implements android.view.ntHandler
{

    public boolean onGenericMotion(View view, MotionEvent motionevent)
    {
        return getInputHandler().handle(motionevent);
    }

    protected void setViewListenersTo(getInputHandler getinputhandler)
    {
        super.enersTo(getinputhandler);
        View view = getInputHandler().getView();
        if (view != null)
        {
            view.setOnGenericMotionListener((getInputHandler)getinputhandler);
        }
    }

    public (ViewInputHandler viewinputhandler)
    {
        super(viewinputhandler);
    }
}
