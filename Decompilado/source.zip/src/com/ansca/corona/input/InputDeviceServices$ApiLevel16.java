// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.Vibrator;
import android.view.InputDevice;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceServices, VibrationSettings

private static class 
{

    public static void vibrateInputDeviceUsing(int i, VibrationSettings vibrationsettings)
    {
        InputDevice inputdevice = InputDevice.getDevice(i);
        Vibrator vibrator;
        if (inputdevice != null)
        {
            if ((vibrator = inputdevice.getVibrator()) != null && vibrator.hasVibrator())
            {
                vibrator.vibrate(100L);
                return;
            }
        }
    }

    private ()
    {
    }
}
