// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.JavaToNativeShim;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceInterface, InputDeviceStatusEventInfo

public class RaiseInputDeviceStatusChangedEventTask
    implements CoronaRuntimeTask
{

    private InputDeviceInterface fDevice;
    private InputDeviceStatusEventInfo fEventInfo;

    public RaiseInputDeviceStatusChangedEventTask(InputDeviceInterface inputdeviceinterface, InputDeviceStatusEventInfo inputdevicestatuseventinfo)
    {
        if (inputdeviceinterface == null || inputdevicestatuseventinfo == null)
        {
            throw new NullPointerException();
        } else
        {
            fDevice = inputdeviceinterface;
            fEventInfo = inputdevicestatuseventinfo;
            return;
        }
    }

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        JavaToNativeShim.inputDeviceStatusEvent(fDevice, fEventInfo);
    }
}
