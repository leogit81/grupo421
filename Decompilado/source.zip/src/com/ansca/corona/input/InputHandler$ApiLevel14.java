// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;

// Referenced classes of package com.ansca.corona.input:
//            InputHandler

private static class 
{

    public static boolean isMiddleMouseButtonPressedFor(MotionEvent motionevent)
    {
        while (motionevent == null || (4 & motionevent.getButtonState()) == 0) 
        {
            return false;
        }
        return true;
    }

    public static boolean isPrimaryMouseButtonPressedFor(MotionEvent motionevent)
    {
        while (motionevent == null || (1 & motionevent.getButtonState()) == 0) 
        {
            return false;
        }
        return true;
    }

    public static boolean isSecondaryMouseButtonPressedFor(MotionEvent motionevent)
    {
        while (motionevent == null || (2 & motionevent.getButtonState()) == 0) 
        {
            return false;
        }
        return true;
    }

    private ()
    {
    }
}
