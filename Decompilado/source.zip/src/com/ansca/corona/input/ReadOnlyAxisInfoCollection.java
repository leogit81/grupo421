// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import java.util.Iterator;

// Referenced classes of package com.ansca.corona.input:
//            AxisInfoCollection, AxisInfo

public class ReadOnlyAxisInfoCollection
    implements Iterable
{

    private AxisInfoCollection fCollection;

    public ReadOnlyAxisInfoCollection(AxisInfoCollection axisinfocollection)
    {
        if (axisinfocollection == null)
        {
            axisinfocollection = new AxisInfoCollection();
        }
        fCollection = axisinfocollection;
    }

    public boolean contains(AxisInfo axisinfo)
    {
        return fCollection.contains(axisinfo);
    }

    public AxisInfo getByIndex(int i)
    {
        return fCollection.getByIndex(i);
    }

    public int indexOf(AxisInfo axisinfo)
    {
        return fCollection.indexOf(axisinfo);
    }

    public Iterator iterator()
    {
        return fCollection.iterator();
    }

    public int size()
    {
        return fCollection.size();
    }
}
