// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.InputEvent;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceType

private static class 
{

    public static int getSourceIdFrom(InputEvent inputevent)
    {
        if (inputevent == null)
        {
            throw new NullPointerException();
        } else
        {
            return inputevent.getSource();
        }
    }

    private ()
    {
    }
}
