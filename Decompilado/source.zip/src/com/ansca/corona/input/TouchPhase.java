// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.view.MotionEvent;

public class TouchPhase
{

    public static final TouchPhase BEGAN = new TouchPhase(0, "began");
    public static final TouchPhase CANCELED = new TouchPhase(4, "cancelled");
    public static final TouchPhase ENDED = new TouchPhase(3, "ended");
    public static final TouchPhase MOVED = new TouchPhase(1, "moved");
    private int fCoronaNumericId;
    private String fCoronaStringId;

    private TouchPhase(int i, String s)
    {
        fCoronaNumericId = i;
        fCoronaStringId = s;
    }

    public static TouchPhase from(MotionEvent motionevent)
    {
        if (motionevent == null)
        {
            return null;
        }
        switch (0xff & motionevent.getAction())
        {
        case 4: // '\004'
        default:
            return null;

        case 0: // '\0'
        case 5: // '\005'
            return BEGAN;

        case 2: // '\002'
            return MOVED;

        case 1: // '\001'
        case 6: // '\006'
            return ENDED;

        case 3: // '\003'
            return CANCELED;
        }
    }

    public int toCoronaNumericId()
    {
        return fCoronaNumericId;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

}
