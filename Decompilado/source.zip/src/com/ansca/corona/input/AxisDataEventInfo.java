// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


// Referenced classes of package com.ansca.corona.input:
//            AxisDataPoint, InputDeviceInfo

public class AxisDataEventInfo
{

    private int fAxisIndex;
    private AxisDataPoint fDataPoint;
    private InputDeviceInfo fDeviceInfo;

    public AxisDataEventInfo(InputDeviceInfo inputdeviceinfo, int i, AxisDataPoint axisdatapoint)
    {
        if (inputdeviceinfo == null || axisdatapoint == null)
        {
            throw new NullPointerException();
        } else
        {
            fDeviceInfo = inputdeviceinfo;
            fAxisIndex = i;
            fDataPoint = axisdatapoint;
            return;
        }
    }

    public int getAxisIndex()
    {
        return fAxisIndex;
    }

    public AxisDataPoint getDataPoint()
    {
        return fDataPoint;
    }

    public InputDeviceInfo getDeviceInfo()
    {
        return fDeviceInfo;
    }
}
