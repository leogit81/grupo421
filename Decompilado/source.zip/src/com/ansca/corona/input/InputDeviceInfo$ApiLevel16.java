// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;

import android.os.Vibrator;
import android.view.InputDevice;

// Referenced classes of package com.ansca.corona.input:
//            InputDeviceInfo

private static class 
{

    public static String getPermanentStringIdFrom(InputDevice inputdevice)
    {
        String s = null;
        if (inputdevice != null)
        {
            s = inputdevice.getDescriptor();
        }
        if (s != null && s.length() <= 0)
        {
            s = null;
        }
        return s;
    }

    public static boolean isVibrationSupportedFor(InputDevice inputdevice)
    {
        if (inputdevice != null)
        {
            Vibrator vibrator = inputdevice.getVibrator();
            if (vibrator != null)
            {
                return vibrator.hasVibrator();
            }
        }
        return false;
    }

    private ()
    {
    }
}
