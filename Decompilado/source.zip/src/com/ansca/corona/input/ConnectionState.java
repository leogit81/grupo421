// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.input;


public class ConnectionState
{

    public static final ConnectionState CONNECTED = new ConnectionState(1, "connected");
    public static final ConnectionState CONNECTING = new ConnectionState(2, "connecting");
    public static final ConnectionState DISCONNECTED = new ConnectionState(0, "disconnected");
    public static final ConnectionState DISCONNECTING = new ConnectionState(3, "disconnecting");
    private int fCoronaIntegerId;
    private String fCoronaStringId;

    private ConnectionState(int i, String s)
    {
        fCoronaIntegerId = i;
        fCoronaStringId = s;
    }

    public int hashCode()
    {
        return fCoronaIntegerId;
    }

    public boolean isConnected()
    {
        return this == CONNECTED;
    }

    public int toCoronaIntegerId()
    {
        return fCoronaIntegerId;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

}
