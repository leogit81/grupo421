// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            CoronaSensorManager, Controller, TimeSpan

private class TimerHandler extends TimerHandler
{
    private class SensorHandler
        implements SensorEventListener
    {

        final CoronaSensorManager.AccelerometerMonitor this$1;

        public void onAccuracyChanged(Sensor sensor, int i)
        {
        }

        public void onSensorChanged(SensorEvent sensorevent)
        {
            if (sensorevent == null)
            {
                return;
            }
            if (!fHasSkippedFirstMeasurement)
            {
                fHasSkippedFirstMeasurement = true;
                return;
            } else
            {
                fLastSensorMeasurement.copyFrom(sensorevent);
                fHasReceivedMeasurement = true;
                return;
            }
        }

        private SensorHandler()
        {
            this$1 = CoronaSensorManager.AccelerometerMonitor.this;
            super();
        }

        SensorHandler(CoronaSensorManager._cls1 _pcls1)
        {
            this();
        }
    }

    private class TimerHandler
        implements MessageBasedTimer.Listener
    {

        final CoronaSensorManager.AccelerometerMonitor this$1;

        public void onTimerElapsed()
        {
            Controller controller;
            controller = Controller.getController();
            break MISSING_BLOCK_LABEL_4;
            if (controller != null && fHasReceivedMeasurement)
            {
                if (!fHasReceivedSample)
                {
                    fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                    fHasReceivedSample = true;
                    return;
                }
                long l = fLastSampleTimestamp + (0xf4240L * getInterval().getTotalMilliseconds()) / 2L;
                if (CoronaSensorManager.compareSensorTimestamps(fLastSensorMeasurement.timestamp, l) <= 0)
                {
                    fLastSensorMeasurement.timestamp = fLastSampleTimestamp + 0xf4240L * getInterval().getTotalMilliseconds();
                }
                double d = 1.0000000000000001E-09D * (double)CoronaSensorManager.subtractSensorTimestamps(fLastSensorMeasurement.timestamp, fLastSampleTimestamp);
                fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                boolean flag = controller.isNaturalOrientationPortrait();
                int i;
                int j;
                double d1;
                double d2;
                double d3;
                EventManager eventmanager;
                if (flag)
                {
                    i = 0;
                } else
                {
                    i = 1;
                }
                if (flag)
                {
                    j = 1;
                } else
                {
                    j = 0;
                }
                d1 = (double)(-fLastSensorMeasurement.values[i]) / 10D;
                d2 = (double)(-fLastSensorMeasurement.values[j]) / 10D;
                d3 = (double)(-fLastSensorMeasurement.values[2]) / 10D;
                if (!flag)
                {
                    d2 *= -1D;
                }
                eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.accelerometerEvent(d1, d2, d3, d);
                    return;
                }
            }
            return;
        }

        private TimerHandler()
        {
            this$1 = CoronaSensorManager.AccelerometerMonitor.this;
            super();
        }

        TimerHandler(CoronaSensorManager._cls1 _pcls1)
        {
            this();
        }
    }


    private boolean fHasReceivedMeasurement;
    private boolean fHasReceivedSample;
    private boolean fHasSkippedFirstMeasurement;
    private long fLastSampleTimestamp;
    private fHasReceivedSample fLastSensorMeasurement;
    final CoronaSensorManager this$0;

    public int getSensorType()
    {
        return 1;
    }

    protected void onStarting()
    {
        fHasSkippedFirstMeasurement = false;
        fHasReceivedMeasurement = false;
        fHasReceivedSample = false;
    }



/*
    static boolean access$1202(TimerHandler timerhandler, boolean flag)
    {
        timerhandler.fHasSkippedFirstMeasurement = flag;
        return flag;
    }

*/




/*
    static boolean access$1402(fHasSkippedFirstMeasurement fhasskippedfirstmeasurement, boolean flag)
    {
        fhasskippedfirstmeasurement.fHasReceivedMeasurement = flag;
        return flag;
    }

*/



/*
    static boolean access$1502(fHasReceivedMeasurement fhasreceivedmeasurement, boolean flag)
    {
        fhasreceivedmeasurement.fHasReceivedSample = flag;
        return flag;
    }

*/



/*
    static long access$1602(fHasReceivedSample fhasreceivedsample, long l)
    {
        fhasreceivedsample.fLastSampleTimestamp = l;
        return l;
    }

*/

    public TimerHandler()
    {
        this$0 = CoronaSensorManager.this;
        super(CoronaSensorManager.this);
        fLastSensorMeasurement = new it>(CoronaSensorManager.this);
        fLastSensorMeasurement.ues = (new float[] {
            0.0F, 0.0F, 0.0F
        });
        fHasSkippedFirstMeasurement = false;
        fHasReceivedMeasurement = false;
        fHasReceivedSample = false;
        fLastSampleTimestamp = 0L;
        setSensorListener(new SensorHandler(null));
        setTimerListener(new TimerHandler(null));
    }
}
