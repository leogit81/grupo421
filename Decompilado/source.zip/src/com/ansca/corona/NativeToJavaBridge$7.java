// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.purchasing.StoreProxy;

// Referenced classes of package com.ansca.corona:
//            NativeToJavaBridge, Controller, CoronaActivity

static final class val.storeName
    implements Runnable
{

    final String val$storeName;

    public void run()
    {
        this;
        JVM INSTR monitorenter ;
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity == null) goto _L2; else goto _L1
_L1:
        StoreProxy storeproxy;
        storeproxy = coronaactivity.getStore();
        if (val$storeName != null && val$storeName.length() > 0)
        {
            break MISSING_BLOCK_LABEL_43;
        }
        storeproxy.useDefaultStore();
_L4:
        storeproxy.enable();
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
        storeproxy.useStore(val$storeName);
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    (String s)
    {
        val$storeName = s;
        super();
    }
}
