// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.Window;

// Referenced classes of package com.ansca.corona:
//            Controller, CoronaActivity

class this._cls0
    implements Runnable
{

    final Controller this$0;

    public void run()
    {
        Window window = Controller.access$200(Controller.this).getWindow();
        if (window != null)
        {
            window.addFlags(128);
        }
    }

    y()
    {
        this$0 = Controller.this;
        super();
    }
}
