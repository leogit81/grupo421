// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.events.MediaPickerEvent;
import com.ansca.corona.events.VideoPickerEvent;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity

private class <init>
    implements <init>
{

    final CoronaActivity this$0;

    public MediaPickerEvent generateEvent(String s)
    {
        return new VideoPickerEvent(s);
    }

    public MediaPickerEvent generateEvent(String s, int i, long l)
    {
        return new VideoPickerEvent(s, i, l);
    }

    private ()
    {
        this$0 = CoronaActivity.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
