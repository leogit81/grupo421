// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Context;
import android.graphics.Rect;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.KeyListener;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.text.method.TextKeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.graphics.FontServices;
import com.ansca.corona.graphics.TypefaceSettings;
import com.ansca.corona.input.CoronaKeyEvent;
import com.ansca.corona.version.IAndroidVersionSpecific;

// Referenced classes of package com.ansca.corona:
//            Controller

public class CoronaEditText extends EditText
{

    private int editingAfter;
    private int editingBefore;
    private int editingNumDeleted;
    private int editingStart;
    private boolean isEditing;
    private boolean myClearingFocus;
    private String myCurrentText;
    private boolean myIsPassword;
    private TextKeyListener myKeyListener;
    private String myPreviousText;
    private int myTextColor;

    public CoronaEditText(Context context)
    {
        super(context);
        myIsPassword = false;
        myTextColor = 0;
        myClearingFocus = false;
        myPreviousText = null;
        myCurrentText = "";
        editingNumDeleted = 0;
        editingStart = 0;
        editingBefore = 0;
        editingAfter = 0;
        isEditing = false;
        myKeyListener = null;
        setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {

            final CoronaEditText this$0;

            public void onFocusChange(View view, boolean flag)
            {
                if (Controller.isValid() && getId() != 0)
                {
                    if (flag)
                    {
                        isEditing = true;
                    }
                    Controller.getEventManager().textEvent(getId(), flag, false);
                }
            }

            
            {
                this$0 = CoronaEditText.this;
                super();
            }
        });
        setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {

            final CoronaEditText this$0;

            public boolean onEditorAction(TextView textview, int i, KeyEvent keyevent)
            {
                boolean flag;
                if ((0x20000 & getInputType()) == 0)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (flag || i != 0)
                {
                    isEditing = false;
                    if (flag && getId() != 0 && Controller.isValid())
                    {
                        Controller.getEventManager().textEvent(getId(), false, true);
                        return false;
                    }
                }
                return false;
            }

            
            {
                this$0 = CoronaEditText.this;
                super();
            }
        });
        addTextChangedListener(new TextWatcher() {

            final CoronaEditText this$0;

            public void afterTextChanged(Editable editable)
            {
                myCurrentText = editable.toString();
                if (myCurrentText == null)
                {
                    myCurrentText = "";
                }
                if (isEditing && Controller.isValid() && getId() != 0)
                {
                    String s = null;
                    String s1 = null;
                    if (editable != null)
                    {
                        s1 = myCurrentText;
                        s = editable.subSequence(editingStart, editingStart + editingAfter).toString();
                    }
                    Controller.getEventManager().textEditingEvent(getId(), editingStart, editingNumDeleted, s, myPreviousText, s1);
                }
            }

            public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
            {
                if (isEditing)
                {
                    myPreviousText = new String(charsequence.toString());
                    editingNumDeleted = j;
                }
            }

            public void onTextChanged(CharSequence charsequence, int i, int j, int k)
            {
                if (isEditing)
                {
                    editingStart = i;
                    editingBefore = j;
                    editingAfter = k;
                }
            }

            
            {
                this$0 = CoronaEditText.this;
                super();
            }
        });
        myKeyListener = new TextKeyListener(android.text.method.TextKeyListener.Capitalize.NONE, false) {

            final CoronaEditText this$0;

            public int getInputType()
            {
                int i;
                if (myIsPassword)
                {
                    i = 1 | 0x80;
                } else
                {
                    i = true | false;
                }
                return i | Controller.getAndroidVersionSpecific().inputTypeFlagsNoSuggestions();
            }

            
            {
                this$0 = CoronaEditText.this;
                super(capitalize, flag);
            }
        };
        setKeyListener(myKeyListener);
        setOnKeyListener(new android.view.View.OnKeyListener() {

            final CoronaEditText this$0;

            public boolean onKey(View view, int i, KeyEvent keyevent)
            {
                if (i != 67 || (keyevent instanceof CoronaKeyEvent))
                {
                    return false;
                } else
                {
                    view.dispatchKeyEvent(new CoronaKeyEvent(keyevent));
                    return true;
                }
            }

            
            {
                this$0 = CoronaEditText.this;
                super();
            }
        });
        setTransformationMethod(SingleLineTransformationMethod.getInstance());
    }

    public void clearFocus()
    {
        myClearingFocus = true;
        super.clearFocus();
        myClearingFocus = false;
    }

    public String getTextString()
    {
        Looper looper = Looper.getMainLooper();
        if (looper == null || looper.getThread() != Thread.currentThread())
        {
            return myCurrentText;
        } else
        {
            return getText().toString();
        }
    }

    public String getTextViewAlign()
    {
        switch (7 & getGravity())
        {
        case 2: // '\002'
        case 4: // '\004'
        default:
            return "unknown";

        case 3: // '\003'
            return "left";

        case 5: // '\005'
            return "right";

        case 1: // '\001'
            return "center";
        }
    }

    public int getTextViewColor()
    {
        return myTextColor;
    }

    public String getTextViewInputType()
    {
        int i;
label0:
        {
label1:
            {
label2:
                {
                    String s = "unknown";
                    KeyListener keylistener = getKeyListener();
                    if (keylistener != null)
                    {
                        i = keylistener.getInputType();
                        switch (i & 0xf)
                        {
                        default:
                            s = "default";
                            break;

                        case 1: // '\001'
                            break label0;

                        case 2: // '\002'
                            break label2;

                        case 3: // '\003'
                            break label1;
                        }
                    }
                    return s;
                }
                return "number";
            }
            return "phone";
        }
        switch (i & 0xff0)
        {
        default:
            return "default";

        case 16: // '\020'
            return "url";

        case 32: // ' '
            return "email";
        }
    }

    public boolean getTextViewPassword()
    {
        return myIsPassword;
    }

    public float getTextViewSize()
    {
        return getTextSize();
    }

    public boolean isReadOnly()
    {
        return getKeyListener() == null;
    }

    public boolean requestFocus(int i, Rect rect)
    {
        if (myClearingFocus)
        {
            return false;
        } else
        {
            return super.requestFocus(i, rect);
        }
    }

    public void setReadOnly(boolean flag)
    {
        Object obj;
        if (flag)
        {
            obj = null;
        } else
        {
            obj = myKeyListener;
        }
        setKeyListener(((KeyListener) (obj)));
    }

    public void setText(CharSequence charsequence, android.widget.TextView.BufferType buffertype)
    {
        boolean flag = isEditing;
        isEditing = false;
        super.setText(charsequence, buffertype);
        isEditing = flag;
    }

    public void setTextViewAlign(String s)
    {
        byte byte0 = 3;
        if (!"left".equals(s)) goto _L2; else goto _L1
_L1:
        byte0 = 3;
_L4:
        setGravity(byte0 | 0x70 & getGravity());
        return;
_L2:
        if ("center".equals(s))
        {
            byte0 = 1;
        } else
        if ("right".equals(s))
        {
            byte0 = 5;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void setTextViewColor(int i)
    {
        myTextColor = i;
        setTextColor(i);
    }

    public void setTextViewFont(String s, float f, boolean flag)
    {
        TypefaceSettings typefacesettings = new TypefaceSettings();
        typefacesettings.setName(s);
        typefacesettings.setIsBold(flag);
        setTypeface((new FontServices(getContext())).fetchTypefaceFor(typefacesettings), typefacesettings.getAndroidTypefaceStyle());
        setTextSize(1, f);
    }

    public void setTextViewInputType(String s)
    {
        if (!"number".equals(s)) goto _L2; else goto _L1
_L1:
        int i = 2;
_L4:
        if (myIsPassword)
        {
            i |= 0x80;
        }
        int j = i | Controller.getAndroidVersionSpecific().inputTypeFlagsNoSuggestions();
        if (j != 0)
        {
            setInputType(j);
        }
        return;
_L2:
        if ("phone".equals(s))
        {
            i = 3;
        } else
        if ("url".equals(s))
        {
            i = 17;
        } else
        if ("email".equals(s))
        {
            i = 33;
        } else
        {
            i = 1;
            if (!myIsPassword)
            {
                i |= 0;
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void setTextViewPassword(boolean flag)
    {
        Object obj;
        if (flag)
        {
            obj = PasswordTransformationMethod.getInstance();
        } else
        {
            obj = SingleLineTransformationMethod.getInstance();
        }
        setTransformationMethod(((android.text.method.TransformationMethod) (obj)));
        myIsPassword = flag;
        setTextViewInputType("password");
    }

    public void setTextViewSize(float f)
    {
        setTextSize(1, f);
    }



/*
    static boolean access$002(CoronaEditText coronaedittext, boolean flag)
    {
        coronaedittext.isEditing = flag;
        return flag;
    }

*/



/*
    static String access$102(CoronaEditText coronaedittext, String s)
    {
        coronaedittext.myPreviousText = s;
        return s;
    }

*/



/*
    static int access$202(CoronaEditText coronaedittext, int i)
    {
        coronaedittext.editingNumDeleted = i;
        return i;
    }

*/



/*
    static String access$302(CoronaEditText coronaedittext, String s)
    {
        coronaedittext.myCurrentText = s;
        return s;
    }

*/



/*
    static int access$402(CoronaEditText coronaedittext, int i)
    {
        coronaedittext.editingStart = i;
        return i;
    }

*/



/*
    static int access$502(CoronaEditText coronaedittext, int i)
    {
        coronaedittext.editingAfter = i;
        return i;
    }

*/


/*
    static int access$602(CoronaEditText coronaedittext, int i)
    {
        coronaedittext.editingBefore = i;
        return i;
    }

*/

}
