// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.ansca.corona.events.EventManager;
import java.util.List;

// Referenced classes of package com.ansca.corona:
//            Controller, CoronaActivity, TimeSpan, MessageBasedTimer, 
//            CoronaEnvironment

class CoronaSensorManager
{
    private class AccelerometerMonitor extends SensorMonitor
    {

        private boolean fHasReceivedMeasurement;
        private boolean fHasReceivedSample;
        private boolean fHasSkippedFirstMeasurement;
        private long fLastSampleTimestamp;
        private SensorMeasurement fLastSensorMeasurement;
        final CoronaSensorManager this$0;

        public int getSensorType()
        {
            return 1;
        }

        protected void onStarting()
        {
            fHasSkippedFirstMeasurement = false;
            fHasReceivedMeasurement = false;
            fHasReceivedSample = false;
        }



/*
        static boolean access$1202(AccelerometerMonitor accelerometermonitor, boolean flag)
        {
            accelerometermonitor.fHasSkippedFirstMeasurement = flag;
            return flag;
        }

*/




/*
        static boolean access$1402(AccelerometerMonitor accelerometermonitor, boolean flag)
        {
            accelerometermonitor.fHasReceivedMeasurement = flag;
            return flag;
        }

*/



/*
        static boolean access$1502(AccelerometerMonitor accelerometermonitor, boolean flag)
        {
            accelerometermonitor.fHasReceivedSample = flag;
            return flag;
        }

*/



/*
        static long access$1602(AccelerometerMonitor accelerometermonitor, long l)
        {
            accelerometermonitor.fLastSampleTimestamp = l;
            return l;
        }

*/

        public AccelerometerMonitor()
        {
            this$0 = CoronaSensorManager.this;
            super();
            fLastSensorMeasurement = new SensorMeasurement();
            fLastSensorMeasurement.values = (new float[] {
                0.0F, 0.0F, 0.0F
            });
            fHasSkippedFirstMeasurement = false;
            fHasReceivedMeasurement = false;
            fHasReceivedSample = false;
            fLastSampleTimestamp = 0L;
            setSensorListener(new SensorHandler());
            setTimerListener(new TimerHandler());
        }
    }

    private class AccelerometerMonitor.SensorHandler
        implements SensorEventListener
    {

        final AccelerometerMonitor this$1;

        public void onAccuracyChanged(Sensor sensor, int i)
        {
        }

        public void onSensorChanged(SensorEvent sensorevent)
        {
            if (sensorevent == null)
            {
                return;
            }
            if (!fHasSkippedFirstMeasurement)
            {
                fHasSkippedFirstMeasurement = true;
                return;
            } else
            {
                fLastSensorMeasurement.copyFrom(sensorevent);
                fHasReceivedMeasurement = true;
                return;
            }
        }

        private AccelerometerMonitor.SensorHandler()
        {
            this$1 = AccelerometerMonitor.this;
            super();
        }

    }

    private class AccelerometerMonitor.TimerHandler
        implements MessageBasedTimer.Listener
    {

        final AccelerometerMonitor this$1;

        public void onTimerElapsed()
        {
            Controller controller;
            controller = Controller.getController();
            break MISSING_BLOCK_LABEL_4;
            if (controller != null && fHasReceivedMeasurement)
            {
                if (!fHasReceivedSample)
                {
                    fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                    fHasReceivedSample = true;
                    return;
                }
                long l = fLastSampleTimestamp + (0xf4240L * getInterval().getTotalMilliseconds()) / 2L;
                if (CoronaSensorManager.compareSensorTimestamps(fLastSensorMeasurement.timestamp, l) <= 0)
                {
                    fLastSensorMeasurement.timestamp = fLastSampleTimestamp + 0xf4240L * getInterval().getTotalMilliseconds();
                }
                double d = 1.0000000000000001E-09D * (double)CoronaSensorManager.subtractSensorTimestamps(fLastSensorMeasurement.timestamp, fLastSampleTimestamp);
                fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                boolean flag = controller.isNaturalOrientationPortrait();
                int i;
                int j;
                double d1;
                double d2;
                double d3;
                EventManager eventmanager;
                if (flag)
                {
                    i = 0;
                } else
                {
                    i = 1;
                }
                if (flag)
                {
                    j = 1;
                } else
                {
                    j = 0;
                }
                d1 = (double)(-fLastSensorMeasurement.values[i]) / 10D;
                d2 = (double)(-fLastSensorMeasurement.values[j]) / 10D;
                d3 = (double)(-fLastSensorMeasurement.values[2]) / 10D;
                if (!flag)
                {
                    d2 *= -1D;
                }
                eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.accelerometerEvent(d1, d2, d3, d);
                    return;
                }
            }
            return;
        }

        private AccelerometerMonitor.TimerHandler()
        {
            this$1 = AccelerometerMonitor.this;
            super();
        }

    }

    private class CoronaLocationListener
        implements LocationListener
    {

        private boolean fHasReceivedData;
        private boolean fSupportsGps;
        private boolean fSupportsNetwork;
        final CoronaSensorManager this$0;

        public void onLocationChanged(Location location)
        {
            if (location.getProvider().equals("gps") || !fHasReceivedData || !fSupportsGps || !myLocationManager.isProviderEnabled("gps"))
            {
                fHasReceivedData = true;
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.locationEvent(location.getLatitude(), location.getLongitude(), location.getAltitude(), location.getAccuracy(), location.getSpeed(), location.getBearing(), (double)location.getTime() / 1000D);
                    return;
                }
            }
        }

        public void onProviderDisabled(String s)
        {
        }

        public void onProviderEnabled(String s)
        {
        }

        public void onStatusChanged(String s, int i, Bundle bundle)
        {
        }

        public void setSupportsGps()
        {
            fSupportsGps = true;
        }

        public void setSupportsNetwork()
        {
            fSupportsNetwork = true;
        }

        private CoronaLocationListener()
        {
            this$0 = CoronaSensorManager.this;
            super();
            fHasReceivedData = false;
            fSupportsGps = false;
            fSupportsNetwork = false;
        }

    }

    private class GyroscopeMonitor extends SensorMonitor
    {

        private boolean fHasReceivedMeasurement;
        private boolean fHasReceivedSample;
        private boolean fHasSkippedFirstMeasurement;
        private long fLastSampleTimestamp;
        private SensorMeasurement fLastSensorMeasurement;
        final CoronaSensorManager this$0;

        public int getSensorType()
        {
            return 4;
        }

        protected void onStarting()
        {
            fHasSkippedFirstMeasurement = false;
            fHasReceivedMeasurement = false;
            fHasReceivedSample = false;
        }



/*
        static boolean access$1902(GyroscopeMonitor gyroscopemonitor, boolean flag)
        {
            gyroscopemonitor.fHasSkippedFirstMeasurement = flag;
            return flag;
        }

*/




/*
        static boolean access$2102(GyroscopeMonitor gyroscopemonitor, boolean flag)
        {
            gyroscopemonitor.fHasReceivedMeasurement = flag;
            return flag;
        }

*/



/*
        static boolean access$2202(GyroscopeMonitor gyroscopemonitor, boolean flag)
        {
            gyroscopemonitor.fHasReceivedSample = flag;
            return flag;
        }

*/



/*
        static long access$2302(GyroscopeMonitor gyroscopemonitor, long l)
        {
            gyroscopemonitor.fLastSampleTimestamp = l;
            return l;
        }

*/

        public GyroscopeMonitor()
        {
            this$0 = CoronaSensorManager.this;
            super();
            fLastSensorMeasurement = new SensorMeasurement();
            fLastSensorMeasurement.values = (new float[] {
                0.0F, 0.0F, 0.0F
            });
            fHasSkippedFirstMeasurement = false;
            fHasReceivedMeasurement = false;
            fHasReceivedSample = false;
            fLastSampleTimestamp = 0L;
            setSensorListener(new SensorHandler());
            setTimerListener(new TimerHandler());
        }
    }

    private class GyroscopeMonitor.SensorHandler
        implements SensorEventListener
    {

        final GyroscopeMonitor this$1;

        public void onAccuracyChanged(Sensor sensor, int i)
        {
        }

        public void onSensorChanged(SensorEvent sensorevent)
        {
            if (sensorevent == null)
            {
                return;
            }
            if (!fHasSkippedFirstMeasurement)
            {
                fHasSkippedFirstMeasurement = true;
                return;
            } else
            {
                fLastSensorMeasurement.copyFrom(sensorevent);
                fHasReceivedMeasurement = true;
                return;
            }
        }

        private GyroscopeMonitor.SensorHandler()
        {
            this$1 = GyroscopeMonitor.this;
            super();
        }

    }

    private class GyroscopeMonitor.TimerHandler
        implements MessageBasedTimer.Listener
    {

        final GyroscopeMonitor this$1;

        public void onTimerElapsed()
        {
            Controller controller;
            controller = Controller.getController();
            break MISSING_BLOCK_LABEL_4;
            if (controller != null && fHasReceivedMeasurement)
            {
                if (!fHasReceivedSample)
                {
                    fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                    fHasReceivedSample = true;
                    return;
                }
                long l = fLastSampleTimestamp + (0xf4240L * getInterval().getTotalMilliseconds()) / 2L;
                if (CoronaSensorManager.compareSensorTimestamps(fLastSensorMeasurement.timestamp, l) <= 0)
                {
                    fLastSensorMeasurement.timestamp = fLastSampleTimestamp + 0xf4240L * getInterval().getTotalMilliseconds();
                }
                double d = 1.0000000000000001E-09D * (double)CoronaSensorManager.subtractSensorTimestamps(fLastSensorMeasurement.timestamp, fLastSampleTimestamp);
                fLastSampleTimestamp = fLastSensorMeasurement.timestamp;
                boolean flag = controller.isNaturalOrientationPortrait();
                int i;
                int j;
                double d1;
                double d2;
                double d3;
                EventManager eventmanager;
                if (flag)
                {
                    i = 0;
                } else
                {
                    i = 1;
                }
                if (flag)
                {
                    j = 1;
                } else
                {
                    j = 0;
                }
                d1 = fLastSensorMeasurement.values[i];
                d2 = fLastSensorMeasurement.values[j];
                d3 = fLastSensorMeasurement.values[2];
                if (!flag)
                {
                    d2 *= -1D;
                }
                eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.gyroscopeEvent(d1, d2, d3, d);
                    return;
                }
            }
            return;
        }

        private GyroscopeMonitor.TimerHandler()
        {
            this$1 = GyroscopeMonitor.this;
            super();
        }

    }

    private class SensorMeasurement
    {

        public int accuracy;
        public Sensor sensor;
        final CoronaSensorManager this$0;
        public long timestamp;
        public float values[];

        public void copyFrom(SensorEvent sensorevent)
        {
            if (sensorevent != null)
            {
                accuracy = sensorevent.accuracy;
                sensor = sensorevent.sensor;
                timestamp = sensorevent.timestamp;
                if (values == null)
                {
                    values = new float[sensorevent.values.length];
                }
                int i = 0;
                while (i < values.length && i < sensorevent.values.length) 
                {
                    values[i] = sensorevent.values[i];
                    i++;
                }
            }
        }

        public SensorMeasurement()
        {
            this$0 = CoronaSensorManager.this;
            super();
            accuracy = 0;
            sensor = null;
            timestamp = 0L;
            values = null;
        }
    }

    private abstract class SensorMonitor
    {

        private boolean fIsRunning;
        private SensorEventListener fSensorListener;
        private MessageBasedTimer fTimer;
        final CoronaSensorManager this$0;

        private int getSensorDelay()
        {
            long l = fTimer.getInterval().getTotalMilliseconds();
            if (l >= 200L)
            {
                return 3;
            }
            if (l >= 60L)
            {
                return 2;
            }
            return l < 20L ? 0 : 1;
        }

        public TimeSpan getInterval()
        {
            return fTimer.getInterval();
        }

        public int getIntervalInHertz()
        {
            return (int)(1000L / fTimer.getInterval().getTotalMilliseconds());
        }

        public abstract int getSensorType();

        public boolean isRunning()
        {
            return fIsRunning;
        }

        protected void onStarting()
        {
        }

        protected void onStopped()
        {
        }

        public void setIntervalInHertz(int i)
        {
            TimeSpan timespan = TimeSpan.fromMilliseconds(1000 / i);
            if (!fTimer.getInterval().equals(timespan))
            {
                boolean flag = isRunning();
                if (flag)
                {
                    stop();
                }
                fTimer.setInterval(timespan);
                if (flag)
                {
                    start();
                    return;
                }
            }
        }

        protected void setSensorListener(SensorEventListener sensoreventlistener)
        {
            if (sensoreventlistener == null)
            {
                throw new NullPointerException();
            }
            if (sensoreventlistener != fSensorListener)
            {
                boolean flag = isRunning();
                if (flag)
                {
                    stop();
                }
                fSensorListener = sensoreventlistener;
                if (flag)
                {
                    start();
                    return;
                }
            }
        }

        protected void setTimerListener(MessageBasedTimer.Listener listener)
        {
            fTimer.setListener(listener);
        }

        public void start()
        {
            if (!isRunning()) goto _L2; else goto _L1
_L1:
            return;
_L2:
            onStarting();
            SensorManager sensormanager = (SensorManager)CoronaEnvironment.getApplicationContext().getSystemService("sensor");
            Sensor sensor = sensormanager.getDefaultSensor(getSensorType());
            sensormanager.registerListener(fSensorListener, sensor, getSensorDelay());
            fIsRunning = true;
            if (fTimer.getListener() == null) goto _L1; else goto _L3
_L3:
            CoronaActivity coronaactivity = Controller.getActivity();
            if (coronaactivity == null)
            {
                break MISSING_BLOCK_LABEL_84;
            }
            fTimer.setHandler(coronaactivity.getHandler());
            fTimer.start();
            return;
            Exception exception;
            exception;
            exception.printStackTrace();
            return;
        }

        public void stop()
        {
            if (!isRunning())
            {
                return;
            }
            try
            {
                ((SensorManager)CoronaEnvironment.getApplicationContext().getSystemService("sensor")).unregisterListener(fSensorListener);
                fTimer.stop();
                fIsRunning = false;
                onStopped();
                return;
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }

        public SensorMonitor()
        {
            this$0 = CoronaSensorManager.this;
            super();
            fSensorListener = null;
            fTimer = new MessageBasedTimer();
            fIsRunning = false;
            setIntervalInHertz(10);
        }
    }


    private AccelerometerMonitor myAccelerometerMonitor;
    private boolean myActiveSensors[];
    private GyroscopeMonitor myGyroscopeMonitor;
    private float myLastHeading;
    private CoronaLocationListener myLocationListener;
    private LocationManager myLocationManager;
    private double myLocationThreshold;
    private Sensor myOrientationSensor;
    private SensorEventListener myOrientationSensorListener;
    private SensorManager mySensorManager;

    CoronaSensorManager()
    {
        myActiveSensors = new boolean[6];
        myLocationThreshold = 0.0D;
        myLastHeading = -1F;
    }

    public static int compareSensorTimestamps(long l, long l1)
    {
        if (l1 == 0x8000000000000000L)
        {
            l1++;
        }
        long l2 = l - l1;
        if (l2 < 0L)
        {
            return -1;
        }
        return l2 != 0L ? 1 : 0;
    }

    private void startType(final int eventType)
    {
        CoronaActivity coronaactivity;
        if (mySensorManager != null && Controller.isValid())
        {
            if ((coronaactivity = Controller.getActivity()) != null)
            {
                coronaactivity.getHandler().post(new Runnable() {

                    final CoronaSensorManager this$0;
                    final int val$eventType;

                    public void run()
                    {
                        eventType;
                        JVM INSTR tableswitch 0 5: default 44
                    //                                   0 44
                    //                                   1 45
                    //                                   2 56
                    //                                   3 129
                    //                                   4 67
                    //                                   5 44;
                           goto _L1 _L1 _L2 _L3 _L4 _L5 _L1
_L1:
                        return;
_L2:
                        myAccelerometerMonitor.start();
                        return;
_L3:
                        myGyroscopeMonitor.start();
                        return;
_L5:
                        myOrientationSensor = mySensorManager.getDefaultSensor(3);
                        myOrientationSensorListener = new SensorEventListener() {

                            final _cls1 this$1;

                            public void onAccuracyChanged(Sensor sensor, int i)
                            {
                            }

                            public void onSensorChanged(SensorEvent sensorevent)
                            {
                                this;
                                JVM INSTR monitorenter ;
                                Controller controller = Controller.getController();
                                if (controller != null)
                                {
                                    break MISSING_BLOCK_LABEL_13;
                                }
                                this;
                                JVM INSTR monitorexit ;
                                return;
                                float f = sensorevent.values[0];
                                if (!controller.isNaturalOrientationPortrait())
                                {
                                    f -= 90F;
                                    if (f < 0.0F)
                                    {
                                        f += 360F;
                                    }
                                }
                                EventManager eventmanager;
                                if (myLastHeading == f)
                                {
                                    break MISSING_BLOCK_LABEL_103;
                                }
                                myLastHeading = f;
                                eventmanager = Controller.getEventManager();
                                if (eventmanager == null)
                                {
                                    break MISSING_BLOCK_LABEL_103;
                                }
                                eventmanager.headingEvent(myLastHeading);
                                this;
                                JVM INSTR monitorexit ;
                                return;
                                Exception exception;
                                exception;
                                this;
                                JVM INSTR monitorexit ;
                                throw exception;
                            }

            
            {
                this$1 = _cls1.this;
                super();
            }
                        };
                        mySensorManager.registerListener(myOrientationSensorListener, myOrientationSensor, 2);
                        return;
_L4:
                        CoronaActivity coronaactivity1 = Controller.getActivity();
                        if (coronaactivity1 != null)
                        {
                            PackageManager packagemanager = coronaactivity1.getPackageManager();
                            boolean flag = packagemanager.hasSystemFeature("android.hardware.location.gps");
                            boolean flag1 = packagemanager.hasSystemFeature("android.hardware.location.network");
                            if (!flag && !flag1)
                            {
                                Log.v("Corona", "Unable to set up location listener. This device is incapable of providing location data.");
                                return;
                            }
                            myLocationListener = new CoronaLocationListener();
                            boolean flag2 = false;
                            if (flag)
                            {
                                int i = coronaactivity1.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION");
                                flag2 = false;
                                if (i == 0)
                                {
                                    myLocationListener.setSupportsGps();
                                    myLocationManager.requestLocationUpdates("gps", 1000L, (float)myLocationThreshold, myLocationListener);
                                    flag2 = true;
                                }
                            }
                            if (flag1 && coronaactivity1.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0)
                            {
                                myLocationListener.setSupportsNetwork();
                                myLocationManager.requestLocationUpdates("network", 1000L, (float)myLocationThreshold, myLocationListener);
                                flag2 = true;
                            }
                            if (!flag2)
                            {
                                Log.v("Corona", (new StringBuilder()).append("Warning: ").append("This application does not have permission to read your current location.").toString());
                                Controller controller = Controller.getController();
                                if (controller != null)
                                {
                                    controller.showNativeAlert("Corona", "This application does not have permission to read your current location.", new String[] {
                                        "OK"
                                    });
                                    return;
                                }
                            }
                        }
                        if (true) goto _L1; else goto _L6
_L6:
                    }

            
            {
                this$0 = CoronaSensorManager.this;
                eventType = i;
                super();
            }
                });
                return;
            }
        }
    }

    private void stopType(final int eventType)
    {
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity == null)
        {
            return;
        } else
        {
            coronaactivity.getHandler().post(new Runnable() {

                final CoronaSensorManager this$0;
                final int val$eventType;

                public void run()
                {
                    eventType;
                    JVM INSTR tableswitch 0 5: default 44
                //                               0 44
                //                               1 45
                //                               2 56
                //                               3 114
                //                               4 67
                //                               5 44;
                       goto _L1 _L1 _L2 _L3 _L4 _L5 _L1
_L1:
                    return;
_L2:
                    myAccelerometerMonitor.stop();
                    return;
_L3:
                    myGyroscopeMonitor.stop();
                    return;
_L5:
                    if (myOrientationSensorListener != null)
                    {
                        mySensorManager.unregisterListener(myOrientationSensorListener);
                        myOrientationSensorListener = null;
                        myLastHeading = -1F;
                        return;
                    }
                    continue; /* Loop/switch isn't completed */
_L4:
                    if (myLocationListener != null)
                    {
                        myLocationManager.removeUpdates(myLocationListener);
                        myLocationListener = null;
                        return;
                    }
                    if (true) goto _L1; else goto _L6
_L6:
                }

            
            {
                this$0 = CoronaSensorManager.this;
                eventType = i;
                super();
            }
            });
            return;
        }
    }

    public static long subtractSensorTimestamps(long l, long l1)
    {
        if (l1 == 0x8000000000000000L)
        {
            l1++;
        }
        return l - l1;
    }

    public boolean hasAccelerometer()
    {
label0:
        {
            SensorManager sensormanager = mySensorManager;
            boolean flag = false;
            if (sensormanager != null)
            {
                if (mySensorManager.getSensorList(1).size() <= 0)
                {
                    break label0;
                }
                flag = true;
            }
            return flag;
        }
        return false;
    }

    public boolean hasGyroscope()
    {
label0:
        {
            SensorManager sensormanager = mySensorManager;
            boolean flag = false;
            if (sensormanager != null)
            {
                if (mySensorManager.getSensorList(4).size() <= 0)
                {
                    break label0;
                }
                flag = true;
            }
            return flag;
        }
        return false;
    }

    public void init()
    {
        if (Controller.isValid())
        {
            mySensorManager = (SensorManager)Controller.getActivity().getSystemService("sensor");
            myLocationManager = (LocationManager)Controller.getActivity().getSystemService("location");
            myAccelerometerMonitor = new AccelerometerMonitor();
            myGyroscopeMonitor = new GyroscopeMonitor();
            int i = 0;
            while (i < myActiveSensors.length) 
            {
                myActiveSensors[i] = false;
                i++;
            }
        }
    }

    public boolean isActive(int i)
    {
        return myActiveSensors[i];
    }

    public void pause()
    {
        for (int i = 0; i < 6; i++)
        {
            stopType(i);
        }

    }

    public void resume()
    {
        for (int i = 0; i < 6; i++)
        {
            if (myActiveSensors[i])
            {
                startType(i);
            }
        }

    }

    public void setAccelerometerInterval(int i)
    {
        myAccelerometerMonitor.setIntervalInHertz(i);
    }

    public void setEventNotification(int i, boolean flag)
    {
        if (flag)
        {
            start(i);
            return;
        } else
        {
            stop(i);
            return;
        }
    }

    public void setGyroscopeInterval(int i)
    {
        myGyroscopeMonitor.setIntervalInHertz(i);
    }

    public void setLocationAccuracy(double d)
    {
    }

    public void setLocationThreshold(double d)
    {
        myLocationThreshold = d;
    }

    public void start(int i)
    {
        if (myActiveSensors[i])
        {
            return;
        } else
        {
            startType(i);
            myActiveSensors[i] = true;
            return;
        }
    }

    public void stop()
    {
        for (int i = 0; i < 6; i++)
        {
            stop(i);
        }

    }

    public void stop(int i)
    {
        if (!myActiveSensors[i])
        {
            return;
        } else
        {
            stopType(i);
            myActiveSensors[i] = false;
            return;
        }
    }





/*
    static Sensor access$202(CoronaSensorManager coronasensormanager, Sensor sensor)
    {
        coronasensormanager.myOrientationSensor = sensor;
        return sensor;
    }

*/




/*
    static SensorEventListener access$402(CoronaSensorManager coronasensormanager, SensorEventListener sensoreventlistener)
    {
        coronasensormanager.myOrientationSensorListener = sensoreventlistener;
        return sensoreventlistener;
    }

*/



/*
    static float access$502(CoronaSensorManager coronasensormanager, float f)
    {
        coronasensormanager.myLastHeading = f;
        return f;
    }

*/



/*
    static CoronaLocationListener access$602(CoronaSensorManager coronasensormanager, CoronaLocationListener coronalocationlistener)
    {
        coronasensormanager.myLocationListener = coronalocationlistener;
        return coronalocationlistener;
    }

*/


}
