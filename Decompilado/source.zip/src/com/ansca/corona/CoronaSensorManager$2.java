// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.hardware.SensorManager;
import android.location.LocationManager;

// Referenced classes of package com.ansca.corona:
//            CoronaSensorManager

class val.eventType
    implements Runnable
{

    final CoronaSensorManager this$0;
    final int val$eventType;

    public void run()
    {
        val$eventType;
        JVM INSTR tableswitch 0 5: default 44
    //                   0 44
    //                   1 45
    //                   2 56
    //                   3 114
    //                   4 67
    //                   5 44;
           goto _L1 _L1 _L2 _L3 _L4 _L5 _L1
_L1:
        return;
_L2:
        CoronaSensorManager.access$000(CoronaSensorManager.this).stop();
        return;
_L3:
        CoronaSensorManager.access$100(CoronaSensorManager.this).stop();
        return;
_L5:
        if (CoronaSensorManager.access$400(CoronaSensorManager.this) != null)
        {
            CoronaSensorManager.access$300(CoronaSensorManager.this).unregisterListener(CoronaSensorManager.access$400(CoronaSensorManager.this));
            CoronaSensorManager.access$402(CoronaSensorManager.this, null);
            CoronaSensorManager.access$502(CoronaSensorManager.this, -1F);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (CoronaSensorManager.access$600(CoronaSensorManager.this) != null)
        {
            CoronaSensorManager.access$900(CoronaSensorManager.this).removeUpdates(CoronaSensorManager.access$600(CoronaSensorManager.this));
            CoronaSensorManager.access$602(CoronaSensorManager.this, null);
            return;
        }
        if (true) goto _L1; else goto _L6
_L6:
    }

    roscopeMonitor()
    {
        this$0 = final_coronasensormanager;
        val$eventType = I.this;
        super();
    }
}
