// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Intent;
import com.ansca.corona.purchasing.StoreActivity;

// Referenced classes of package com.ansca.corona:
//            Controller, WindowOrientation, CoronaActivity

class val.appStringId
    implements Runnable
{

    final Controller this$0;
    final String val$appStringId;

    public void run()
    {
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity == null)
        {
            return;
        }
        boolean flag = canShowActivityFor(new Intent(coronaactivity, com/ansca/corona/purchasing/StoreActivity));
        Intent intent = new Intent();
        if (WindowOrientation.fromCurrentWindowUsing(coronaactivity).isLandscape() && flag)
        {
            int i = coronaactivity.getStatusBarMode();
            boolean flag1 = false;
            if (i == 0)
            {
                flag1 = true;
            }
            intent.setClass(coronaactivity, com/ansca/corona/purchasing/StoreActivity);
            intent.putExtra("full_screen", flag1);
            intent.putExtra("nook_app_ean", val$appStringId);
            intent.setFlags(0x10000);
        } else
        {
            intent.setAction("com.bn.sdk.shop.details");
            intent.putExtra("product_details_ean", val$appStringId);
        }
        coronaactivity.startActivity(intent);
    }

    ()
    {
        this$0 = final_controller;
        val$appStringId = String.this;
        super();
    }
}
