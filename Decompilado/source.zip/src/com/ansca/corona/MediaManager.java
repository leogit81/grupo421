// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Handler;
import android.webkit.URLUtil;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.storage.FileContentProvider;
import com.ansca.corona.storage.FileServices;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package com.ansca.corona:
//            AudioRecorder, CoronaActivity, Controller, VideoActivity

public class MediaManager
{

    private static final int SOUNDPOOL_STREAMS = 4;
    private CoronaActivity myActivity;
    private AudioRecorder myAudioRecorder;
    private HashMap myIdToSoundPoolIdMap;
    private HashMap myMediaPlayers;
    private SoundPool mySoundPool;
    private int myVideoId;
    private float myVolume;

    public MediaManager(CoronaActivity coronaactivity)
    {
        myActivity = coronaactivity;
    }

    protected Uri createVideoURLFromString(String s)
    {
        String s1 = s.toLowerCase();
        Uri uri;
        if (URLUtil.isNetworkUrl(s) || s1.startsWith("rtsp:") || s1.startsWith("file:") || s1.startsWith("content:"))
        {
            uri = Uri.parse(s);
        } else
        {
            CoronaActivity coronaactivity = myActivity;
            if (coronaactivity == null)
            {
                return null;
            }
            uri = FileContentProvider.createContentUriForFile(coronaactivity, s);
        }
        return uri;
    }

    public AudioRecorder getAudioRecorder(int i)
    {
        if (myAudioRecorder == null)
        {
            myAudioRecorder = new AudioRecorder(myActivity.getHandler());
        }
        myAudioRecorder.setId(i);
        return myAudioRecorder;
    }

    public float getVolume(int i)
    {
        return myVolume;
    }

    public void init()
    {
        myIdToSoundPoolIdMap = new HashMap();
        mySoundPool = new SoundPool(4, 3, 0);
        myMediaPlayers = new HashMap();
    }

    public void loadEventSound(int i, String s)
    {
        CoronaActivity coronaactivity;
        if (s != null && s.length() > 0)
        {
            if ((coronaactivity = myActivity) != null)
            {
                onUsingAudio();
                FileServices fileservices = new FileServices(coronaactivity);
                if (fileservices.isAssetFile(s))
                {
                    android.content.res.AssetFileDescriptor assetfiledescriptor = fileservices.openAssetFileDescriptorFor(s);
                    if (assetfiledescriptor != null)
                    {
                        int k = mySoundPool.load(assetfiledescriptor, 1);
                        myIdToSoundPoolIdMap.put(Integer.valueOf(i), Integer.valueOf(k));
                        return;
                    }
                } else
                {
                    int j = mySoundPool.load(s, 1);
                    myIdToSoundPoolIdMap.put(Integer.valueOf(i), Integer.valueOf(j));
                    return;
                }
            }
        }
    }

    public void loadSound(final int id, String s)
    {
        boolean flag;
        onUsingAudio();
        if (s.startsWith("/"))
        {
            break MISSING_BLOCK_LABEL_29;
        }
        flag = s.startsWith("http:");
        MediaPlayer mediaplayer1;
        mediaplayer1 = null;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_125;
        }
        File file;
        if (URLUtil.isNetworkUrl(s))
        {
            break MISSING_BLOCK_LABEL_156;
        }
        file = new File(s);
        if (!file.exists())
        {
            System.err.println((new StringBuilder()).append("Could not load sound ").append(s).toString());
            return;
        }
        FileInputStream fileinputstream;
        MediaPlayer mediaplayer;
        Uri uri;
        try
        {
            fileinputstream = new FileInputStream(file);
            mediaplayer = new MediaPlayer();
        }
        catch (Exception exception)
        {
            return;
        }
        try
        {
            mediaplayer.setDataSource(fileinputstream.getFD());
            mediaplayer.setAudioStreamType(3);
            mediaplayer.prepare();
        }
        catch (Exception exception1)
        {
            return;
        }
        mediaplayer1 = mediaplayer;
        if (mediaplayer1 != null)
        {
            break MISSING_BLOCK_LABEL_175;
        }
        System.err.println((new StringBuilder()).append("Could not load sound ").append(s).toString());
        return;
        uri = Uri.parse(s);
        mediaplayer1 = MediaPlayer.create(Controller.getActivity(), uri);
        break MISSING_BLOCK_LABEL_125;
        mediaplayer1.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {

            final MediaManager this$0;
            final int val$id;

            public boolean onError(MediaPlayer mediaplayer2, int i, int j)
            {
                mediaplayer2.release();
                if (myMediaPlayers != null)
                {
                    myMediaPlayers.remove(new Integer(id));
                }
                if (Controller.isValid())
                {
                    Controller.getEventManager().soundEnded(id);
                }
                return true;
            }

            
            {
                this$0 = MediaManager.this;
                id = i;
                super();
            }
        });
        mediaplayer1.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {

            final MediaManager this$0;
            final int val$id;

            public void onCompletion(MediaPlayer mediaplayer2)
            {
                mediaplayer2.release();
                if (myMediaPlayers != null)
                {
                    myMediaPlayers.remove(new Integer(id));
                }
                if (Controller.isValid())
                {
                    Controller.getEventManager().soundEnded(id);
                }
            }

            
            {
                this$0 = MediaManager.this;
                id = i;
                super();
            }
        });
        myMediaPlayers.put(new Integer(id), mediaplayer1);
        return;
    }

    void onUsingAudio()
    {
        CoronaActivity coronaactivity;
        for (coronaactivity = myActivity; coronaactivity == null || coronaactivity.getVolumeControlStream() != 0x80000000;)
        {
            return;
        }

        coronaactivity.runOnUiThread(new Runnable() {

            final MediaManager this$0;

            public void run()
            {
                CoronaActivity coronaactivity1 = Controller.getActivity();
                if (coronaactivity1 != null)
                {
                    coronaactivity1.setVolumeControlStream(3);
                }
            }

            
            {
                this$0 = MediaManager.this;
                super();
            }
        });
    }

    public void pauseAll()
    {
        for (Iterator iterator = myMediaPlayers.keySet().iterator(); iterator.hasNext(); pauseMedia(((Integer)iterator.next()).intValue())) { }
        for (Iterator iterator1 = myIdToSoundPoolIdMap.keySet().iterator(); iterator1.hasNext(); pauseMedia(((Integer)iterator1.next()).intValue())) { }
    }

    public void pauseMedia(int i)
    {
        MediaPlayer mediaplayer;
        mediaplayer = (MediaPlayer)myMediaPlayers.get(Integer.valueOf(i));
        if (mediaplayer == null)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        mediaplayer.pause();
_L1:
        return;
        Integer integer = (Integer)myIdToSoundPoolIdMap.get(new Integer(i));
        if (integer != null)
        {
            mySoundPool.pause(integer.intValue());
            return;
        }
          goto _L1
        IllegalStateException illegalstateexception;
        illegalstateexception;
    }

    public void playMedia(int i, boolean flag)
    {
        onUsingAudio();
        MediaPlayer mediaplayer = (MediaPlayer)myMediaPlayers.get(new Integer(i));
        if (mediaplayer != null)
        {
            mediaplayer.setLooping(flag);
            mediaplayer.start();
        } else
        {
            Integer integer = (Integer)myIdToSoundPoolIdMap.get(new Integer(i));
            if (integer != null)
            {
                AudioManager audiomanager = (AudioManager)myActivity.getSystemService("audio");
                float f = (float)audiomanager.getStreamVolume(3) / (float)audiomanager.getStreamMaxVolume(3);
                if (mySoundPool.play(integer.intValue(), f, f, 1, 0, 1.0F) == 0)
                {
                    System.out.println((new StringBuilder()).append("playSound failed ").append(integer).toString());
                    return;
                }
            }
        }
    }

    public void playVideo(int i, final String path, final boolean mediaControlsEnabled)
    {
        CoronaActivity coronaactivity;
        for (coronaactivity = myActivity; coronaactivity == null || path == null || path.length() < 1;)
        {
            return;
        }

        pauseAll();
        myVideoId = i;
        coronaactivity.getHandler().post(new Runnable() {

            final MediaManager this$0;
            final boolean val$mediaControlsEnabled;
            final String val$path;

            public void run()
            {
                CoronaActivity coronaactivity1 = myActivity;
                MediaManager mediamanager;
                Uri uri;
                if (coronaactivity1 != null && Controller.isValid())
                {
                    if ((mediamanager = Controller.getMediaManager()) != null && (uri = mediamanager.createVideoURLFromString(path)) != null)
                    {
                        Intent intent = new Intent(coronaactivity1, com/ansca/corona/VideoActivity);
                        intent.putExtra("video_uri", uri.toString());
                        intent.putExtra("video_id", myVideoId);
                        intent.putExtra("media_controls_enabled", mediaControlsEnabled);
                        intent.setFlags(0x10000);
                        coronaactivity1.startActivity(intent);
                        return;
                    }
                }
            }

            
            {
                this$0 = MediaManager.this;
                path = s;
                mediaControlsEnabled = flag;
                super();
            }
        });
    }

    public void release()
    {
        if (mySoundPool != null)
        {
            mySoundPool.release();
            mySoundPool = null;
            myMediaPlayers = null;
            myIdToSoundPoolIdMap = null;
        }
    }

    public void resumeAll()
    {
        for (Iterator iterator = myMediaPlayers.keySet().iterator(); iterator.hasNext(); resumeMedia(((Integer)iterator.next()).intValue())) { }
        for (Iterator iterator1 = myIdToSoundPoolIdMap.keySet().iterator(); iterator1.hasNext(); resumeMedia(((Integer)iterator1.next()).intValue())) { }
    }

    public void resumeMedia(int i)
    {
        MediaPlayer mediaplayer;
        mediaplayer = (MediaPlayer)myMediaPlayers.get(Integer.valueOf(i));
        if (mediaplayer == null)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        mediaplayer.start();
_L1:
        return;
        Integer integer = (Integer)myIdToSoundPoolIdMap.get(new Integer(i));
        if (integer != null)
        {
            mySoundPool.resume(integer.intValue());
            return;
        }
          goto _L1
        IllegalStateException illegalstateexception;
        illegalstateexception;
    }

    public void setVolume(int i, float f)
    {
        if (f < 0.0F)
        {
            f = 0.0F;
        }
        if (f > 1.0F)
        {
            f = 1.0F;
        }
        MediaPlayer mediaplayer = (MediaPlayer)myMediaPlayers.get(new Integer(i));
        if (mediaplayer != null)
        {
            mediaplayer.setVolume(f, f);
        }
        myVolume = f;
    }

    public void stopMedia(int i)
    {
        MediaPlayer mediaplayer = (MediaPlayer)myMediaPlayers.get(new Integer(i));
        if (mediaplayer != null)
        {
            mediaplayer.stop();
        } else
        {
            Integer integer = (Integer)myIdToSoundPoolIdMap.get(new Integer(i));
            if (integer != null)
            {
                mySoundPool.stop(integer.intValue());
                return;
            }
        }
    }



}
