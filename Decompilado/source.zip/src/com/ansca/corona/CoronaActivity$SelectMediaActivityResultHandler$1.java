// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.storage.FileServices;
import java.io.File;

// Referenced classes of package com.ansca.corona:
//            CoronaEnvironment, Controller, CoronaActivity

class val.finalDestinationFile
    implements Runnable
{

    final val.finalUri this$0;
    final File val$finalDestinationFile;
    final Uri val$finalUri;

    public void run()
    {
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        FileServices fileservices;
        long l;
        boolean flag;
        fileservices = new FileServices(context);
        l = -1L;
        flag = false;
        String s3;
        boolean flag1;
        s3 = val$finalUri.getScheme();
        flag1 = "file".equals(s3);
        flag = false;
        if (!flag1) goto _L4; else goto _L3
_L3:
        File file2 = new File(val$finalUri.getPath());
        long l1;
        if (!file2.exists())
        {
            break MISSING_BLOCK_LABEL_399;
        }
        l1 = file2.length();
        File file;
        l = l1;
        file = file2;
_L7:
        String s = null;
        if (file != null)
        {
            s = fileservices.getExtensionFrom(file);
            if (!file.exists())
            {
                file = null;
            }
        }
        String s1 = "";
        EventManager eventmanager;
        int i;
        boolean flag2;
        String as[];
        Cursor cursor;
        String s4;
        File file3;
        if (file != null && file.exists())
        {
            if (val$finalDestinationFile != null)
            {
                File file1 = val$finalDestinationFile;
                if (fileservices.copyFile(file, file1))
                {
                    s1 = val$finalDestinationFile.getAbsolutePath();
                }
            } else
            {
                s1 = file.getAbsolutePath();
            }
        } else
        if (flag)
        {
            String s2 = cess._mth100(this._cls0.this);
            if (s != null)
            {
                s2 = s;
            }
            s1 = ndleContentUri(val$finalUri, val$finalDestinationFile, context, s2);
        }
        eventmanager = Controller.getEventManager();
        if (eventmanager == null) goto _L1; else goto _L5
_L5:
        i = CoronaActivity.access$200(s1);
        eventmanager.addEvent(nerateEvent(s1, i, l));
        return;
_L4:
        flag2 = "content".equals(s3);
        flag = false;
        file = null;
        if (!flag2) goto _L7; else goto _L6
_L6:
        flag = true;
        as = tColumns();
        cursor = context.getContentResolver().query(val$finalUri, as, null, null, null);
        cursor.moveToFirst();
        s4 = cursor.getString(cursor.getColumnIndex(as[0]));
        l = cursor.getLong(cursor.getColumnIndex(as[1]));
        cursor.close();
        file3 = new File(s4);
        file = file3;
          goto _L7
        Exception exception;
        exception;
        file = null;
          goto _L7
        Exception exception1;
        exception1;
        file = file2;
        flag = false;
          goto _L7
        file = file2;
        flag = false;
          goto _L7
    }

    ()
    {
        this$0 = final_;
        val$finalUri = uri;
        val$finalDestinationFile = File.this;
        super();
    }
}
