// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.os.Parcel;

// Referenced classes of package com.ansca.corona:
//            CoronaData

private static class <init>
    implements android.os.eator
{

    public <init> createFromParcel(Parcel parcel)
    {
        <init> <init>1 = new <init>();
        if (parcel.readByte() != 0)
        {
            <init>1.<init>((CoronaData)parcel.readParcelable(getClass().getClassLoader()));
        }
        return <init>1;
    }

    public volatile Object createFromParcel(Parcel parcel)
    {
        return createFromParcel(parcel);
    }

    public createFromParcel[] newArray(int i)
    {
        return new createFromParcel[i];
    }

    public volatile Object[] newArray(int i)
    {
        return newArray(i);
    }

    private _cls9()
    {
    }

    _cls9(_cls9 _pcls9)
    {
        this();
    }
}
