// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;

// Referenced classes of package com.ansca.corona:
//            CoronaSensorManager

private class <init>
    implements SensorEventListener
{

    final this._cls1 this$1;

    public void onAccuracyChanged(Sensor sensor, int i)
    {
    }

    public void onSensorChanged(SensorEvent sensorevent)
    {
        if (sensorevent == null)
        {
            return;
        }
        if (!<init>(this._cls1.this))
        {
            this._mth1(this._cls1.this, true);
            return;
        } else
        {
            this._mth1(this._cls1.this)._mth1(sensorevent);
            this._mth1(this._cls1.this, true);
            return;
        }
    }

    private I()
    {
        this$1 = this._cls1.this;
        super();
    }

    this._cls1(this._cls1 _pcls1_1)
    {
        this();
    }
}
