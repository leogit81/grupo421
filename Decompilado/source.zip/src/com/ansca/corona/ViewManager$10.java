// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaEditText, CoronaActivity

class val.focus
    implements Runnable
{

    final ViewManager this$0;
    final boolean val$focus;
    final int val$id;

    public void run()
    {
        int i = val$id;
        CoronaEditText coronaedittext = null;
        if (i != 0)
        {
            coronaedittext = (CoronaEditText)getDisplayObjectById(com/ansca/corona/CoronaEditText, val$id);
        }
        if (coronaedittext != null && val$focus)
        {
            coronaedittext.requestFocus();
            ((InputMethodManager)ViewManager.access$100(ViewManager.this).getSystemService("input_method")).showSoftInput(coronaedittext, 2);
            return;
        } else
        {
            ViewManager.access$400(ViewManager.this).requestFocus();
            ((InputMethodManager)ViewManager.access$100(ViewManager.this).getSystemService("input_method")).hideSoftInputFromWindow(ViewManager.access$400(ViewManager.this).getApplicationWindowToken(), 0);
            return;
        }
    }

    thodManager()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$focus = Z.this;
        super();
    }
}
