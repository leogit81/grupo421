// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Context;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

// Referenced classes of package com.ansca.corona:
//            MessageBasedTimer, TimeSpan, CoronaEnvironment, Controller, 
//            CoronaActivity, CoronaSensorManager

private abstract class setIntervalInHertz
{

    private boolean fIsRunning;
    private SensorEventListener fSensorListener;
    private MessageBasedTimer fTimer;
    final CoronaSensorManager this$0;

    private int getSensorDelay()
    {
        long l = fTimer.getInterval().getTotalMilliseconds();
        if (l >= 200L)
        {
            return 3;
        }
        if (l >= 60L)
        {
            return 2;
        }
        return l < 20L ? 0 : 1;
    }

    public TimeSpan getInterval()
    {
        return fTimer.getInterval();
    }

    public int getIntervalInHertz()
    {
        return (int)(1000L / fTimer.getInterval().getTotalMilliseconds());
    }

    public abstract int getSensorType();

    public boolean isRunning()
    {
        return fIsRunning;
    }

    protected void onStarting()
    {
    }

    protected void onStopped()
    {
    }

    public void setIntervalInHertz(int i)
    {
        TimeSpan timespan = TimeSpan.fromMilliseconds(1000 / i);
        if (!fTimer.getInterval().equals(timespan))
        {
            boolean flag = isRunning();
            if (flag)
            {
                stop();
            }
            fTimer.setInterval(timespan);
            if (flag)
            {
                start();
                return;
            }
        }
    }

    protected void setSensorListener(SensorEventListener sensoreventlistener)
    {
        if (sensoreventlistener == null)
        {
            throw new NullPointerException();
        }
        if (sensoreventlistener != fSensorListener)
        {
            boolean flag = isRunning();
            if (flag)
            {
                stop();
            }
            fSensorListener = sensoreventlistener;
            if (flag)
            {
                start();
                return;
            }
        }
    }

    protected void setTimerListener(start start1)
    {
        fTimer.setListener(start1);
    }

    public void start()
    {
        if (!isRunning()) goto _L2; else goto _L1
_L1:
        return;
_L2:
        onStarting();
        SensorManager sensormanager = (SensorManager)CoronaEnvironment.getApplicationContext().getSystemService("sensor");
        android.hardware.Sensor sensor = sensormanager.getDefaultSensor(getSensorType());
        sensormanager.registerListener(fSensorListener, sensor, getSensorDelay());
        fIsRunning = true;
        if (fTimer.getListener() == null) goto _L1; else goto _L3
_L3:
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity == null)
        {
            break MISSING_BLOCK_LABEL_84;
        }
        fTimer.setHandler(coronaactivity.getHandler());
        fTimer.start();
        return;
        Exception exception;
        exception;
        exception.printStackTrace();
        return;
    }

    public void stop()
    {
        if (!isRunning())
        {
            return;
        }
        try
        {
            ((SensorManager)CoronaEnvironment.getApplicationContext().getSystemService("sensor")).unregisterListener(fSensorListener);
            fTimer.stop();
            fIsRunning = false;
            onStopped();
            return;
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public ()
    {
        this$0 = CoronaSensorManager.this;
        super();
        fSensorListener = null;
        fTimer = new MessageBasedTimer();
        fIsRunning = false;
        setIntervalInHertz(10);
    }
}
