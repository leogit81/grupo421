// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.widget.AbsoluteLayout;
import com.ansca.corona.maps.MapView;
import java.util.ArrayList;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.top
    implements Runnable
{

    final ViewManager this$0;
    final int val$height;
    final int val$id;
    final int val$left;
    final int val$top;
    final int val$width;

    public void run()
    {
        if (ViewManager.access$100(ViewManager.this) == null || ViewManager.access$000(ViewManager.this) == null)
        {
            return;
        }
        MapView mapview = new MapView(ViewManager.access$100(ViewManager.this));
        mapview.setId(val$id);
        mapview.setTag(new ingObjectHashMap(ViewManager.this, null));
        android.widget.LayoutParams layoutparams = new android.widget.LayoutParams(val$width, val$height, val$left, val$top);
        ViewManager.access$000(ViewManager.this).addView(mapview, layoutparams);
        mapview.bringToFront();
        synchronized (ViewManager.access$300(ViewManager.this))
        {
            ViewManager.access$300(ViewManager.this).add(mapview);
        }
        return;
        exception;
        arraylist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    youtParams()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$width = j;
        val$height = k;
        val$left = l;
        val$top = I.this;
        super();
    }
}
