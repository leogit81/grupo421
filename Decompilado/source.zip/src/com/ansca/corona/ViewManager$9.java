// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaEditText

class val.size
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final float val$size;

    public void run()
    {
        CoronaEditText coronaedittext = (CoronaEditText)getDisplayObjectById(com/ansca/corona/CoronaEditText, val$id);
        if (coronaedittext == null)
        {
            return;
        } else
        {
            coronaedittext.setTextViewSize(val$size);
            return;
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$size = F.this;
        super();
    }
}
