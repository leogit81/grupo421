// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.events.RunnableEvent;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity, Controller, JavaToNativeShim

public class SystemMonitor
{
    private static class SystemEventHandler extends BroadcastReceiver
    {

        private SystemMonitor fMonitor;

        public void dispose()
        {
            fMonitor.getActivity().unregisterReceiver(this);
        }

        public void onReceive(Context context, Intent intent)
        {
            String s;
            if (intent != null)
            {
                if ((s = intent.getAction()) != null && s.length() > 0)
                {
                    if (s.equals("android.intent.action.SCREEN_OFF"))
                    {
                        fMonitor.fIsScreenOn = false;
                        fMonitor.getActivity().onScreenLockStateChanged(true);
                        return;
                    }
                    if (s.equals("android.intent.action.SCREEN_ON"))
                    {
                        fMonitor.fIsScreenOn = true;
                        fMonitor.getActivity().onScreenLockStateChanged(fMonitor.isScreenLocked());
                        return;
                    }
                    if (s.equals("android.intent.action.USER_PRESENT"))
                    {
                        fMonitor.getActivity().onScreenLockStateChanged(false);
                        return;
                    }
                    if (s.equals("android.media.RINGER_MODE_CHANGED"))
                    {
                        fMonitor.isSilentModeEnabled();
                        return;
                    }
                }
            }
        }

        public SystemEventHandler(SystemMonitor systemmonitor)
        {
            if (systemmonitor == null)
            {
                throw new NullPointerException();
            } else
            {
                fMonitor = systemmonitor;
                IntentFilter intentfilter = new IntentFilter();
                intentfilter.addAction("android.intent.action.SCREEN_OFF");
                intentfilter.addAction("android.intent.action.SCREEN_ON");
                intentfilter.addAction("android.intent.action.USER_PRESENT");
                intentfilter.addAction("android.media.RINGER_MODE_CHANGED");
                fMonitor.getActivity().registerReceiver(this, intentfilter);
                return;
            }
        }
    }


    private CoronaActivity fActivity;
    private boolean fIsLowOnMemory;
    private boolean fIsScreenOn;
    private boolean fIsSilentModeEnabled;
    private SystemEventHandler fSystemEventHandler;

    public SystemMonitor(CoronaActivity coronaactivity)
    {
        if (coronaactivity == null)
        {
            throw new NullPointerException();
        } else
        {
            fActivity = coronaactivity;
            fSystemEventHandler = null;
            fIsScreenOn = true;
            fIsLowOnMemory = false;
            fIsSilentModeEnabled = false;
            return;
        }
    }

    public CoronaActivity getActivity()
    {
        return fActivity;
    }

    public boolean isLowOnMemory()
    {
        android.app.ActivityManager.MemoryInfo memoryinfo = new android.app.ActivityManager.MemoryInfo();
        ((ActivityManager)fActivity.getSystemService("activity")).getMemoryInfo(memoryinfo);
        if (fIsLowOnMemory != memoryinfo.lowMemory)
        {
            fIsLowOnMemory = memoryinfo.lowMemory;
            EventManager eventmanager = Controller.getEventManager();
            if (fIsLowOnMemory && eventmanager != null)
            {
                eventmanager.addEvent(new RunnableEvent(new Runnable() {

                    final SystemMonitor this$0;

                    public void run()
                    {
                        if (Controller.isValid())
                        {
                            JavaToNativeShim.memoryWarningEvent();
                        }
                    }

            
            {
                this$0 = SystemMonitor.this;
                super();
            }
                }));
            }
        }
        return fIsLowOnMemory;
    }

    public boolean isRunning()
    {
        return fSystemEventHandler != null;
    }

    public boolean isScreenLocked()
    {
        return ((KeyguardManager)fActivity.getSystemService("keyguard")).inKeyguardRestrictedInputMode();
    }

    public boolean isScreenOff()
    {
        return !fIsScreenOn;
    }

    public boolean isScreenOn()
    {
        return fIsScreenOn;
    }

    public boolean isScreenUnlocked()
    {
        return !isScreenLocked();
    }

    public boolean isSilentModeEnabled()
    {
        boolean flag;
        if (((AudioManager)fActivity.getSystemService("audio")).getRingerMode() != 2)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag != fIsSilentModeEnabled)
        {
            fIsSilentModeEnabled = flag;
        }
        return fIsSilentModeEnabled;
    }

    public void start()
    {
        if (fSystemEventHandler == null)
        {
            fSystemEventHandler = new SystemEventHandler(this);
        }
    }

    public void stop()
    {
        if (fSystemEventHandler == null)
        {
            return;
        } else
        {
            fSystemEventHandler.dispose();
            fSystemEventHandler = null;
            fIsSilentModeEnabled = false;
            return;
        }
    }

    public void update()
    {
        isLowOnMemory();
    }


/*
    static boolean access$002(SystemMonitor systemmonitor, boolean flag)
    {
        systemmonitor.fIsScreenOn = flag;
        return flag;
    }

*/
}
