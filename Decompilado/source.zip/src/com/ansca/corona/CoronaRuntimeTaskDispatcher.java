// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.events.Event;
import com.ansca.corona.events.EventManager;
import com.naef.jnlua.LuaState;

// Referenced classes of package com.ansca.corona:
//            Controller, CoronaRuntime, CoronaRuntimeTask

public class CoronaRuntimeTaskDispatcher
{
    private static class TaskEvent extends Event
    {

        private CoronaRuntimeTask fTask;

        public void Send()
        {
            CoronaRuntime coronaruntime;
            if (fTask != null && Controller.isValid())
            {
                if ((coronaruntime = Controller.getRuntime()) != null && !coronaruntime.wasDisposed())
                {
                    fTask.executeUsing(coronaruntime);
                    return;
                }
            }
        }

        public TaskEvent(CoronaRuntimeTask coronaruntimetask)
        {
            if (coronaruntimetask == null)
            {
                throw new NullPointerException();
            } else
            {
                fTask = coronaruntimetask;
                return;
            }
        }
    }


    private CoronaRuntime fRuntime;

    public CoronaRuntimeTaskDispatcher(CoronaRuntime coronaruntime)
    {
        fRuntime = coronaruntime;
    }

    public CoronaRuntimeTaskDispatcher(LuaState luastate)
    {
        fRuntime = null;
        if (luastate != null)
        {
            CoronaRuntime coronaruntime = Controller.getRuntime();
            if (coronaruntime != null && coronaruntime.getLuaState() == luastate)
            {
                fRuntime = coronaruntime;
            }
        }
    }

    public boolean isRuntimeAvailable()
    {
        if (fRuntime == null)
        {
            return false;
        } else
        {
            return fRuntime.wasNotDisposed();
        }
    }

    public boolean isRuntimeUnavailable()
    {
        return !isRuntimeAvailable();
    }

    public void send(CoronaRuntimeTask coronaruntimetask)
    {
        if (coronaruntimetask == null)
        {
            throw new NullPointerException();
        }
        EventManager eventmanager;
        if (!isRuntimeUnavailable())
        {
            if ((eventmanager = Controller.getEventManager()) != null)
            {
                eventmanager.addEvent(new TaskEvent(coronaruntimetask));
                return;
            }
        }
    }
}
