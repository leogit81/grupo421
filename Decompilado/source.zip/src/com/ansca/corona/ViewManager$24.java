// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaVideoView

class val.toggle
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final boolean val$toggle;

    public void run()
    {
        CoronaVideoView coronavideoview = (CoronaVideoView)getDisplayObjectById(com/ansca/corona/CoronaVideoView, val$id);
        if (coronavideoview != null)
        {
            coronavideoview.touchTogglesPlay(val$toggle);
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$toggle = Z.this;
        super();
    }
}
