// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            AudioRecorder, JavaToNativeShim

class val.status
    implements Runnable
{

    final AudioRecorder this$0;
    final int val$status;

    public void run()
    {
        JavaToNativeShim.recordCallback(val$status, AudioRecorder.access$200(AudioRecorder.this));
    }

    ()
    {
        this$0 = final_audiorecorder;
        val$status = I.this;
        super();
    }
}
