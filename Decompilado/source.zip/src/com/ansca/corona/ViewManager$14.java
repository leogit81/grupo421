// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.visible
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final boolean val$visible;

    public void run()
    {
        View view;
label0:
        {
            view = getDisplayObjectById(val$id);
            if (view != null)
            {
                int i;
                if (val$visible)
                {
                    i = 0;
                } else
                {
                    i = 8;
                }
                view.setVisibility(i);
                if (!val$visible)
                {
                    break label0;
                }
                setDisplayObjectAlpha(val$id, getDisplayObjectAlpha(val$id));
            }
            return;
        }
        view.setAnimation(null);
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$visible = Z.this;
        super();
    }
}
