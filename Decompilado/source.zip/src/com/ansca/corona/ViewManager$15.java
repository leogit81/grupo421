// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.top
    implements Runnable
{

    final ViewManager this$0;
    final int val$height;
    final int val$id;
    final int val$left;
    final int val$top;
    final int val$width;

    public void run()
    {
        View view = getDisplayObjectById(val$id);
        if (view != null)
        {
            view.setLayoutParams(new android.widget.LayoutParams(val$width, val$height, val$left, val$top));
        }
    }

    youtParams()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$width = j;
        val$height = k;
        val$left = l;
        val$top = I.this;
        super();
    }
}
