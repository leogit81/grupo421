// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona:
//            CoronaRuntimeListener, CoronaEnvironment, CoronaRuntime

private static class <init>
    implements CoronaRuntimeListener
{

    private ArrayList cloneListenerCollection()
    {
        ArrayList arraylist1;
        synchronized (CoronaEnvironment.access$100())
        {
            arraylist1 = (ArrayList)CoronaEnvironment.access$100().clone();
        }
        return arraylist1;
        exception;
        arraylist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void onExiting(CoronaRuntime coronaruntime)
    {
        Iterator iterator = cloneListenerCollection().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            CoronaRuntimeListener coronaruntimelistener = (CoronaRuntimeListener)iterator.next();
            if (coronaruntimelistener != null)
            {
                coronaruntimelistener.onExiting(coronaruntime);
            }
        } while (true);
    }

    public void onLoaded(CoronaRuntime coronaruntime)
    {
        Iterator iterator = cloneListenerCollection().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            CoronaRuntimeListener coronaruntimelistener = (CoronaRuntimeListener)iterator.next();
            if (coronaruntimelistener != null)
            {
                coronaruntimelistener.onLoaded(coronaruntime);
            }
        } while (true);
    }

    public void onResumed(CoronaRuntime coronaruntime)
    {
        Iterator iterator = cloneListenerCollection().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            CoronaRuntimeListener coronaruntimelistener = (CoronaRuntimeListener)iterator.next();
            if (coronaruntimelistener != null)
            {
                coronaruntimelistener.onResumed(coronaruntime);
            }
        } while (true);
    }

    public void onStarted(CoronaRuntime coronaruntime)
    {
        Iterator iterator = cloneListenerCollection().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            CoronaRuntimeListener coronaruntimelistener = (CoronaRuntimeListener)iterator.next();
            if (coronaruntimelistener != null)
            {
                coronaruntimelistener.onStarted(coronaruntime);
            }
        } while (true);
    }

    public void onSuspended(CoronaRuntime coronaruntime)
    {
        Iterator iterator = cloneListenerCollection().iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            CoronaRuntimeListener coronaruntimelistener = (CoronaRuntimeListener)iterator.next();
            if (coronaruntimelistener != null)
            {
                coronaruntimelistener.onSuspended(coronaruntime);
            }
        } while (true);
    }

    private ()
    {
    }

    ( )
    {
        this();
    }
}
