// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Activity;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

public final class WindowOrientation
{

    public static final WindowOrientation LANDSCAPE_LEFT = new WindowOrientation(4, "landscapeLeft");
    public static final WindowOrientation LANDSCAPE_RIGHT = new WindowOrientation(2, "landscapeRight");
    public static final WindowOrientation PORTRAIT_UPRIGHT = new WindowOrientation(1, "portrait");
    public static final WindowOrientation PORTRAIT_UPSIDE_DOWN = new WindowOrientation(3, "portraitUpsideDown");
    public static final WindowOrientation UNKNOWN = new WindowOrientation(0, "unknown");
    private int fCoronaIntegerId;
    private String fCoronaStringId;

    private WindowOrientation(int i, String s)
    {
        if (s == null)
        {
            throw new NullPointerException();
        } else
        {
            fCoronaIntegerId = i;
            fCoronaStringId = s;
            return;
        }
    }

    public static WindowOrientation fromCurrentWindowUsing(Context context)
    {
        if (context == null)
        {
            throw new NullPointerException();
        }
        ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getRotation();
        JVM INSTR tableswitch 1 3: default 56
    //                   1 78
    //                   2 64
    //                   3 71;
           goto _L1 _L2 _L3 _L4
_L1:
        int i = 0;
_L6:
        return fromDegrees(context, i);
_L3:
        i = 180;
        continue; /* Loop/switch isn't completed */
_L4:
        i = 270;
        continue; /* Loop/switch isn't completed */
_L2:
        i = 90;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public static WindowOrientation fromDegrees(Context context, int i)
    {
        boolean flag;
        Display display;
        if (context == null)
        {
            throw new NullPointerException();
        }
        flag = true;
        display = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        display.getRotation();
        JVM INSTR tableswitch 0 3: default 64
    //                   0 94
    //                   1 115
    //                   2 94
    //                   3 115;
           goto _L1 _L2 _L3 _L2 _L3
_L1:
        if (!flag)
        {
            i = (i + 90) % 360;
        }
        if (i >= 45 && i < 135)
        {
            return LANDSCAPE_RIGHT;
        }
        break; /* Loop/switch isn't completed */
_L2:
        if (display.getWidth() < display.getHeight())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if (display.getWidth() > display.getHeight())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (true) goto _L1; else goto _L4
_L4:
        if (i >= 135 && i < 225)
        {
            return PORTRAIT_UPSIDE_DOWN;
        }
        if (i >= 225 && i < 315)
        {
            return LANDSCAPE_LEFT;
        } else
        {
            return PORTRAIT_UPRIGHT;
        }
    }

    public boolean isLandscape()
    {
        return equals(LANDSCAPE_RIGHT) || equals(LANDSCAPE_LEFT);
    }

    public boolean isPortrait()
    {
        return equals(PORTRAIT_UPRIGHT) || equals(PORTRAIT_UPSIDE_DOWN);
    }

    public boolean isSupportedBy(Activity activity)
    {
        if (activity == null)
        {
            throw new NullPointerException();
        }
        switch (activity.getRequestedOrientation())
        {
        case 2: // '\002'
        case 3: // '\003'
        case 5: // '\005'
        default:
            return false;

        case -1: 
        case 4: // '\004'
        case 10: // '\n'
            return true;

        case 1: // '\001'
        case 7: // '\007'
        case 9: // '\t'
            return isPortrait();

        case 0: // '\0'
        case 6: // '\006'
        case 8: // '\b'
            return isLandscape();
        }
    }

    public int toCoronaIntegerId()
    {
        return fCoronaIntegerId;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

}
