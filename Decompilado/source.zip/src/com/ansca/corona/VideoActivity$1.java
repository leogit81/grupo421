// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.media.MediaPlayer;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            VideoActivity, Controller, MediaManager

class this._cls0
    implements android.media.mpletionListener
{

    final VideoActivity this$0;

    public void onCompletion(MediaPlayer mediaplayer)
    {
        EventManager eventmanager = Controller.getEventManager();
        if (eventmanager != null)
        {
            eventmanager.videoEnded(VideoActivity.access$000(VideoActivity.this));
        }
        MediaManager mediamanager = Controller.getMediaManager();
        if (mediamanager != null)
        {
            mediamanager.resumeAll();
        }
        finish();
    }

    ger()
    {
        this$0 = VideoActivity.this;
        super();
    }
}
