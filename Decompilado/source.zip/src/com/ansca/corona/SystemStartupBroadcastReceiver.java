// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.ansca.corona.notifications.NotificationServices;

// Referenced classes of package com.ansca.corona:
//            CoronaService

public class SystemStartupBroadcastReceiver extends BroadcastReceiver
{

    public SystemStartupBroadcastReceiver()
    {
    }

    public void onReceive(Context context, Intent intent)
    {
        if ((new NotificationServices(context)).hasNotifications())
        {
            context.startService(new Intent(context, com/ansca/corona/CoronaService));
        }
    }
}
