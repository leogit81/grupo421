// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            Controller

class this._cls1
    implements android.content..OnClickListener
{

    final is._cls0 this$1;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        int j = i;
        if (i >= 0) goto _L2; else goto _L1
_L1:
        i;
        JVM INSTR tableswitch -3 -1: default 32
    //                   -3 92
    //                   -2 97
    //                   -1 102;
           goto _L2 _L3 _L4 _L5
_L2:
        EventManager eventmanager = Controller.access$400(_fld0);
        if (eventmanager != null)
        {
            eventmanager.nativeAlertResult(j, false);
        }
        synchronized (_fld0)
        {
            Controller.access$502(_fld0, null);
        }
        return;
        exception;
        controller;
        JVM INSTR monitorexit ;
        throw exception;
_L3:
        j = 1;
        continue; /* Loop/switch isn't completed */
_L4:
        j = 2;
        continue; /* Loop/switch isn't completed */
_L5:
        j = 0;
        if (true) goto _L2; else goto _L6
_L6:
    }

    l.msg()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ansca/corona/Controller$5

/* anonymous class */
    class Controller._cls5
        implements Runnable
    {

        final Controller this$0;
        final String val$buttonLabels[];
        final String val$msg;
        final String val$title;

        public void run()
        {
            android.app.AlertDialog.Builder builder;
            Controller._cls5._cls1 _lcls1;
            int i;
            CoronaActivity coronaactivity;
            for (coronaactivity = Controller.access$200(Controller.this); coronaactivity == null || coronaactivity.isFinishing();)
            {
                return;
            }

            builder = Controller.access$300(Controller.this, coronaactivity);
            _lcls1 = new Controller._cls5._cls1();
            android.content.DialogInterface.OnCancelListener oncancellistener = new Controller._cls5._cls2();
            if (buttonLabels != null)
            {
                i = buttonLabels.length;
            } else
            {
                i = 0;
            }
            if (i > 0) goto _L2; else goto _L1
_L1:
            builder.setTitle(title);
            builder.setMessage(msg);
_L4:
            builder.setOnCancelListener(oncancellistener);
            synchronized (Controller.this)
            {
                Controller.access$502(Controller.this, builder.create());
                Controller.access$500(Controller.this).setCanceledOnTouchOutside(false);
                Controller.access$500(Controller.this).show();
            }
            return;
            exception;
            controller;
            JVM INSTR monitorexit ;
            throw exception;
_L2:
            if (i <= 3)
            {
                builder.setTitle(title);
                builder.setMessage(msg);
                builder.setPositiveButton(buttonLabels[0], _lcls1);
                if (i > 1)
                {
                    builder.setNeutralButton(buttonLabels[1], _lcls1);
                }
                if (i > 2)
                {
                    builder.setNegativeButton(buttonLabels[2], _lcls1);
                }
            } else
            {
                builder.setTitle((new StringBuilder()).append(title).append(": ").append(msg).toString());
                builder.setItems(buttonLabels, _lcls1);
            }
            if (true) goto _L4; else goto _L3
_L3:
        }

            
            {
                this$0 = final_controller;
                buttonLabels = as;
                title = s;
                msg = String.this;
                super();
            }

        // Unreferenced inner class com/ansca/corona/Controller$5$2

/* anonymous class */
        class Controller._cls5._cls2
            implements android.content.DialogInterface.OnCancelListener
        {

            final Controller._cls5 this$1;

            public void onCancel(DialogInterface dialoginterface)
            {
                EventManager eventmanager = Controller.access$400(this$0);
                if (eventmanager != null)
                {
                    eventmanager.nativeAlertResult(-1, true);
                }
                synchronized (this$0)
                {
                    Controller.access$502(this$0, null);
                }
                return;
                exception;
                controller;
                JVM INSTR monitorexit ;
                throw exception;
            }

                    
                    {
                        this$1 = Controller._cls5.this;
                        super();
                    }
        }

    }

}
