// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.events.MediaPickerEvent;
import com.ansca.corona.storage.FileServices;
import java.io.File;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity, Controller, CoronaEnvironment

private static abstract class fGenericFileName
    implements fGenericFileName
{

    private String fDefaultExtention;
    private String fDestinationFilePath;
    protected String fGenericFileName;

    protected abstract MediaPickerEvent generateEvent(String s, int i, long l);

    protected abstract String[] getColumns();

    protected abstract String handleContentUri(Uri uri, File file, Context context, String s);

    public void onHandleActivityResult(CoronaActivity coronaactivity, int i, int j, Intent intent)
    {
        coronaactivity.unregisterActivityResultHandler(this);
        Uri uri = null;
        if (intent != null)
        {
            uri = intent.getData();
        }
        final Uri finalUri = uri;
        String s = fDestinationFilePath;
        File file = null;
        if (s != null)
        {
            int k = fDestinationFilePath.length();
            file = null;
            if (k > 0)
            {
                file = new File(fDestinationFilePath);
            }
        }
        final File finalDestinationFile = file;
        fDestinationFilePath = null;
        if (j != -1 || finalUri == null)
        {
            EventManager eventmanager = Controller.getEventManager();
            if (eventmanager != null)
            {
                eventmanager.addEvent(generateEvent(null, -1, -1L));
            }
            return;
        } else
        {
            (new Thread(new Runnable() {

                final CoronaActivity.SelectMediaActivityResultHandler this$0;
                final File val$finalDestinationFile;
                final Uri val$finalUri;

                public void run()
                {
                    Context context = CoronaEnvironment.getApplicationContext();
                    if (context != null) goto _L2; else goto _L1
_L1:
                    return;
_L2:
                    FileServices fileservices;
                    long l;
                    boolean flag;
                    fileservices = new FileServices(context);
                    l = -1L;
                    flag = false;
                    String s4;
                    boolean flag1;
                    s4 = finalUri.getScheme();
                    flag1 = "file".equals(s4);
                    flag = false;
                    if (!flag1) goto _L4; else goto _L3
_L3:
                    File file3 = new File(finalUri.getPath());
                    long l1;
                    if (!file3.exists())
                    {
                        break MISSING_BLOCK_LABEL_399;
                    }
                    l1 = file3.length();
                    File file1;
                    l = l1;
                    file1 = file3;
_L7:
                    String s1 = null;
                    if (file1 != null)
                    {
                        s1 = fileservices.getExtensionFrom(file1);
                        if (!file1.exists())
                        {
                            file1 = null;
                        }
                    }
                    String s2 = "";
                    EventManager eventmanager1;
                    int i1;
                    boolean flag2;
                    String as[];
                    Cursor cursor;
                    String s5;
                    File file4;
                    if (file1 != null && file1.exists())
                    {
                        if (finalDestinationFile != null)
                        {
                            File file2 = finalDestinationFile;
                            if (fileservices.copyFile(file1, file2))
                            {
                                s2 = finalDestinationFile.getAbsolutePath();
                            }
                        } else
                        {
                            s2 = file1.getAbsolutePath();
                        }
                    } else
                    if (flag)
                    {
                        String s3 = fDefaultExtention;
                        if (s1 != null)
                        {
                            s3 = s1;
                        }
                        s2 = handleContentUri(finalUri, finalDestinationFile, context, s3);
                    }
                    eventmanager1 = Controller.getEventManager();
                    if (eventmanager1 == null) goto _L1; else goto _L5
_L5:
                    i1 = CoronaActivity.access$200(s2);
                    eventmanager1.addEvent(generateEvent(s2, i1, l));
                    return;
_L4:
                    flag2 = "content".equals(s4);
                    flag = false;
                    file1 = null;
                    if (!flag2) goto _L7; else goto _L6
_L6:
                    flag = true;
                    as = getColumns();
                    cursor = context.getContentResolver().query(finalUri, as, null, null, null);
                    cursor.moveToFirst();
                    s5 = cursor.getString(cursor.getColumnIndex(as[0]));
                    l = cursor.getLong(cursor.getColumnIndex(as[1]));
                    cursor.close();
                    file4 = new File(s5);
                    file1 = file4;
                      goto _L7
                    Exception exception;
                    exception;
                    file1 = null;
                      goto _L7
                    Exception exception1;
                    exception1;
                    file1 = file3;
                    flag = false;
                      goto _L7
                    file1 = file3;
                    flag = false;
                      goto _L7
                }

            
            {
                this$0 = CoronaActivity.SelectMediaActivityResultHandler.this;
                finalUri = uri;
                finalDestinationFile = file;
                super();
            }
            })).start();
            return;
        }
    }

    public void setDestinationFilePath(String s)
    {
        fDestinationFilePath = s;
    }


    public _cls1.val.finalDestinationFile(String s, String s1)
    {
        fDestinationFilePath = null;
        fDefaultExtention = s;
        fGenericFileName = (new StringBuilder()).append(s1).append(" %d").toString();
    }
}
