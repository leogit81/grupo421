// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Handler;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaError;
import com.naef.jnlua.LuaStackTraceElement;
import com.naef.jnlua.LuaState;

// Referenced classes of package com.ansca.corona:
//            CoronaEnvironment, CoronaActivity, Controller

public class CoronaLuaErrorHandler
    implements JavaFunction
{

    private boolean fIsShowingError;

    public CoronaLuaErrorHandler()
    {
        fIsShowingError = false;
    }

    private String getStackTraceFrom(Throwable throwable)
    {
        if (throwable == null || throwable.getStackTrace() == null || throwable.getStackTrace().length <= 0)
        {
            return null;
        }
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("\nJava Stack Trace:");
        StackTraceElement astacktraceelement[] = throwable.getStackTrace();
        int i = astacktraceelement.length;
        for (int j = 0; j < i; j++)
        {
            StackTraceElement stacktraceelement = astacktraceelement[j];
            stringbuilder.append("\n\t");
            stringbuilder.append(stacktraceelement.toString());
        }

        return stringbuilder.toString();
    }

    private String getStackTraceFrom(LuaStackTraceElement aluastacktraceelement[])
    {
        if (aluastacktraceelement == null || aluastacktraceelement.length <= 0)
        {
            return null;
        }
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("Lua Stack Trace:");
        int i = aluastacktraceelement.length;
        for (int j = 0; j < i; j++)
        {
            LuaStackTraceElement luastacktraceelement = aluastacktraceelement[j];
            stringbuilder.append("\n\t");
            stringbuilder.append(luastacktraceelement.toString());
        }

        return stringbuilder.toString();
    }

    private void reportError(final String errorMessage, final RuntimeException exception)
    {
        if (exception == null)
        {
            throw new NullPointerException();
        }
        if (errorMessage == null || errorMessage.length() <= 0)
        {
            throw exception;
        }
        if (fIsShowingError)
        {
            return;
        }
        CoronaActivity coronaactivity = CoronaEnvironment.getCoronaActivity();
        if (coronaactivity == null)
        {
            throw exception;
        } else
        {
            fIsShowingError = true;
            coronaactivity.runOnUiThread(new Runnable() {

                final CoronaLuaErrorHandler this$0;
                final String val$errorMessage;
                final RuntimeException val$exception;

                public void run()
                {
                    CoronaActivity coronaactivity1 = CoronaEnvironment.getCoronaActivity();
                    if (coronaactivity1 == null)
                    {
                        throw exception;
                    } else
                    {
                        android.content.DialogInterface.OnCancelListener oncancellistener = new android.content.DialogInterface.OnCancelListener() {

                            final _cls2 this$1;

                            public void onCancel(DialogInterface dialoginterface)
                            {
                                throw exception;
                            }

            
            {
                this$1 = _cls2.this;
                super();
            }
                        };
                        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(coronaactivity1);
                        builder.setTitle("Runtime Error");
                        builder.setMessage(errorMessage);
                        builder.setOnCancelListener(oncancellistener);
                        AlertDialog alertdialog = builder.create();
                        alertdialog.setCanceledOnTouchOutside(false);
                        alertdialog.show();
                        return;
                    }
                }

            
            {
                this$0 = CoronaLuaErrorHandler.this;
                exception = runtimeexception;
                errorMessage = s;
                super();
            }
            });
            return;
        }
    }

    public int invoke(LuaState luastate)
    {
        String s;
        String s1;
        s = null;
        s1 = null;
        if (!luastate.isString(1)) goto _L2; else goto _L1
_L1:
        String s2 = luastate.toString(1);
_L4:
        if (s2 == null || s2.length() <= 0)
        {
            s2 = "Lua runtime error occurred.";
        }
        int i = s2.indexOf("\nJava Stack Trace:");
        if (i > 0)
        {
            if (s == null)
            {
                s = s2.substring(i + 1);
            }
            s2 = s2.substring(0, i);
        }
        if (s1 == null)
        {
            int j = luastate.getTop();
            luastate.getField(-10002, "debug");
            if (luastate.isTable(-1))
            {
                luastate.getField(-1, "traceback");
                if (luastate.isFunction(-1))
                {
                    luastate.call(0, 1);
                    if (luastate.isString(-1))
                    {
                        s1 = luastate.toString(-1);
                    }
                }
            }
            luastate.setTop(j);
        }
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(s2);
        if (s != null && s.length() > 0)
        {
            stringbuilder.append("\n");
            stringbuilder.append(s);
        }
        if (s1 != null && s1.length() > 0)
        {
            stringbuilder.append("\n");
            stringbuilder.append(s1);
        }
        RuntimeException runtimeexception = new RuntimeException(stringbuilder.toString());
        runtimeexception.setStackTrace(new StackTraceElement[0]);
        CoronaActivity coronaactivity = CoronaEnvironment.getCoronaActivity();
        if (coronaactivity != null)
        {
            Handler handler = coronaactivity.getHandler();
            if (handler != null)
            {
                handler.postDelayed(new Runnable() {

                    final CoronaLuaErrorHandler this$0;

                    public void run()
                    {
                        Controller controller = Controller.getController();
                        if (controller != null)
                        {
                            controller.stop();
                        }
                    }

            
            {
                this$0 = CoronaLuaErrorHandler.this;
                super();
            }
                }, 10L);
            }
        }
        reportError(s2, runtimeexception);
        return 1;
_L2:
        boolean flag = luastate.isJavaObjectRaw(1);
        s2 = null;
        s = null;
        s1 = null;
        if (flag)
        {
            Object obj = luastate.toJavaObjectRaw(1);
            boolean flag1 = obj instanceof LuaError;
            s2 = null;
            s = null;
            s1 = null;
            if (flag1)
            {
                LuaError luaerror = (LuaError)obj;
                s2 = luaerror.toString();
                s1 = getStackTraceFrom(luaerror.getLuaStackTrace());
                s = getStackTraceFrom(luaerror.getCause());
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }
}
