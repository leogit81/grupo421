// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ImageView;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity

class this._cls1
    implements Runnable
{

    final is._cls0 this$1;

    public void run()
    {
        if (CoronaActivity.access$000(_fld0) != null)
        {
            ViewGroup viewgroup = (ViewGroup)CoronaActivity.access$000(_fld0).getParent();
            if (viewgroup != null)
            {
                viewgroup.removeView(CoronaActivity.access$000(_fld0));
            }
            CoronaActivity.access$002(_fld0, null);
        }
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ansca/corona/CoronaActivity$2

/* anonymous class */
    class CoronaActivity._cls2
        implements android.view.animation.Animation.AnimationListener
    {

        final CoronaActivity this$0;

        public void onAnimationEnd(Animation animation)
        {
            if (CoronaActivity.access$000(CoronaActivity.this) != null)
            {
                CoronaActivity.access$000(CoronaActivity.this).post(new CoronaActivity._cls2._cls1());
            }
        }

        public void onAnimationRepeat(Animation animation)
        {
        }

        public void onAnimationStart(Animation animation)
        {
        }

            
            {
                this$0 = CoronaActivity.this;
                super();
            }
    }

}
