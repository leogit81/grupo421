// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaEditText

class val.isSingleLine
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final boolean val$isSingleLine;

    public void run()
    {
        CoronaEditText coronaedittext = (CoronaEditText)getDisplayObjectById(com/ansca/corona/CoronaEditText, val$id);
        if (coronaedittext != null)
        {
            coronaedittext.setSingleLine(val$isSingleLine);
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$isSingleLine = Z.this;
        super();
    }
}
