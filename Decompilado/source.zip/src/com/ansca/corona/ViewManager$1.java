// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.widget.AbsoluteLayout;
import java.util.ArrayList;

// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaEditText

class val.isSingleLine
    implements Runnable
{

    final ViewManager this$0;
    final int val$height;
    final int val$id;
    final boolean val$isSingleLine;
    final int val$left;
    final int val$top;
    final int val$width;

    public void run()
    {
        if (ViewManager.access$000(ViewManager.this) == null)
        {
            return;
        }
        CoronaEditText coronaedittext = new CoronaEditText(ViewManager.access$100(ViewManager.this));
        android.widget..LayoutParams layoutparams = new android.widget..LayoutParams(val$width, val$height, val$left, val$top);
        ViewManager.access$000(ViewManager.this).addView(coronaedittext, layoutparams);
        coronaedittext.setId(val$id);
        coronaedittext.setTag(new ringObjectHashMap(ViewManager.this, null));
        coronaedittext.bringToFront();
        coronaedittext.setTextColor(0xff000000);
        coronaedittext.setSingleLine(val$isSingleLine);
        coronaedittext.setImeOptions(6);
        int i = 7 & coronaedittext.getGravity();
        byte byte0;
        if (val$isSingleLine)
        {
            byte0 = 16;
        } else
        {
            byte0 = 48;
        }
        coronaedittext.setGravity(i | byte0);
        coronaedittext.setNextFocusDownId(coronaedittext.getId());
        coronaedittext.setNextFocusUpId(coronaedittext.getId());
        coronaedittext.setNextFocusLeftId(coronaedittext.getId());
        coronaedittext.setNextFocusRightId(coronaedittext.getId());
        synchronized (ViewManager.access$300(ViewManager.this))
        {
            ViewManager.access$300(ViewManager.this).add(coronaedittext);
        }
        return;
        exception;
        arraylist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    ringObjectHashMap()
    {
        this$0 = final_viewmanager;
        val$width = i;
        val$height = j;
        val$left = k;
        val$top = l;
        val$id = i1;
        val$isSingleLine = Z.this;
        super();
    }
}
