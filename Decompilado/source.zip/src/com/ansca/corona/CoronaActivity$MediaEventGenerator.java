// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.events.MediaPickerEvent;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity

private static interface _cls9
{

    public abstract MediaPickerEvent generateEvent(String s);

    public abstract MediaPickerEvent generateEvent(String s, int i, long l);
}
