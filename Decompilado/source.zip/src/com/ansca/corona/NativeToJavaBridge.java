// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.ExifInterface;
import android.net.Uri;
import android.net.http.AndroidHttpClient;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.events.NotificationRegistrationEvent;
import com.ansca.corona.facebook.FacebookController;
import com.ansca.corona.graphics.FontServices;
import com.ansca.corona.graphics.FontSettings;
import com.ansca.corona.graphics.HorizontalAlignment;
import com.ansca.corona.graphics.TextRenderer;
import com.ansca.corona.input.InputDeviceInterface;
import com.ansca.corona.input.InputDeviceInterfaceCollection;
import com.ansca.corona.input.InputDeviceServices;
import com.ansca.corona.maps.MapMarker;
import com.ansca.corona.maps.MapRequestLocationEvent;
import com.ansca.corona.maps.MapRequestLocationFailedEvent;
import com.ansca.corona.maps.MapType;
import com.ansca.corona.notifications.GoogleCloudMessagingServices;
import com.ansca.corona.notifications.NotificationServices;
import com.ansca.corona.notifications.ScheduledNotificationSettings;
import com.ansca.corona.notifications.StatusBarNotificationSettings;
import com.ansca.corona.purchasing.StoreProxy;
import com.ansca.corona.purchasing.StoreServices;
import com.ansca.corona.storage.FileServices;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaError;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.LuaType;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ansca.corona:
//            CoronaActivity, Controller, Crypto, ViewManager, 
//            CoronaEnvironment, JavaToNativeShim, MediaManager, CoronaRuntime, 
//            WindowOrientation, AudioRecorder, CoronaLua, CoronaRuntimeTaskDispatcher, 
//            CoronaRuntimeListener, CoronaData, CoronaRuntimeTask

public class NativeToJavaBridge
{
    private static class LoadBitmapResult
    {

        private Bitmap fBitmap;
        private int fHeight;
        private int fRotationInDegrees;
        private float fScaleFactor;
        private int fWidth;

        public Bitmap getBitmap()
        {
            return fBitmap;
        }

        public int getHeight()
        {
            if (fBitmap != null)
            {
                return fBitmap.getHeight();
            } else
            {
                return fHeight;
            }
        }

        public int getRotationInDegrees()
        {
            return fRotationInDegrees;
        }

        public float getScaleFactor()
        {
            return fScaleFactor;
        }

        public int getWidth()
        {
            if (fBitmap != null)
            {
                return fBitmap.getWidth();
            } else
            {
                return fWidth;
            }
        }

        public boolean wasSuccessful()
        {
            return fBitmap != null;
        }

        public LoadBitmapResult(int i, int j, float f, int k)
        {
            fBitmap = null;
            fWidth = i;
            fHeight = j;
            fScaleFactor = f;
            fRotationInDegrees = k;
        }

        public LoadBitmapResult(Bitmap bitmap, float f, int i)
        {
            fBitmap = bitmap;
            fWidth = 0;
            fHeight = 0;
            fScaleFactor = f;
            fRotationInDegrees = i;
        }
    }

    private class NetworkRequestHandler extends AsyncHttpResponseHandler
    {

        private String fFilePath;
        private boolean fHasErrorOccurred;
        private int fListenerId;
        private String fResponseMessage;
        private int fStatusCode;
        private String fUrl;
        final NativeToJavaBridge this$0;

        protected void handleResponseMessage(HttpResponse httpresponse)
        {
            if (fHasErrorOccurred)
            {
                onFailure(fResponseMessage);
                return;
            } else
            {
                fStatusCode = httpresponse.getStatusLine().getStatusCode();
                onSuccess(fResponseMessage);
                return;
            }
        }

        public void onFailure(String s)
        {
            if (fListenerId != 0)
            {
                if (s == null)
                {
                    s = "";
                }
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.networkRequestEvent(fListenerId, s, fUrl);
                }
            }
        }

        public void onFailure(Throwable throwable)
        {
            String s;
            if (throwable != null)
            {
                s = throwable.getMessage();
            } else
            {
                s = "";
            }
            onFailure(s);
        }

        public void onStart()
        {
            fHasErrorOccurred = false;
            fResponseMessage = "";
        }

        public void onSuccess(String s)
        {
            if (fListenerId != 0)
            {
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.networkRequestEvent(fListenerId, s, fUrl, fStatusCode);
                }
            }
        }

        public void sendResponseMessage(HttpResponse httpresponse)
        {
            if (httpresponse == null) goto _L2; else goto _L1
_L1:
            if (httpresponse.getEntity() == null) goto _L2; else goto _L3
_L3:
            if (fFilePath == null) goto _L5; else goto _L4
_L4:
            FileOutputStream fileoutputstream = new FileOutputStream(new File(fFilePath));
            httpresponse.getEntity().writeTo(fileoutputstream);
            fileoutputstream.flush();
            fileoutputstream.close();
            fResponseMessage = fFilePath;
_L2:
            fHasErrorOccurred = false;
_L6:
            super.sendResponseMessage(httpresponse);
            return;
_L5:
            fResponseMessage = getResponseBody(httpresponse);
              goto _L2
            Exception exception;
            exception;
            fResponseMessage = exception.getMessage();
            fHasErrorOccurred = true;
              goto _L6
        }

        public NetworkRequestHandler(int i, String s, String s1)
        {
            this$0 = NativeToJavaBridge.this;
            super();
            fListenerId = i;
            String s2;
            if (s != null && !s.equals(""))
            {
                s2 = new String(s);
            } else
            {
                s2 = null;
            }
            fFilePath = s2;
            fStatusCode = -1;
            fUrl = s1;
        }
    }


    private static DexClassLoader sClassLoader = null;
    private static HashMap sPluginCache = new HashMap();
    private CoronaActivity myActivity;
    private String myDexCacheDir;

    NativeToJavaBridge(CoronaActivity coronaactivity)
    {
        myActivity = coronaactivity;
        myDexCacheDir = coronaactivity.getDir("CoronaDexCache", 0).getAbsolutePath();
    }

    protected static boolean callCanShowPopup(String s)
    {
        return Controller.getController().canShowPopup(s);
    }

    protected static void callCancelNativeAlert(int i)
    {
        Controller.getController().cancelNativeAlert(i);
    }

    protected static void callCancelTimer()
    {
        Controller.getController().cancelTimer();
    }

    protected static void callCloseNativeActivityIndicator()
    {
        Controller.getController().closeNativeActivityIndicator();
    }

    protected static byte[] callCryptoCalculateDigest(String s, byte abyte0[])
    {
        return Crypto.CalculateDigest(s, abyte0);
    }

    protected static byte[] callCryptoCalculateHMAC(String s, String s1, byte abyte0[])
    {
        return Crypto.CalculateHMAC(s, s1, abyte0);
    }

    protected static int callCryptoGetDigestLength(String s)
    {
        return Crypto.GetDigestLength(s);
    }

    protected static void callDisplayObjectDestroy(int i)
    {
        ViewManager.getViewManager().destroyDisplayObject(i);
    }

    protected static float callDisplayObjectGetAlpha(int i)
    {
        return ViewManager.getViewManager().getDisplayObjectAlpha(i);
    }

    protected static boolean callDisplayObjectGetBackground(int i)
    {
        return ViewManager.getViewManager().getDisplayObjectBackground(i);
    }

    protected static boolean callDisplayObjectGetVisible(int i)
    {
        return ViewManager.getViewManager().getDisplayObjectVisible(i);
    }

    protected static void callDisplayObjectSetAlpha(int i, float f)
    {
        ViewManager.getViewManager().setDisplayObjectAlpha(i, f);
    }

    protected static void callDisplayObjectSetBackground(int i, boolean flag)
    {
        ViewManager.getViewManager().setDisplayObjectBackground(i, flag);
    }

    protected static void callDisplayObjectSetFocus(int i, boolean flag)
    {
        ViewManager.getViewManager().setTextViewFocus(i, flag);
    }

    protected static void callDisplayObjectSetVisible(int i, boolean flag)
    {
        ViewManager.getViewManager().setDisplayObjectVisible(i, flag);
    }

    protected static void callDisplayObjectUpdateScreenBounds(int i, int j, int k, int l, int i1)
    {
        ViewManager.getViewManager().displayObjectUpdateScreenBounds(i, j, k, l, i1);
    }

    protected static void callDisplayUpdate()
    {
        Controller.getController().displayUpdate();
    }

    protected static String callExternalizeResource(String s)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        File file;
        if (context != null)
        {
            if ((file = (new FileServices(context)).extractAssetFile(s)) != null)
            {
                return file.getAbsolutePath();
            }
        }
        return null;
    }

    protected static void callFBConnectLogin(int i, String s, String as[])
    {
        if (as == null)
        {
            as = new String[0];
        }
        FacebookController.facebookLogin(s, as);
    }

    protected static void callFBConnectLogout(int i)
    {
        FacebookController.facebookLogout();
    }

    protected static void callFBConnectRequest(int i, String s, String s1, HashMap hashmap)
    {
        FacebookController.facebookRequest(s, s1, hashmap);
    }

    protected static void callFBPublishInstall(String s)
    {
        FacebookController.publishInstall(s);
    }

    protected static void callFBShowDialog(int i, String s, HashMap hashmap)
    {
        FacebookController.facebookDialog(s, hashmap);
    }

    protected static void callFetchAllInputDevices()
    {
        for (Iterator iterator = (new InputDeviceServices(CoronaEnvironment.getApplicationContext())).fetchAll().iterator(); iterator.hasNext(); JavaToNativeShim.update((InputDeviceInterface)iterator.next())) { }
    }

    protected static void callFetchInputDevice(int i)
    {
        InputDeviceInterface inputdeviceinterface = (new InputDeviceServices(CoronaEnvironment.getApplicationContext())).fetchByCoronaDeviceId(i);
        if (inputdeviceinterface != null)
        {
            JavaToNativeShim.update(inputdeviceinterface);
        }
    }

    protected static void callFlurryEvent(String s)
    {
    }

    protected static void callFlurryInit(String s)
    {
    }

    protected static boolean callGetAssetFileLocation(String s, long l)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        com.ansca.corona.storage.AssetFileLocationInfo assetfilelocationinfo;
        if (context != null)
        {
            if ((assetfilelocationinfo = (new FileServices(context)).getAssetFileLocation(s)) != null)
            {
                JavaToNativeShim.setZipFileEntryInfo(l, assetfilelocationinfo);
                return true;
            }
        }
        return false;
    }

    protected static String[] callGetAvailableStoreNames()
    {
        return StoreServices.getAvailableInAppStoreNames();
    }

    protected static byte[] callGetBytesFromFile(String s)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        if (context == null)
        {
            return null;
        } else
        {
            return (new FileServices(context)).getBytesFromFile(s);
        }
    }

    protected static float callGetDefaultFontSize()
    {
        return Controller.getController().getDefaultFontSize();
    }

    protected static String callGetExceptionStackTraceFrom(Throwable throwable)
    {
        if (throwable == null)
        {
            return null;
        } else
        {
            return (new LuaError(null, throwable)).toString();
        }
    }

    protected static String[] callGetFonts()
    {
        return (new FontServices(CoronaEnvironment.getApplicationContext())).fetchAllSystemFontNames();
    }

    protected static boolean callGetIdleTimer()
    {
        return Controller.getController().getIdleTimer();
    }

    protected static String callGetManufacturerName()
    {
        return Controller.getController().getManufacturerName();
    }

    protected static String callGetModel()
    {
        return Controller.getController().getModel();
    }

    protected static String callGetName()
    {
        return Controller.getController().getName();
    }

    protected static String callGetPlatformVersion()
    {
        return Controller.getController().getPlatformVersion();
    }

    protected static String callGetPreference(int i)
    {
        return Controller.getController().getPreference(i);
    }

    protected static String callGetProductName()
    {
        return Controller.getController().getProductName();
    }

    protected static boolean callGetRawAssetExists(String s)
    {
        return getBridge().getRawAssetExists(s);
    }

    protected static int callGetStatusBarHeight()
    {
        NativeToJavaBridge nativetojavabridge = getBridge();
        nativetojavabridge;
        JVM INSTR monitorenter ;
        boolean flag = Controller.isValid();
        int i;
        i = 0;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_34;
        }
        CoronaActivity coronaactivity = Controller.getActivity();
        i = 0;
        if (coronaactivity == null)
        {
            break MISSING_BLOCK_LABEL_34;
        }
        i = coronaactivity.getStatusBarHeight();
        nativetojavabridge;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        nativetojavabridge;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected static int callGetStatusBarMode()
    {
        NativeToJavaBridge nativetojavabridge = getBridge();
        nativetojavabridge;
        JVM INSTR monitorenter ;
        boolean flag = Controller.isValid();
        int i;
        i = 0;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_34;
        }
        CoronaActivity coronaactivity = Controller.getActivity();
        i = 0;
        if (coronaactivity == null)
        {
            break MISSING_BLOCK_LABEL_34;
        }
        i = coronaactivity.getStatusBarMode();
        nativetojavabridge;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        nativetojavabridge;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected static String callGetTargetedStoreName()
    {
        return StoreServices.getTargetedAppStoreName();
    }

    protected static String callGetUniqueIdentifier(int i)
    {
        return Controller.getController().getUniqueIdentifier(i);
    }

    protected static float callGetVolume(int i)
    {
        return Controller.getMediaManager().getVolume(i);
    }

    protected static void callGooglePushNotificationsRegister(String s)
    {
        if (s != null && s.length() > 0)
        {
            GoogleCloudMessagingServices googlecloudmessagingservices = new GoogleCloudMessagingServices(CoronaEnvironment.getApplicationContext());
            String s1 = googlecloudmessagingservices.getRegistrationId();
            String s2 = googlecloudmessagingservices.getCommaSeparatedRegisteredProjectNumbers();
            if (s1.length() > 0 && s2.equals(s))
            {
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.addEvent(new NotificationRegistrationEvent(s1));
                    return;
                }
            } else
            {
                googlecloudmessagingservices.register(s);
                return;
            }
        }
    }

    protected static void callGooglePushNotificationsUnregister()
    {
        (new GoogleCloudMessagingServices(CoronaEnvironment.getApplicationContext())).unregister();
    }

    protected static boolean callHasAccelerometer()
    {
        return Controller.getController().hasAccelerometer();
    }

    protected static boolean callHasGyroscope()
    {
        return Controller.getController().hasGyroscope();
    }

    protected static boolean callHasMediaSource(int i)
    {
        return Controller.getController().hasMediaSource(i);
    }

    protected static void callHttpPost(String s, String s1, String s2)
    {
        Controller.getController().httpPost(s, s1, s2);
    }

    protected static int callInvokeLuaErrorHandler(long l)
    {
        return CoronaEnvironment.invokeLuaErrorHandler(l);
    }

    private static boolean callLoadBitmap(String s, long l, boolean flag, int i, int j, boolean flag1)
    {
        if (s != null && s.length() > 0 && l != 0L) goto _L2; else goto _L1
_L1:
        boolean flag2 = false;
_L23:
        return flag2;
_L2:
        Uri uri;
        String s1;
        uri = Uri.parse(Uri.encode(s, ":/\\."));
        s1 = uri.getScheme();
        if (s1 == null)
        {
            s1 = "";
        }
        if (!s1.toLowerCase().equals("android.app.icon")) goto _L4; else goto _L3
_L3:
        ApplicationInfo applicationinfo;
        PackageManager packagemanager;
        String s2;
        Context context = CoronaEnvironment.getApplicationContext();
        applicationinfo = context.getApplicationInfo();
        packagemanager = context.getPackageManager();
        s2 = uri.getHost();
        if (s2 == null)
        {
            break MISSING_BLOCK_LABEL_105;
        }
        if (s2.length() > 0)
        {
            break MISSING_BLOCK_LABEL_112;
        }
        s2 = applicationinfo.packageName;
        android.graphics.drawable.Drawable drawable;
        boolean flag4;
        drawable = packagemanager.getApplicationIcon(s2);
        flag4 = drawable instanceof BitmapDrawable;
        LoadBitmapResult loadbitmapresult;
        boolean flag3;
        flag3 = false;
        loadbitmapresult = null;
        if (!flag4) goto _L6; else goto _L5
_L5:
        BitmapDrawable bitmapdrawable;
        Bitmap bitmap5;
        bitmapdrawable = (BitmapDrawable)drawable;
        bitmap5 = bitmapdrawable.getBitmap();
        loadbitmapresult = null;
        if (bitmap5 == null) goto _L8; else goto _L7
_L7:
        if (!flag1) goto _L10; else goto _L9
_L9:
        LoadBitmapResult loadbitmapresult1 = new LoadBitmapResult(bitmapdrawable.getBitmap().getWidth(), bitmapdrawable.getBitmap().getHeight(), 1.0F, 0);
        loadbitmapresult = loadbitmapresult1;
          goto _L8
_L10:
        LoadBitmapResult loadbitmapresult2 = new LoadBitmapResult(bitmapdrawable.getBitmap(), 1.0F, 0);
        loadbitmapresult = loadbitmapresult2;
          goto _L8
        Exception exception1;
        exception1;
        exception1.printStackTrace();
        flag3 = false;
        loadbitmapresult = null;
          goto _L6
_L4:
        loadbitmapresult = getBridge().loadBitmap(s, i, j, flag1);
        flag3 = true;
          goto _L6
_L21:
        Bitmap bitmap = loadbitmapresult.getBitmap();
        if (!flag1) goto _L12; else goto _L11
_L11:
        Bitmap bitmap1;
        flag2 = JavaToNativeShim.copyBitmapInfo(l, loadbitmapresult.getWidth(), loadbitmapresult.getHeight(), loadbitmapresult.getScaleFactor(), loadbitmapresult.getRotationInDegrees());
        bitmap1 = bitmap;
_L19:
        if (flag3 && bitmap1 != null)
        {
            bitmap1.recycle();
            return flag2;
        }
        continue; /* Loop/switch isn't completed */
_L12:
        if (bitmap == null)
        {
            break MISSING_BLOCK_LABEL_433;
        }
        if (bitmap.getConfig() != null) goto _L14; else goto _L13
_L13:
        if (!flag) goto _L16; else goto _L15
_L15:
        Bitmap bitmap4 = bitmap.copy(android.graphics.Bitmap.Config.ALPHA_8, false);
        Bitmap bitmap2 = bitmap4;
_L18:
        if (flag3)
        {
            bitmap.recycle();
        }
        bitmap1 = bitmap2;
        flag3 = true;
        if (bitmap1 == null)
        {
            return false;
        }
        break; /* Loop/switch isn't completed */
_L16:
        Bitmap bitmap3 = bitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, false);
        bitmap2 = bitmap3;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        exception.printStackTrace();
        bitmap2 = null;
        if (true) goto _L18; else goto _L17
_L14:
        bitmap1 = bitmap;
_L17:
        flag2 = JavaToNativeShim.copyBitmap(l, bitmap1, loadbitmapresult.getScaleFactor(), loadbitmapresult.getRotationInDegrees(), flag);
        continue; /* Loop/switch isn't completed */
        bitmap1 = bitmap;
        flag2 = false;
        if (true) goto _L19; else goto _L8
_L8:
        flag3 = false;
_L6:
        if (loadbitmapresult != null) goto _L21; else goto _L20
_L20:
        return false;
        if (true) goto _L23; else goto _L22
_L22:
    }

    protected static int callLoadClass(long l, String s, String s1)
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        int i = 0;
        if (coronaruntime != null)
        {
            LuaState luastate = coronaruntime.getLuaState();
            if (luastate == null)
            {
                luastate = new LuaState(l);
            }
            try
            {
                String s2 = (new StringBuilder()).append(s).append(".").append(s1).toString();
                Log.v("Corona", (new StringBuilder()).append("> Class.forName: ").append(s2).toString());
                Class class1 = Class.forName(s2);
                Log.v("Corona", (new StringBuilder()).append("< Class.forName: ").append(s2).toString());
                i = instantiateClass(luastate, coronaruntime, class1);
                Log.v("Corona", (new StringBuilder()).append("Loading via reflection: ").append(s2).toString());
            }
            catch (Exception exception)
            {
                Log.v("Corona", (new StringBuilder()).append("WARNING: Could not load '").append(s1).append("'").toString());
                exception.printStackTrace();
                return i;
            }
        }
        return i;
    }

    protected static void callLoadEventSound(int i, String s)
    {
        Controller.getEventManager().loadEventSound(i, s);
    }

    protected static void callLoadSound(int i, String s)
    {
        Controller.getEventManager().loadSound(i, s);
    }

    protected static int callMapViewAddMarker(int i, double d, double d1, String s, String s1, int j, 
            String s2)
    {
        MapMarker mapmarker = new MapMarker(d, d1);
        mapmarker.setTitle(s);
        mapmarker.setSubtitle(s1);
        mapmarker.setListener(j);
        mapmarker.setImageFile(s2);
        return ViewManager.getViewManager().addMapMarker(i, mapmarker);
    }

    protected static void callMapViewCreate(int i, int j, int k, int l, int i1)
    {
        ViewManager.getViewManager().addMapView(i, j, k, l, i1);
    }

    protected static String callMapViewGetType(int i)
    {
        MapType maptype = ViewManager.getViewManager().getMapType(i);
        if (maptype == null)
        {
            maptype = MapType.STANDARD;
        }
        return maptype.toInvariantString();
    }

    protected static boolean callMapViewIsCurrentLocationVisible(int i)
    {
        return ViewManager.getViewManager().isCurrentLocationVisibleInMap(i);
    }

    protected static boolean callMapViewIsScrollEnabled(int i)
    {
        return ViewManager.getViewManager().isMapScrollEnabled(i);
    }

    protected static boolean callMapViewIsZoomEnabled(int i)
    {
        return ViewManager.getViewManager().isMapZoomEnabled(i);
    }

    protected static int callMapViewPushCurrentLocationToLua(int i, long l)
    {
        return ViewManager.getViewManager().pushMapCurrentLocationToLua(i, l);
    }

    protected static void callMapViewRemoveAllMarkers(int i)
    {
        ViewManager.getViewManager().removeAllMapViewMarkers(i);
    }

    protected static void callMapViewRemoveMarker(int i, int j)
    {
        ViewManager.getViewManager().removeMapMarker(i, j);
    }

    protected static void callMapViewSetCenter(int i, double d, double d1, boolean flag)
    {
        ViewManager.getViewManager().setMapCenter(i, d, d1, flag);
    }

    protected static void callMapViewSetRegion(int i, double d, double d1, double d2, double d3, boolean flag)
    {
        ViewManager.getViewManager().setMapRegion(i, d, d1, d2, d3, flag);
    }

    protected static void callMapViewSetScrollEnabled(int i, boolean flag)
    {
        ViewManager.getViewManager().setMapScrollEnabled(i, flag);
    }

    protected static void callMapViewSetType(int i, String s)
    {
        MapType maptype = MapType.fromInvariantString(s);
        if (maptype != null)
        {
            ViewManager.getViewManager().setMapType(i, maptype);
        }
    }

    protected static void callMapViewSetZoomEnabled(int i, boolean flag)
    {
        ViewManager.getViewManager().setMapZoomEnabled(i, flag);
    }

    protected static void callNetworkRequest(String s, String s1, int i, HashMap hashmap, String s2, String s3)
    {
        getBridge().networkRequest(s, s1, i, hashmap, s2, s3);
    }

    protected static void callNotificationCancel(int i)
    {
        (new NotificationServices(CoronaEnvironment.getApplicationContext())).removeById(i);
    }

    protected static void callNotificationCancelAll()
    {
        (new NotificationServices(CoronaEnvironment.getApplicationContext())).removeAll();
    }

    protected static int callNotificationSchedule(long l, int i)
    {
        LuaState luastate;
        if (l == 0L)
        {
            return 0;
        }
        CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
        luastate = null;
        if (coronaruntime != null)
        {
            luastate = coronaruntime.getLuaState();
        }
        if (luastate == null)
        {
            luastate = new LuaState(l);
        }
        Date date;
        if (luastate.isTable(i))
        {
            GregorianCalendar gregoriancalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
            luastate.getField(i, "year");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(1, luastate.toInteger(-1));
            }
            luastate.pop(1);
            luastate.getField(i, "month");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(2, -1 + luastate.toInteger(-1));
            }
            luastate.pop(1);
            luastate.getField(i, "day");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(5, luastate.toInteger(-1));
            }
            luastate.pop(1);
            luastate.getField(i, "hour");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(11, luastate.toInteger(-1));
            }
            luastate.pop(1);
            luastate.getField(i, "min");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(12, luastate.toInteger(-1));
            }
            luastate.pop(1);
            luastate.getField(i, "sec");
            if (luastate.isNumber(-1))
            {
                gregoriancalendar.set(13, luastate.toInteger(-1));
            }
            luastate.pop(1);
            date = gregoriancalendar.getTime();
            break MISSING_BLOCK_LABEL_378;
        }
        LuaType luatype;
        LuaType luatype1;
        luatype = luastate.type(i);
        luatype1 = LuaType.NUMBER;
        date = null;
        if (luatype != luatype1)
        {
            break MISSING_BLOCK_LABEL_378;
        }
        Date date2;
        Date date1 = new Date();
        double d = luastate.toNumber(i);
        date2 = new Date(date1.getTime() + (long)(1000D * d));
        date = date2;
        break MISSING_BLOCK_LABEL_378;
        Exception exception;
        exception;
        exception.printStackTrace();
        date = null;
        while (date != null) 
        {
            Context context = CoronaEnvironment.getApplicationContext();
            NotificationServices notificationservices = new NotificationServices(context);
            ScheduledNotificationSettings schedulednotificationsettings = ScheduledNotificationSettings.from(context, luastate, i + 1);
            schedulednotificationsettings.setId(notificationservices.reserveId());
            schedulednotificationsettings.setEndTime(date);
            schedulednotificationsettings.getStatusBarSettings().setTimestamp(date);
            notificationservices.post(schedulednotificationsettings);
            return schedulednotificationsettings.getId();
        }
        return 0;
    }

    protected static void callOnAudioEnabled()
    {
        MediaManager mediamanager = Controller.getMediaManager();
        if (mediamanager != null)
        {
            mediamanager.onUsingAudio();
        }
    }

    protected static void callOnRuntimeExiting()
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        if (coronaruntime != null)
        {
            coronaruntime.dispose();
        }
    }

    protected static void callOnRuntimeLoaded(long l)
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        if (coronaruntime != null)
        {
            coronaruntime.onLoaded(l);
        }
    }

    protected static void callOnRuntimeResumed()
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        if (coronaruntime != null)
        {
            coronaruntime.onResumed();
        }
    }

    protected static void callOnRuntimeStarted()
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        if (coronaruntime != null)
        {
            coronaruntime.onStarted();
        }
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity != null)
        {
            coronaactivity.runOnUiThread(new Runnable() {

                public void run()
                {
                    CoronaActivity coronaactivity1 = Controller.getActivity();
                    if (coronaactivity1 != null)
                    {
                        coronaactivity1.hideSplashScreen();
                    }
                }

            });
        }
    }

    protected static void callOnRuntimeSuspended()
    {
        CoronaRuntime coronaruntime = Controller.getRuntime();
        if (coronaruntime != null)
        {
            coronaruntime.onSuspended();
        }
    }

    protected static boolean callOpenUrl(String s)
    {
        return Controller.getController().openUrl(s);
    }

    protected static void callPauseSound(int i)
    {
        Controller.getEventManager().pauseSound(i);
    }

    protected static void callPlaySound(int i, String s, boolean flag)
    {
        Controller.getEventManager().playSound(i, s, flag);
    }

    protected static void callPlayVideo(int i, String s, boolean flag)
    {
        Controller.getMediaManager().playVideo(i, s, flag);
    }

    protected static void callPushApplicationOpenArgumentsToLuaTable(long l)
    {
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity != null)
        {
            pushArgumentsToLuaTable(l, coronaactivity.getIntent());
        }
    }

    protected static void callPushLaunchArgumentsToLuaTable(long l)
    {
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity != null)
        {
            pushArgumentsToLuaTable(l, coronaactivity.getInitialIntent());
        }
    }

    protected static int callPushLocationNameCoordinatesToLua(String s, long l)
    {
        double d = 0.0D;
        double d1 = 0.0D;
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null)
        {
            context.enforceCallingOrSelfPermission("android.permission.INTERNET", null);
        }
        CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
        LuaState luastate = null;
        if (coronaruntime != null)
        {
            luastate = coronaruntime.getLuaState();
        }
        if (luastate == null)
        {
            luastate = new LuaState(l);
        }
        Location location = getLocationFromName(s);
        if (location != null)
        {
            d = location.getLatitude();
            d1 = location.getLongitude();
        }
        luastate.pushNumber(d);
        luastate.pushNumber(d1);
        return 2;
    }

    protected static int callPushSystemInfoToLua(long l, String s)
    {
        if (l != 0L) goto _L2; else goto _L1
_L1:
        int i = 0;
_L4:
        return i;
_L2:
        LuaState luastate;
        Context context;
        ApplicationInfo applicationinfo;
        PackageManager packagemanager;
        CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
        luastate = null;
        if (coronaruntime != null)
        {
            luastate = coronaruntime.getLuaState();
        }
        if (luastate == null)
        {
            luastate = new LuaState(l);
        }
        context = CoronaEnvironment.getApplicationContext();
        if (context == null)
        {
            return 0;
        }
        applicationinfo = context.getApplicationInfo();
        packagemanager = context.getPackageManager();
        i = 0;
        if (s != null)
        {
            int j = s.length();
            i = 0;
            if (j > 0)
            {
                break; /* Loop/switch isn't completed */
            }
        }
_L5:
        if (i <= 0)
        {
            luastate.pushNil();
            return 1;
        }
        if (true) goto _L4; else goto _L3
_L3:
        if (s.equals("appName"))
        {
            CharSequence charsequence = packagemanager.getApplicationLabel(applicationinfo);
            String s4 = null;
            if (charsequence != null)
            {
                s4 = charsequence.toString();
            }
            if (s4 == null)
            {
                s4 = "";
            }
            luastate.pushString(s4);
            i = 1;
        } else
        if (s.equals("appVersionString"))
        {
            boolean flag;
            DisplayMetrics displaymetrics;
            float f;
            double d;
            int k;
            DisplayMetrics displaymetrics1;
            float f1;
            double d1;
            int i1;
            DisplayMetrics displaymetrics2;
            float f2;
            DisplayMetrics displaymetrics3;
            float f3;
            DisplayMetrics displaymetrics4;
            String s1;
            DisplayMetrics displaymetrics5;
            String s2;
            Exception exception;
            int j1;
            String s3;
            try
            {
                s3 = packagemanager.getPackageInfo(context.getPackageName(), 0).versionName;
            }
            catch (Exception exception1)
            {
                s3 = null;
            }
            if (s3 == null)
            {
                s3 = "";
            }
            luastate.pushString(s3);
            i = 1;
        } else
        if (s.equals("androidAppVersionCode"))
        {
            try
            {
                j1 = packagemanager.getPackageInfo(context.getPackageName(), 0).versionCode;
            }
            // Misplaced declaration of an exception variable
            catch (Exception exception)
            {
                j1 = 0;
            }
            luastate.pushInteger(j1);
            i = 1;
        } else
        {
label0:
            {
                if (!s.equals("androidAppPackageName"))
                {
                    break label0;
                }
                s2 = applicationinfo.packageName;
                if (s2 == null)
                {
                    s2 = "";
                }
                luastate.pushString(s2);
                i = 1;
            }
        }
          goto _L5
        if (!s.equals("androidDisplayDensityName"))
        {
            break MISSING_BLOCK_LABEL_437;
        }
        s1 = "unknown";
        displaymetrics5 = getDisplayMetrics();
        if (displaymetrics5 == null) goto _L7; else goto _L6
_L6:
        displaymetrics5.densityDpi;
        JVM INSTR lookupswitch 6: default 376
    //                   120: 429
    //                   160: 421
    //                   213: 389
    //                   240: 413
    //                   320: 405
    //                   480: 397;
           goto _L8 _L9 _L10 _L11 _L12 _L13 _L14
_L8:
        break; /* Loop/switch isn't completed */
_L9:
        break MISSING_BLOCK_LABEL_429;
_L7:
        luastate.pushString(s1);
        i = 1;
          goto _L5
_L11:
        s1 = "tvdpi";
          goto _L7
_L14:
        s1 = "xxhdpi";
          goto _L7
_L13:
        s1 = "xhdpi";
          goto _L7
_L12:
        s1 = "hdpi";
          goto _L7
_L10:
        s1 = "mdpi";
          goto _L7
        s1 = "ldpi";
          goto _L7
        if (s.equals("androidDisplayApproximateDpi"))
        {
            displaymetrics4 = getDisplayMetrics();
            i = 0;
            if (displaymetrics4 != null)
            {
                luastate.pushInteger(displaymetrics4.densityDpi);
                i = 1;
            }
        } else
        if (s.equals("androidDisplayXDpi"))
        {
            displaymetrics3 = getDisplayMetrics();
            i = 0;
            if (displaymetrics3 != null)
            {
                if (WindowOrientation.fromCurrentWindowUsing(context).isPortrait())
                {
                    f3 = displaymetrics3.xdpi;
                } else
                {
                    f3 = displaymetrics3.ydpi;
                }
                luastate.pushNumber(f3);
                i = 1;
            }
        } else
        if (s.equals("androidDisplayYDpi"))
        {
            displaymetrics2 = getDisplayMetrics();
            i = 0;
            if (displaymetrics2 != null)
            {
                if (WindowOrientation.fromCurrentWindowUsing(context).isPortrait())
                {
                    f2 = displaymetrics2.ydpi;
                } else
                {
                    f2 = displaymetrics2.xdpi;
                }
                luastate.pushNumber(f2);
                i = 1;
            }
        } else
        if (s.equals("androidDisplayWidthInInches"))
        {
            displaymetrics1 = getDisplayMetrics();
            i = 0;
            if (displaymetrics1 != null)
            {
                if (WindowOrientation.fromCurrentWindowUsing(context).isPortrait())
                {
                    f1 = displaymetrics1.xdpi;
                } else
                {
                    f1 = displaymetrics1.ydpi;
                }
                d1 = f1;
                i1 = d1 != 0.0D;
                i = 0;
                if (i1 > 0)
                {
                    luastate.pushNumber((double)displaymetrics1.widthPixels / d1);
                    i = 1;
                }
            }
        } else
        {
            flag = s.equals("androidDisplayHeightInInches");
            i = 0;
            if (flag)
            {
                displaymetrics = getDisplayMetrics();
                i = 0;
                if (displaymetrics != null)
                {
                    if (WindowOrientation.fromCurrentWindowUsing(context).isPortrait())
                    {
                        f = displaymetrics.ydpi;
                    } else
                    {
                        f = displaymetrics.xdpi;
                    }
                    d = f;
                    k = d != 0.0D;
                    i = 0;
                    if (k > 0)
                    {
                        luastate.pushNumber((double)displaymetrics.heightPixels / d);
                        i = 1;
                    }
                }
            }
        }
          goto _L5
    }

    protected static ByteBuffer callRecordGetBytes(int i)
    {
        AudioRecorder.AudioByteBufferHolder audiobytebufferholder = Controller.getMediaManager().getAudioRecorder(i).getNextBuffer();
        if (audiobytebufferholder != null)
        {
            return audiobytebufferholder.myBuffer;
        } else
        {
            return null;
        }
    }

    protected static int callRecordGetCurrentByteCount(int i)
    {
        AudioRecorder.AudioByteBufferHolder audiobytebufferholder = Controller.getMediaManager().getAudioRecorder(i).getCurrentBuffer();
        if (audiobytebufferholder != null)
        {
            return audiobytebufferholder.myValidBytes;
        } else
        {
            return 0;
        }
    }

    protected static void callRecordReleaseCurrentBuffer(int i)
    {
        Controller.getMediaManager().getAudioRecorder(i).releaseCurrentBuffer();
    }

    protected static void callRecordStart(String s, int i)
    {
        Controller.getMediaManager().getAudioRecorder(i).startRecording(s);
    }

    protected static void callRecordStop(int i)
    {
        Controller.getMediaManager().getAudioRecorder(i).stopRecording();
    }

    protected static boolean callRenderText(long l, String s, String s1, float f, boolean flag, int i, int j, 
            int k, String s2)
    {
        if (l == 0L)
        {
            return false;
        }
        Context context = CoronaEnvironment.getApplicationContext();
        if (context == null)
        {
            return false;
        }
        HorizontalAlignment horizontalalignment = HorizontalAlignment.fromCoronaStringId(s2);
        if (horizontalalignment == null)
        {
            horizontalalignment = HorizontalAlignment.LEFT;
        }
        TextRenderer textrenderer = new TextRenderer(context);
        textrenderer.getFontSettings().setName(s1);
        textrenderer.getFontSettings().setPointSize(f);
        textrenderer.getFontSettings().setIsBold(flag);
        textrenderer.setText(s);
        textrenderer.setHorizontalAlignment(horizontalalignment);
        textrenderer.setWrapWidth(i);
        textrenderer.setClipWidth(j);
        textrenderer.setClipHeight(k);
        Bitmap bitmap = textrenderer.createBitmap();
        if (bitmap == null)
        {
            return false;
        } else
        {
            boolean flag1 = JavaToNativeShim.copyBitmap(l, bitmap, 1.0F, 0, true);
            bitmap.recycle();
            return flag1;
        }
    }

    protected static void callRequestLocationAsync(long l)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null)
        {
            context.enforceCallingOrSelfPermission("android.permission.INTERNET", null);
        }
        CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
        LuaState luastate = null;
        if (coronaruntime != null)
        {
            luastate = coronaruntime.getLuaState();
        }
        if (luastate == null)
        {
            luastate = new LuaState(l);
        }
        luastate.checkArg(-1, CoronaLua.isListener(luastate, -1, "mapLocation"), "The third arguement of requestLocation should be a listener.");
        int i = CoronaLua.newRef(luastate, -1);
        String s = luastate.checkString(-2);
        new CoronaRuntimeTaskDispatcher(luastate);
        (new Thread(new Runnable(s, i) {

            final int val$functionListenerFinal;
            final String val$locationFinal;

            public void run()
            {
                EventManager eventmanager;
label0:
                {
                    Location location = NativeToJavaBridge.getLocationFromName(locationFinal);
                    eventmanager = Controller.getEventManager();
                    if (eventmanager != null)
                    {
                        if (location == null)
                        {
                            break label0;
                        }
                        eventmanager.addEvent(new MapRequestLocationEvent(functionListenerFinal, location.getLatitude(), location.getLongitude(), locationFinal));
                    }
                    return;
                }
                eventmanager.addEvent(new MapRequestLocationFailedEvent(functionListenerFinal, "", locationFinal));
            }

            
            {
                locationFinal = s;
                functionListenerFinal = i;
                super();
            }
        })).start();
    }

    protected static void callRequestNearestAddressFromCoordinates(long l)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null)
        {
            context.enforceCallingOrSelfPermission("android.permission.INTERNET", null);
        }
        CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
        LuaState luastate = null;
        if (coronaruntime != null)
        {
            luastate = coronaruntime.getLuaState();
        }
        if (luastate == null)
        {
            luastate = new LuaState(l);
        }
        boolean flag = CoronaLua.isListener(luastate, -1, "requestLocation");
        luastate.checkArg(-1, flag, "The third arguement of nearestAddress should be a listener.");
        int i = CoronaLua.newRef(luastate, -1);
        double d = luastate.checkNumber(-2);
        (new Thread(new Runnable(luastate.checkNumber(-3), d, i, new CoronaRuntimeTaskDispatcher(luastate)) {

            final CoronaRuntimeTaskDispatcher val$dispatcher;
            final int val$functionListenerFinal;
            final double val$latitudeFinal;
            final double val$longitudeFinal;

            public void run()
            {
                List list = (new Geocoder(CoronaEnvironment.getApplicationContext())).getFromLocation(latitudeFinal, longitudeFinal, 1);
                if (list == null) goto _L2; else goto _L1
_L1:
                if (list.size() <= 0) goto _L2; else goto _L3
_L3:
                Address address = (Address)list.get(0);
_L5:
                CoronaRuntimeTask coronaruntimetask = address. new CoronaRuntimeTask() {

                    final _cls5 this$0;
                    final Address val$addressFinal;

                    public void executeUsing(CoronaRuntime coronaruntime)
                    {
                        LuaState luastate = coronaruntime.getLuaState();
                        CoronaLua.newEvent(luastate, "nearestAddress");
                        if (addressFinal != null)
                        {
                            try
                            {
                                if (addressFinal.getThoroughfare() != null)
                                {
                                    luastate.pushString(addressFinal.getThoroughfare());
                                    luastate.setField(-2, "street");
                                }
                                if (addressFinal.getSubThoroughfare() != null)
                                {
                                    luastate.pushString(addressFinal.getSubThoroughfare());
                                    luastate.setField(-2, "streetDetail");
                                }
                                if (addressFinal.getLocality() != null)
                                {
                                    luastate.pushString(addressFinal.getLocality());
                                    luastate.setField(-2, "city");
                                }
                                if (addressFinal.getSubLocality() != null)
                                {
                                    luastate.pushString(addressFinal.getSubLocality());
                                    luastate.setField(-2, "cityDetail");
                                }
                                if (addressFinal.getAdminArea() != null)
                                {
                                    luastate.pushString(addressFinal.getAdminArea());
                                    luastate.setField(-2, "region");
                                }
                                if (addressFinal.getSubAdminArea() != null)
                                {
                                    luastate.pushString(addressFinal.getSubAdminArea());
                                    luastate.setField(-2, "regionDetail");
                                }
                                if (addressFinal.getPostalCode() != null)
                                {
                                    luastate.pushString(addressFinal.getPostalCode());
                                    luastate.setField(-2, "postalCode");
                                }
                                if (addressFinal.getCountryName() != null)
                                {
                                    luastate.pushString(addressFinal.getCountryName());
                                    luastate.setField(-2, "country");
                                }
                                if (addressFinal.getCountryCode() != null)
                                {
                                    luastate.pushString(addressFinal.getCountryCode());
                                    luastate.setField(-2, "countryCode");
                                }
                                CoronaLua.dispatchEvent(luastate, functionListenerFinal, 0);
                            }
                            catch (Exception exception1)
                            {
                                exception1.printStackTrace();
                            }
                        } else
                        {
                            try
                            {
                                luastate.pushBoolean(true);
                                luastate.setField(-2, "isError");
                                CoronaLua.dispatchEvent(luastate, functionListenerFinal, 0);
                            }
                            catch (Exception exception)
                            {
                                exception.printStackTrace();
                            }
                        }
                        CoronaLua.deleteRef(luastate, functionListenerFinal);
                    }

            
            {
                this$0 = final__pcls5;
                addressFinal = Address.this;
                super();
            }
                };
                dispatcher.send(coronaruntimetask);
                return;
_L2:
                address = null;
                continue; /* Loop/switch isn't completed */
                Exception exception;
                exception;
                exception.getMessage();
                address = null;
                if (true) goto _L5; else goto _L4
_L4:
            }

            
            {
                latitudeFinal = d;
                longitudeFinal = d1;
                functionListenerFinal = i;
                dispatcher = coronaruntimetaskdispatcher;
                super();
            }
        })).start();
    }

    protected static boolean callRequestSystem(long l, String s, int i)
    {
        if (s != null && s.length() > 0) goto _L2; else goto _L1
_L1:
        CoronaActivity coronaactivity;
        return false;
_L2:
        if ((coronaactivity = Controller.getActivity()) == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!s.equals("exitApplication"))
        {
            continue; /* Loop/switch isn't completed */
        }
        coronaactivity.runOnUiThread(new Runnable() {

            public void run()
            {
                CoronaActivity coronaactivity1 = Controller.getActivity();
                if (coronaactivity1 != null)
                {
                    coronaactivity1.finish();
                }
            }

        });
_L4:
        return true;
        if (!s.equals("suspendApplication")) goto _L1; else goto _L3
_L3:
        coronaactivity.runOnUiThread(new Runnable() {

            public void run()
            {
                CoronaActivity coronaactivity1 = Controller.getActivity();
                if (coronaactivity1 != null)
                {
                    coronaactivity1.moveTaskToBack(true);
                }
            }

        });
          goto _L4
        if (true) goto _L1; else goto _L5
_L5:
    }

    protected static void callResumeSound(int i)
    {
        Controller.getEventManager().resumeSound(i);
    }

    protected static boolean callSaveBitmap(int ai[], int i, int j, int k, String s)
    {
        if (Controller.isValid()) goto _L2; else goto _L1
_L1:
        Log.v("Corona", "callSaveBitmap has invalid controller");
_L4:
        return false;
_L2:
        boolean flag;
label0:
        {
            if (s != null)
            {
                int l = s.length();
                flag = false;
                if (l > 0)
                {
                    break label0;
                }
            }
            File file = createUniqueFileNameInPicturesDirectory(".png");
            if (file == null)
            {
                Log.v("Corona", "ERROR: Failed to save bitmap to the photo library.");
                return false;
            }
            s = file.getPath();
            flag = true;
        }
        Bitmap bitmap1 = Bitmap.createBitmap(ai, i, j, android.graphics.Bitmap.Config.ARGB_8888);
        Bitmap bitmap = bitmap1;
_L5:
        if (bitmap != null)
        {
            boolean flag1 = Controller.getController().saveBitmap(bitmap, k, s);
            if (flag1 && flag)
            {
                Controller.getController().addImageFileToPhotoGallery(s);
            }
            bitmap.recycle();
            return flag1;
        }
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        exception.printStackTrace();
        bitmap = null;
          goto _L5
    }

    protected static boolean callSaveImageToPhotoLibrary(String s)
    {
        Controller controller;
        if (s != null && s.length() > 0)
        {
            if ((controller = Controller.getController()) != null)
            {
                FileServices fileservices = new FileServices(CoronaEnvironment.getApplicationContext());
                File file = createUniqueFileNameInPicturesDirectory(fileservices.getExtensionFrom(s));
                if (file != null)
                {
                    String s1 = file.getPath();
                    if (fileservices.copyFile(s, s1))
                    {
                        controller.addImageFileToPhotoGallery(s1);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    protected static void callSetAccelerometerInterval(int i)
    {
        Controller.getController().setAccelerometerInterval(i);
    }

    protected static void callSetEventNotification(int i, boolean flag)
    {
        Controller.getController().setEventNotification(i, flag);
    }

    protected static void callSetGyroscopeInterval(int i)
    {
        Controller.getController().setGyroscopeInterval(i);
    }

    protected static void callSetIdleTimer(boolean flag)
    {
        Controller.getController().setIdleTimer(flag);
    }

    protected static void callSetLocationAccuracy(double d)
    {
    }

    protected static void callSetLocationThreshold(double d)
    {
        Controller.getController().setLocationThreshold(d);
    }

    protected static void callSetStatusBarMode(int i)
    {
        if (Controller.isValid())
        {
            Controller.getActivity().runOnUiThread(new Runnable(i) {

                final int val$mode;

                public void run()
                {
                    this;
                    JVM INSTR monitorenter ;
                    CoronaActivity coronaactivity = Controller.getActivity();
                    if (coronaactivity == null)
                    {
                        break MISSING_BLOCK_LABEL_18;
                    }
                    coronaactivity.setStatusBarMode(mode);
                    this;
                    JVM INSTR monitorexit ;
                    return;
                    Exception exception;
                    exception;
                    this;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            
            {
                mode = i;
                super();
            }
            });
        }
    }

    protected static void callSetTimer(int i)
    {
        Controller.getController().setTimer(i);
    }

    protected static void callSetVolume(int i, float f)
    {
        Controller.getMediaManager().setVolume(i, f);
    }

    protected static boolean callShowAppStorePopup(HashMap hashmap)
    {
        return Controller.getController().showAppStoreWindow(hashmap);
    }

    protected static void callShowImagePicker(int i, String s)
    {
        Controller.getController().showImagePickerWindow(i, s);
    }

    protected static void callShowNativeActivityIndicator()
    {
        Controller.getController().showNativeActivityIndicator();
    }

    protected static void callShowNativeAlert(String s, String s1, String as[])
    {
        Controller.getController().showNativeAlert(s, s1, as);
    }

    protected static void callShowSendMailPopup(HashMap hashmap)
    {
        Controller.getController().showSendMailWindow(hashmap);
    }

    protected static void callShowSendSmsPopup(HashMap hashmap)
    {
        Controller.getController().showSendSmsWindow(hashmap);
    }

    protected static void callShowSplashScreen()
    {
        getBridge().getActivity().runOnUiThread(new Runnable() {

            public void run()
            {
                CoronaActivity coronaactivity = Controller.getActivity();
                if (coronaactivity != null)
                {
                    coronaactivity.showSplashScreen();
                }
            }

        });
    }

    protected static void callShowTrialAlert()
    {
        Controller.getController().showTrialAlert();
    }

    protected static void callShowVideoPicker(int i, int j, int k)
    {
        Controller.getController().showVideoPickerWindow(i, j, k);
    }

    protected static void callStopSound(int i)
    {
        Controller.getEventManager().stopSound(i);
    }

    protected static void callStoreFinishTransaction(String s)
    {
        if (Controller.isValid())
        {
            Controller.getActivity().runOnUiThread(new Runnable(s) {

                final String val$transactionStringId;

                public void run()
                {
                    this;
                    JVM INSTR monitorenter ;
                    CoronaActivity coronaactivity = Controller.getActivity();
                    if (coronaactivity == null)
                    {
                        break MISSING_BLOCK_LABEL_21;
                    }
                    coronaactivity.getStore().confirmTransaction(transactionStringId);
                    this;
                    JVM INSTR monitorexit ;
                    return;
                    Exception exception;
                    exception;
                    this;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            
            {
                transactionStringId = s;
                super();
            }
            });
        }
    }

    protected static void callStoreInit(String s)
    {
        if (Controller.isValid())
        {
            Controller.getActivity().runOnUiThread(new Runnable(s) {

                final String val$storeName;

                public void run()
                {
                    this;
                    JVM INSTR monitorenter ;
                    CoronaActivity coronaactivity = Controller.getActivity();
                    if (coronaactivity == null) goto _L2; else goto _L1
_L1:
                    StoreProxy storeproxy;
                    storeproxy = coronaactivity.getStore();
                    if (storeName != null && storeName.length() > 0)
                    {
                        break MISSING_BLOCK_LABEL_43;
                    }
                    storeproxy.useDefaultStore();
_L4:
                    storeproxy.enable();
_L2:
                    this;
                    JVM INSTR monitorexit ;
                    return;
                    storeproxy.useStore(storeName);
                    if (true) goto _L4; else goto _L3
_L3:
                    Exception exception;
                    exception;
                    this;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            
            {
                storeName = s;
                super();
            }
            });
        }
    }

    protected static void callStorePurchase(String s)
    {
        if (Controller.isValid())
        {
            Controller.getActivity().runOnUiThread(new Runnable(s) {

                final String val$productName;

                public void run()
                {
                    this;
                    JVM INSTR monitorenter ;
                    CoronaActivity coronaactivity = Controller.getActivity();
                    if (coronaactivity == null)
                    {
                        break MISSING_BLOCK_LABEL_21;
                    }
                    coronaactivity.getStore().purchase(productName);
                    this;
                    JVM INSTR monitorexit ;
                    return;
                    Exception exception;
                    exception;
                    this;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            
            {
                productName = s;
                super();
            }
            });
        }
    }

    protected static void callStoreRestoreCompletedTransactions()
    {
        if (Controller.isValid())
        {
            Controller.getActivity().runOnUiThread(new Runnable() {

                public void run()
                {
                    this;
                    JVM INSTR monitorenter ;
                    CoronaActivity coronaactivity = Controller.getActivity();
                    if (coronaactivity == null)
                    {
                        break MISSING_BLOCK_LABEL_17;
                    }
                    coronaactivity.getStore().restorePurchases();
                    this;
                    JVM INSTR monitorexit ;
                    return;
                    Exception exception;
                    exception;
                    this;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            });
        }
    }

    protected static int callTextFieldCreate(int i, int j, int k, int l, int i1, boolean flag)
    {
        ViewManager.getViewManager().addTextView(i, j, k, l, i1, flag);
        return 1;
    }

    protected static String callTextFieldGetAlign(int i)
    {
        return ViewManager.getViewManager().getTextViewAlign(i);
    }

    protected static int[] callTextFieldGetColor(int i)
    {
        int j = ViewManager.getViewManager().getTextViewColor(i);
        int ai[] = new int[4];
        ai[0] = Color.red(j);
        ai[1] = Color.green(j);
        ai[2] = Color.blue(j);
        ai[3] = Color.alpha(j);
        return ai;
    }

    protected static String callTextFieldGetFont(int i)
    {
        return "";
    }

    protected static String callTextFieldGetInputType(int i)
    {
        return ViewManager.getViewManager().getTextViewInputType(i);
    }

    protected static boolean callTextFieldGetSecure(int i)
    {
        return ViewManager.getViewManager().getTextViewPassword(i);
    }

    protected static float callTextFieldGetSize(int i)
    {
        return ViewManager.getViewManager().getTextViewSize(i);
    }

    protected static String callTextFieldGetText(int i)
    {
        return ViewManager.getViewManager().getTextViewText(i);
    }

    protected static boolean callTextFieldIsEditable(int i)
    {
        return ViewManager.getViewManager().isTextViewEditable(i);
    }

    protected static boolean callTextFieldIsSingleLine(int i)
    {
        return ViewManager.getViewManager().isTextViewSingleLine(i);
    }

    protected static void callTextFieldSetAlign(int i, String s)
    {
        ViewManager.getViewManager().setTextViewAlign(i, s);
    }

    protected static void callTextFieldSetColor(int i, int j, int k, int l, int i1)
    {
        int j1 = Color.argb(i1, j, k, l);
        ViewManager.getViewManager().setTextViewColor(i, j1);
    }

    protected static void callTextFieldSetEditable(int i, boolean flag)
    {
        ViewManager.getViewManager().setTextViewEditable(i, flag);
    }

    protected static void callTextFieldSetFont(int i, String s, float f, boolean flag)
    {
        ViewManager.getViewManager().setTextViewFont(i, s, f, flag);
    }

    protected static void callTextFieldSetInputType(int i, String s)
    {
        ViewManager.getViewManager().setTextViewInputType(i, s);
    }

    protected static void callTextFieldSetReturnKey(int i, String s)
    {
        ViewManager.getViewManager().setTextReturnKey(i, s);
    }

    protected static void callTextFieldSetSecure(int i, boolean flag)
    {
        ViewManager.getViewManager().setTextViewPassword(i, flag);
    }

    protected static void callTextFieldSetSize(int i, float f)
    {
        ViewManager.getViewManager().setTextViewSize(i, f);
    }

    protected static void callTextFieldSetText(int i, String s)
    {
        ViewManager.getViewManager().setTextViewText(i, s);
    }

    protected static void callVibrate()
    {
        Controller.getController().vibrate();
    }

    protected static void callVibrateInputDevice(int i)
    {
        Context context = CoronaEnvironment.getApplicationContext();
        InputDeviceInterface inputdeviceinterface;
        if (context != null)
        {
            if ((inputdeviceinterface = (new InputDeviceServices(context)).fetchByCoronaDeviceId(i)) != null)
            {
                inputdeviceinterface.vibrate();
                return;
            }
        }
    }

    protected static void callVideoViewCreate(int i, int j, int k, int l, int i1)
    {
        ViewManager.getViewManager().addVideoView(i, j, k, l, i1);
    }

    protected static int callVideoViewGetCurrentTime(int i)
    {
        return ViewManager.getViewManager().videoViewGetCurrentTime(i);
    }

    protected static boolean callVideoViewGetIsMuted(int i)
    {
        return ViewManager.getViewManager().videoViewGetIsMuted(i);
    }

    protected static boolean callVideoViewGetIsTouchTogglesPlay(int i)
    {
        return ViewManager.getViewManager().videoViewGetIsTouchTogglesPlay(i);
    }

    protected static int callVideoViewGetTotalTime(int i)
    {
        return ViewManager.getViewManager().videoViewGetTotalTime(i);
    }

    protected static void callVideoViewLoad(int i, String s)
    {
        ViewManager.getViewManager().videoViewLoad(i, s);
    }

    protected static void callVideoViewMute(int i, boolean flag)
    {
        ViewManager.getViewManager().videoViewMute(i, flag);
    }

    protected static void callVideoViewPause(int i)
    {
        ViewManager.getViewManager().videoViewPause(i);
    }

    protected static void callVideoViewPlay(int i)
    {
        ViewManager.getViewManager().videoViewPlay(i);
    }

    protected static void callVideoViewSeek(int i, int j)
    {
        ViewManager.getViewManager().videoViewSeek(i, j);
    }

    protected static void callVideoViewTouchTogglesPlay(int i, boolean flag)
    {
        ViewManager.getViewManager().videoViewTouchTogglesPlay(i, flag);
    }

    protected static void callWebViewCreate(int i, int j, int k, int l, int i1, boolean flag, boolean flag1)
    {
        ViewManager.getViewManager().addWebView(i, j, k, l, i1, flag, flag1);
    }

    protected static void callWebViewRequestGoBack(int i)
    {
        ViewManager.getViewManager().requestWebViewGoBack(i);
    }

    protected static void callWebViewRequestGoForward(int i)
    {
        ViewManager.getViewManager().requestWebViewGoForward(i);
    }

    protected static void callWebViewRequestLoadUrl(int i, String s)
    {
        ViewManager.getViewManager().requestWebViewLoadUrl(i, s);
    }

    protected static void callWebViewRequestReload(int i)
    {
        ViewManager.getViewManager().requestWebViewReload(i);
    }

    protected static void callWebViewRequestStop(int i)
    {
        ViewManager.getViewManager().requestWebViewStop(i);
    }

    protected static File createUniqueFileNameInPicturesDirectory(String s)
    {
        if (s != null) goto _L2; else goto _L1
_L1:
        s = "";
_L10:
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null) goto _L4; else goto _L3
_L3:
        return null;
_L2:
        if (s.length() > 0 && !s.startsWith("."))
        {
            s = (new StringBuilder()).append(".").append(s).toString();
        }
        continue; /* Loop/switch isn't completed */
_L4:
        File file;
        file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        if (file.exists() || file.mkdirs())
        {
            break; /* Loop/switch isn't completed */
        }
        file = new File("/mnt/media/My Files/Pictures");
        if (!file.exists()) goto _L3; else goto _L5
_L5:
        String s1;
        int i;
        ApplicationInfo applicationinfo = context.getApplicationInfo();
        s1 = (String)context.getPackageManager().getApplicationLabel(applicationinfo);
        if (s1 == null || s1.length() <= 0)
        {
            s1 = "Corona";
        }
        i = 1;
_L7:
        if (i > 10000)
        {
            break; /* Loop/switch isn't completed */
        }
        File file1;
        boolean flag;
        file1 = new File(file, (new StringBuilder()).append(s1).append(" Picture ").append(Integer.toString(i)).append(s).toString());
        flag = file1.exists();
        if (!flag)
        {
            return file1;
        }
        i++;
        if (true) goto _L7; else goto _L6
_L6:
        if (true) goto _L3; else goto _L8
_L8:
        Exception exception;
        exception;
        exception.printStackTrace();
        return null;
        if (true) goto _L10; else goto _L9
_L9:
    }

    private android.graphics.BitmapFactory.Options getBitmapFileInfo(String s)
    {
        android.graphics.BitmapFactory.Options options;
        InputStream inputstream;
        options = null;
        if (s == null || s.length() <= 0)
        {
            return null;
        }
        inputstream = null;
        inputstream = (new FileServices(myActivity)).openFile(s);
        options = null;
        if (inputstream == null)
        {
            break MISSING_BLOCK_LABEL_76;
        }
        android.graphics.BitmapFactory.Options options1 = new android.graphics.BitmapFactory.Options();
        int i;
        options1.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(inputstream, null, options1);
        i = options1.outWidth;
        Exception exception;
        Exception exception2;
        if (i < 0)
        {
            options = null;
        } else
        {
            options = options1;
        }
        if (inputstream != null)
        {
            try
            {
                inputstream.close();
            }
            catch (Exception exception4) { }
        }
        return options;
        exception2;
_L4:
        exception2.printStackTrace();
        if (inputstream != null)
        {
            try
            {
                inputstream.close();
            }
            catch (Exception exception3) { }
        }
        break MISSING_BLOCK_LABEL_84;
        exception;
_L2:
        if (inputstream != null)
        {
            try
            {
                inputstream.close();
            }
            catch (Exception exception1) { }
        }
        throw exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
        exception2;
        options = options1;
        if (true) goto _L4; else goto _L3
_L3:
    }

    private static NativeToJavaBridge getBridge()
    {
        return Controller.getBridge();
    }

    private static DisplayMetrics getDisplayMetrics()
    {
        Context context = CoronaEnvironment.getApplicationContext();
        WindowManager windowmanager;
        if (context != null)
        {
            if ((windowmanager = (WindowManager)context.getSystemService("window")) != null)
            {
                DisplayMetrics displaymetrics = new DisplayMetrics();
                windowmanager.getDefaultDisplay().getMetrics(displaymetrics);
                return displaymetrics;
            }
        }
        return null;
    }

    private int getImageExifRotationInDegreesFrom(String s)
    {
        while (s == null || s.length() <= 0 || (new FileServices(CoronaEnvironment.getApplicationContext())).isAssetFile(s)) 
        {
            return 0;
        }
        int i;
        try
        {
            i = (new ExifInterface(s)).getAttributeInt("Orientation", 1);
        }
        catch (Exception exception)
        {
            return 0;
        }
        switch (i)
        {
        case 4: // '\004'
        case 5: // '\005'
        case 7: // '\007'
        default:
            return 0;

        case 3: // '\003'
            return 180;

        case 6: // '\006'
            return 90;

        case 8: // '\b'
            return 270;
        }
    }

    private static Location getLocationFromName(String s)
    {
        Location location;
        AndroidHttpClient androidhttpclient;
        location = null;
        if (s == null)
        {
            break MISSING_BLOCK_LABEL_227;
        }
        int i = s.length();
        location = null;
        if (i <= 0)
        {
            break MISSING_BLOCK_LABEL_227;
        }
        androidhttpclient = null;
        HttpResponse httpresponse;
        int j;
        String s1 = (new StringBuilder()).append("http://maps.googleapis.com/maps/api/geocode/json?address=").append(URLEncoder.encode(s)).append("&sensor=true").toString();
        androidhttpclient = AndroidHttpClient.newInstance("Android");
        httpresponse = androidhttpclient.execute(new HttpGet(s1));
        j = httpresponse.getStatusLine().getStatusCode();
        location = null;
        if (j != 200)
        {
            break MISSING_BLOCK_LABEL_219;
        }
        HttpEntity httpentity = httpresponse.getEntity();
        location = null;
        if (httpentity == null)
        {
            break MISSING_BLOCK_LABEL_219;
        }
        String s2 = EntityUtils.toString(httpresponse.getEntity());
        location = null;
        if (s2 == null)
        {
            break MISSING_BLOCK_LABEL_219;
        }
        int k = s2.length();
        location = null;
        if (k <= 0)
        {
            break MISSING_BLOCK_LABEL_219;
        }
        JSONObject jsonobject;
        Location location1;
        jsonobject = (new JSONObject(s2)).getJSONArray("results").getJSONObject(0).getJSONObject("geometry").getJSONObject("location");
        location1 = new Location("Google");
        location1.setLatitude(jsonobject.getDouble("lat"));
        location1.setLongitude(jsonobject.getDouble("lng"));
        location = location1;
        Exception exception;
        Exception exception2;
        if (androidhttpclient != null)
        {
            try
            {
                androidhttpclient.close();
            }
            catch (Exception exception4)
            {
                return location;
            }
        }
        return location;
        exception2;
_L4:
        exception2.printStackTrace();
        if (androidhttpclient != null)
        {
            try
            {
                androidhttpclient.close();
            }
            catch (Exception exception3)
            {
                return location;
            }
            return location;
        } else
        {
            break MISSING_BLOCK_LABEL_227;
        }
        exception;
_L2:
        if (androidhttpclient != null)
        {
            try
            {
                androidhttpclient.close();
            }
            catch (Exception exception1) { }
        }
        throw exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
        exception2;
        location = location1;
        if (true) goto _L4; else goto _L3
_L3:
    }

    private boolean getRawAssetExists(String s)
    {
        if (s != null && s.length() > 0) goto _L2; else goto _L1
_L1:
        boolean flag = false;
_L4:
        return flag;
_L2:
        Uri uri = Uri.parse(Uri.encode(s, ":/\\."));
        String s1 = uri.getScheme();
        if (s1 == null)
        {
            s1 = "";
        }
        if (!s1.toLowerCase().equals("android.app.icon"))
        {
            break MISSING_BLOCK_LABEL_101;
        }
        Context context;
        String s2;
        PackageInfo packageinfo;
        try
        {
            s2 = uri.getHost();
        }
        catch (Exception exception)
        {
            return false;
        }
        if (s2 == null)
        {
            break; /* Loop/switch isn't completed */
        }
        if (s2.length() <= 0)
        {
            break; /* Loop/switch isn't completed */
        }
        packageinfo = CoronaEnvironment.getApplicationContext().getPackageManager().getPackageInfo(s2, 0);
        return packageinfo != null;
        context = CoronaEnvironment.getApplicationContext();
        flag = false;
        if (context != null)
        {
            flag = (new FileServices(context)).doesAssetFileExist(s);
        }
        if (!flag)
        {
            Log.v("Corona", (new StringBuilder()).append("WARNING: Asset file \"").append(s).append("\" does not exist.").toString());
            return flag;
        }
        if (true) goto _L4; else goto _L3
_L3:
        return true;
    }

    protected static int instantiateClass(LuaState luastate, CoronaRuntime coronaruntime, Class class1)
    {
        boolean flag;
        int i;
        JavaFunction javafunction;
        Object obj;
        CoronaRuntimeListener coronaruntimelistener;
        try
        {
            flag = com/naef/jnlua/JavaFunction.isAssignableFrom(class1);
        }
        catch (Exception exception)
        {
            Log.v("Corona", (new StringBuilder()).append("ERROR: Could not instantiate class (").append(class1.getName()).append("): ").append(exception.getLocalizedMessage()).toString());
            exception.printStackTrace();
            return 0;
        }
        i = 0;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_102;
        }
        javafunction = (JavaFunction)sPluginCache.get(class1.getName());
        if (javafunction != null)
        {
            break MISSING_BLOCK_LABEL_93;
        }
        obj = class1.newInstance();
        if (com/ansca/corona/CoronaRuntimeListener.isAssignableFrom(class1))
        {
            coronaruntimelistener = (CoronaRuntimeListener)obj;
            CoronaEnvironment.addRuntimeListener(coronaruntimelistener);
            coronaruntimelistener.onLoaded(coronaruntime);
        }
        javafunction = (JavaFunction)obj;
        sPluginCache.put(class1.getName(), javafunction);
        luastate.pushJavaFunction(javafunction);
        i = 1;
        return i;
    }

    private LoadBitmapResult loadBitmap(String s, int i, int j, boolean flag)
    {
        int k;
        InputStream inputstream;
        int i1;
        android.graphics.BitmapFactory.Options options1;
        android.graphics.BitmapFactory.Options options = getBitmapFileInfo(s);
        if (options == null)
        {
            return null;
        }
        k = options.outWidth;
        int l = options.outHeight;
        FileServices fileservices = new FileServices(getBridge().getActivity());
        boolean flag1 = fileservices.isAssetFile(s);
        inputstream = fileservices.openFile(s);
        if (inputstream == null)
        {
            return null;
        }
        i1 = 0;
        if (!flag1)
        {
            i1 = getImageExifRotationInDegreesFrom(s);
        }
        int j1;
        if (i > 0 && j > 0)
        {
            if (i < j)
            {
                j1 = i;
            } else
            {
                j1 = j;
            }
        } else
        if (i > 0)
        {
            j1 = i;
        } else
        {
            j1 = 0;
            if (j > 0)
            {
                j1 = j;
            }
        }
        options1 = new android.graphics.BitmapFactory.Options();
        options1.inSampleSize = 1;
        if (j1 > 0)
        {
            for (float f2 = (float)Math.max(k, l) / (float)j1; f2 > 1.0F; f2 /= 2.0F)
            {
                options1.inSampleSize = 2 * options1.inSampleSize;
            }

            if (options1.inSampleSize > 1)
            {
                Log.v("Corona", (new StringBuilder()).append("Downsampling image file '").append(s).append("' to fit max pixel size of ").append(Integer.toString(j1)).append(".").toString());
            }
        }
        long l1 = 0x1e8480L + 4L * (long)((k * l) / options1.inSampleSize);
        options1.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
        if (l1 > Runtime.getRuntime().maxMemory())
        {
            Log.v("Corona", (new StringBuilder()).append("Not enough memory to load file '").append(s).append("' as a 32-bit image. Reducing the image quality to 16-bit.").toString());
            options1.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
        }
        if (flag)
        {
            int k1 = k;
            int i2 = l;
            float f1 = 1.0F;
            if (options1.inSampleSize > 1)
            {
                k1 = k / options1.inSampleSize;
                if (k % options1.inSampleSize > 0)
                {
                    k1++;
                }
                i2 = l / options1.inSampleSize;
                if (l % options1.inSampleSize > 0)
                {
                    i2++;
                }
                f1 = (float)k1 / (float)k;
            }
            LoadBitmapResult loadbitmapresult1 = new LoadBitmapResult(k1, i2, f1, i1);
            return loadbitmapresult1;
        }
        Bitmap bitmap1 = BitmapFactory.decodeStream(inputstream, null, options1);
        Bitmap bitmap = bitmap1;
_L1:
        Exception exception;
        OutOfMemoryError outofmemoryerror;
        Exception exception2;
        try
        {
            inputstream.close();
        }
        catch (Exception exception1)
        {
            exception1.printStackTrace();
        }
        if (bitmap == null)
        {
            Log.v("Corona", (new StringBuilder()).append("Unable to decode file '").append(s).append("'").toString());
            return null;
        }
        break MISSING_BLOCK_LABEL_597;
        outofmemoryerror;
label0:
        {
            if (options1.inPreferredConfig != android.graphics.Bitmap.Config.ARGB_8888)
            {
                break label0;
            }
            Log.v("Corona", (new StringBuilder()).append("Failed to load file '").append(s).append("' as a 32-bit image. Reducing the image quality to 16-bit.").toString());
            System.gc();
            options1.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
            bitmap = BitmapFactory.decodeStream(inputstream, null, options1);
        }
          goto _L1
        try
        {
            throw outofmemoryerror;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception2)
        {
            exception2.printStackTrace();
        }
        bitmap = null;
          goto _L1
        exception;
        exception.printStackTrace();
        bitmap = null;
          goto _L1
        float f = 1.0F;
        if (bitmap.getWidth() != k)
        {
            f = (float)bitmap.getWidth() / (float)k;
        }
        LoadBitmapResult loadbitmapresult = new LoadBitmapResult(bitmap, f, i1);
        return loadbitmapresult;
    }

    private void networkRequest(String s, String s1, int i, HashMap hashmap, String s2, String s3)
    {
        AsyncHttpClient asynchttpclient;
        NetworkRequestHandler networkrequesthandler;
        Context context = CoronaEnvironment.getApplicationContext();
        if (context != null)
        {
            context.enforceCallingOrSelfPermission("android.permission.INTERNET", null);
        }
        if (hashmap != null)
        {
            ArrayList arraylist = new ArrayList();
            Iterator iterator = hashmap.entrySet().iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                if (!(entry.getKey() instanceof String))
                {
                    arraylist.add(entry.getKey());
                } else
                if (((String)entry.getKey()).toLowerCase().equals("content-length"))
                {
                    arraylist.add(entry.getKey());
                } else
                {
                    Object obj = entry.getValue();
                    if (obj == null)
                    {
                        entry.setValue("");
                    } else
                    if (obj instanceof Number)
                    {
                        NumberFormat numberformat = NumberFormat.getInstance(Locale.US);
                        numberformat.setMinimumFractionDigits(0);
                        entry.setValue(numberformat.format(((Number)obj).doubleValue()));
                    } else
                    if (!(obj instanceof String))
                    {
                        entry.setValue(obj.toString());
                    }
                }
            } while (true);
            for (Iterator iterator1 = arraylist.iterator(); iterator1.hasNext(); hashmap.remove(iterator1.next())) { }
        }
        asynchttpclient = new AsyncHttpClient("My User Agent");
        networkrequesthandler = new NetworkRequestHandler(i, s3, s);
        try
        {
            new URL(s);
            if (s1.equalsIgnoreCase("get"))
            {
                asynchttpclient.get(s, hashmap, networkrequesthandler);
                return;
            }
        }
        catch (Exception exception)
        {
            if (i != 0)
            {
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.networkRequestEvent(i, exception.getMessage(), s);
                    return;
                }
            }
            break MISSING_BLOCK_LABEL_472;
        }
        if (s1.equalsIgnoreCase("head"))
        {
            asynchttpclient.head(s, hashmap, networkrequesthandler);
            return;
        }
        if (s1.equalsIgnoreCase("delete"))
        {
            asynchttpclient.delete(s, hashmap, networkrequesthandler);
            return;
        }
        if (s1.equalsIgnoreCase("put"))
        {
            asynchttpclient.put(s, hashmap, s2, networkrequesthandler);
            return;
        }
        if (s1.equalsIgnoreCase("post"))
        {
            asynchttpclient.post(s, hashmap, s2, networkrequesthandler);
            return;
        }
        throw new Exception((new StringBuilder()).append("HTTP method '").append(s1).append("' not supported").toString());
    }

    protected static void ping()
    {
        System.out.println("NativeToJavaBridge.ping()");
    }

    private static void pushArgumentsToLuaTable(long l, Intent intent)
    {
        if (l != 0L && intent != null)
        {
            CoronaRuntime coronaruntime = CoronaEnvironment.getCoronaRuntimeByLuaState(l);
            LuaState luastate = null;
            if (coronaruntime != null)
            {
                luastate = coronaruntime.getLuaState();
            }
            if (luastate == null)
            {
                luastate = new LuaState(l);
            }
            int i = luastate.getTop();
            if (luastate.isTable(i))
            {
                Uri uri = intent.getData();
                String s;
                int j;
                String s1;
                String s2;
                int k;
                Bundle bundle;
                if (uri != null)
                {
                    s = uri.toString();
                } else
                {
                    s = "";
                }
                luastate.pushString(s);
                luastate.setField(i, "url");
                luastate.newTable();
                j = luastate.getTop();
                if (uri != null)
                {
                    s1 = uri.toString();
                } else
                {
                    s1 = "";
                }
                luastate.pushString(s1);
                luastate.setField(j, "url");
                s2 = intent.getAction();
                if (s2 == null)
                {
                    s2 = "";
                }
                luastate.pushString(s2);
                luastate.setField(j, "action");
                if (!pushToLua(luastate, intent.getCategories()))
                {
                    luastate.newTable();
                }
                luastate.setField(j, "categories");
                luastate.newTable();
                k = luastate.getTop();
                bundle = intent.getExtras();
                if (bundle != null && bundle.size() > 0)
                {
                    Iterator iterator = bundle.keySet().iterator();
                    do
                    {
                        if (!iterator.hasNext())
                        {
                            break;
                        }
                        String s3 = (String)iterator.next();
                        if (pushToLua(luastate, bundle.get(s3)))
                        {
                            luastate.setField(k, s3);
                        }
                    } while (true);
                }
                luastate.setField(j, "extras");
                luastate.setField(i, "androidIntent");
                if (pushToLua(luastate, intent.getBundleExtra("notification")))
                {
                    luastate.setField(i, "notification");
                    return;
                }
            }
        }
    }

    private static boolean pushToLua(LuaState luastate, Object obj)
    {
        if (luastate != null && obj != null) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if (!(obj instanceof Boolean)) goto _L4; else goto _L3
_L3:
        luastate.pushBoolean(((Boolean)obj).booleanValue());
_L6:
        return true;
_L4:
        if ((obj instanceof Float) || (obj instanceof Double))
        {
            luastate.pushNumber(((Number)obj).doubleValue());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Number)
        {
            luastate.pushInteger(((Number)obj).intValue());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Character)
        {
            luastate.pushString(obj.toString());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof String)
        {
            luastate.pushString((String)obj);
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof File)
        {
            luastate.pushString(((File)obj).getAbsolutePath());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Uri)
        {
            luastate.pushString(obj.toString());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof CoronaData)
        {
            ((CoronaData)obj).pushTo(luastate);
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Bundle)
        {
            Bundle bundle = (Bundle)obj;
            if (bundle.size() > 0)
            {
                luastate.newTable(0, bundle.size());
                int k1 = luastate.getTop();
                Iterator iterator2 = bundle.keySet().iterator();
                do
                {
                    String s;
                    do
                    {
                        if (!iterator2.hasNext())
                        {
                            continue; /* Loop/switch isn't completed */
                        }
                        s = (String)iterator2.next();
                    } while (!pushToLua(luastate, bundle.get(s)));
                    luastate.setField(k1, s);
                } while (true);
            }
            luastate.newTable();
            continue; /* Loop/switch isn't completed */
        }
        if (obj.getClass().isArray())
        {
            int l = Array.getLength(obj);
            if (l > 0)
            {
                luastate.newTable(l, 0);
                int i1 = luastate.getTop();
                int j1 = 0;
                while (j1 < l) 
                {
                    if (pushToLua(luastate, Array.get(obj, j1)))
                    {
                        luastate.rawSet(i1, j1 + 1);
                    }
                    j1++;
                }
            } else
            {
                luastate.newTable();
            }
            continue; /* Loop/switch isn't completed */
        }
        if (!(obj instanceof Map))
        {
            break; /* Loop/switch isn't completed */
        }
        Map map = (Map)obj;
        if (map.size() > 0)
        {
            luastate.newTable(0, map.size());
            int k = luastate.getTop();
            Iterator iterator1 = map.entrySet().iterator();
            do
            {
                java.util.Map.Entry entry;
                do
                {
                    if (!iterator1.hasNext())
                    {
                        continue; /* Loop/switch isn't completed */
                    }
                    entry = (java.util.Map.Entry)iterator1.next();
                } while (!(entry.getKey() instanceof String) && !(entry.getKey() instanceof Number) || !pushToLua(luastate, entry.getValue()));
                luastate.setField(k, entry.getKey().toString());
            } while (true);
        }
        luastate.newTable();
        if (true) goto _L6; else goto _L5
_L5:
        if (!(obj instanceof Iterable))
        {
            continue; /* Loop/switch isn't completed */
        }
        luastate.newTable();
        int i = luastate.getTop();
        int j = 0;
        Iterator iterator = ((Iterable)obj).iterator();
        while (iterator.hasNext()) 
        {
            if (pushToLua(luastate, iterator.next()))
            {
                luastate.rawSet(i, j + 1);
            }
            j++;
        }
        if (true) goto _L6; else goto _L7
_L7:
        if (true) goto _L1; else goto _L8
_L8:
    }

    public CoronaActivity getActivity()
    {
        return myActivity;
    }

    public String getDexCacheDir()
    {
        return myDexCacheDir;
    }


}
