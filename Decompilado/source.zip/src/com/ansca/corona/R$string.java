// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            R

public static final class 
{

    public static final int com_facebook_choose_friends = 0x7f06000f;
    public static final int com_facebook_dialogloginactivity_ok_button = 0x7f060000;
    public static final int com_facebook_internet_permission_error_message = 0x7f060013;
    public static final int com_facebook_internet_permission_error_title = 0x7f060012;
    public static final int com_facebook_loading = 0x7f060011;
    public static final int com_facebook_loginview_cancel_action = 0x7f060006;
    public static final int com_facebook_loginview_log_in_button = 0x7f060002;
    public static final int com_facebook_loginview_log_out_action = 0x7f060005;
    public static final int com_facebook_loginview_log_out_button = 0x7f060001;
    public static final int com_facebook_loginview_logged_in_as = 0x7f060003;
    public static final int com_facebook_loginview_logged_in_using_facebook = 0x7f060004;
    public static final int com_facebook_logo_content_description = 0x7f060007;
    public static final int com_facebook_nearby = 0x7f060010;
    public static final int com_facebook_picker_done_button_text = 0x7f06000e;
    public static final int com_facebook_placepicker_subtitle_catetory_only_format = 0x7f06000c;
    public static final int com_facebook_placepicker_subtitle_format = 0x7f06000b;
    public static final int com_facebook_placepicker_subtitle_were_here_only_format = 0x7f06000d;
    public static final int com_facebook_requesterror_password_changed = 0x7f060016;
    public static final int com_facebook_requesterror_permissions = 0x7f060018;
    public static final int com_facebook_requesterror_reconnect = 0x7f060017;
    public static final int com_facebook_requesterror_relogin = 0x7f060015;
    public static final int com_facebook_requesterror_web_login = 0x7f060014;
    public static final int com_facebook_usersettingsfragment_log_in_button = 0x7f060008;
    public static final int com_facebook_usersettingsfragment_logged_in = 0x7f060009;
    public static final int com_facebook_usersettingsfragment_not_logged_in = 0x7f06000a;

    public ()
    {
    }
}
