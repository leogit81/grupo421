// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.maps.MapType;
import com.ansca.corona.maps.MapView;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.mapType
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final MapType val$mapType;

    public void run()
    {
        MapView mapview = (MapView)getDisplayObjectById(com/ansca/corona/maps/MapView, val$id);
        if (mapview != null)
        {
            mapview.setMapType(val$mapType);
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$mapType = MapType.this;
        super();
    }
}
