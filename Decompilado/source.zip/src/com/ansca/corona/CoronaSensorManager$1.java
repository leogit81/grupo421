// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.util.Log;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            CoronaSensorManager, Controller, CoronaActivity

class val.eventType
    implements Runnable
{

    final CoronaSensorManager this$0;
    final int val$eventType;

    public void run()
    {
        val$eventType;
        JVM INSTR tableswitch 0 5: default 44
    //                   0 44
    //                   1 45
    //                   2 56
    //                   3 129
    //                   4 67
    //                   5 44;
           goto _L1 _L1 _L2 _L3 _L4 _L5 _L1
_L1:
        return;
_L2:
        CoronaSensorManager.access$000(CoronaSensorManager.this).start();
        return;
_L3:
        CoronaSensorManager.access$100(CoronaSensorManager.this).start();
        return;
_L5:
        CoronaSensorManager.access$202(CoronaSensorManager.this, CoronaSensorManager.access$300(CoronaSensorManager.this).getDefaultSensor(3));
        CoronaSensorManager.access$402(CoronaSensorManager.this, new SensorEventListener() {

            final CoronaSensorManager._cls1 this$1;

            public void onAccuracyChanged(Sensor sensor, int j)
            {
            }

            public void onSensorChanged(SensorEvent sensorevent)
            {
                this;
                JVM INSTR monitorenter ;
                Controller controller1 = Controller.getController();
                if (controller1 != null)
                {
                    break MISSING_BLOCK_LABEL_13;
                }
                this;
                JVM INSTR monitorexit ;
                return;
                float f = sensorevent.values[0];
                if (!controller1.isNaturalOrientationPortrait())
                {
                    f -= 90F;
                    if (f < 0.0F)
                    {
                        f += 360F;
                    }
                }
                EventManager eventmanager;
                if (CoronaSensorManager.access$500(this$0) == f)
                {
                    break MISSING_BLOCK_LABEL_103;
                }
                CoronaSensorManager.access$502(this$0, f);
                eventmanager = Controller.getEventManager();
                if (eventmanager == null)
                {
                    break MISSING_BLOCK_LABEL_103;
                }
                eventmanager.headingEvent(CoronaSensorManager.access$500(this$0));
                this;
                JVM INSTR monitorexit ;
                return;
                Exception exception;
                exception;
                this;
                JVM INSTR monitorexit ;
                throw exception;
            }

            
            {
                this$1 = CoronaSensorManager._cls1.this;
                super();
            }
        });
        CoronaSensorManager.access$300(CoronaSensorManager.this).registerListener(CoronaSensorManager.access$400(CoronaSensorManager.this), CoronaSensorManager.access$200(CoronaSensorManager.this), 2);
        return;
_L4:
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity != null)
        {
            PackageManager packagemanager = coronaactivity.getPackageManager();
            boolean flag = packagemanager.hasSystemFeature("android.hardware.location.gps");
            boolean flag1 = packagemanager.hasSystemFeature("android.hardware.location.network");
            if (!flag && !flag1)
            {
                Log.v("Corona", "Unable to set up location listener. This device is incapable of providing location data.");
                return;
            }
            CoronaSensorManager.access$602(CoronaSensorManager.this, new ronaLocationListener(CoronaSensorManager.this, null));
            boolean flag2 = false;
            if (flag)
            {
                int i = coronaactivity.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION");
                flag2 = false;
                if (i == 0)
                {
                    CoronaSensorManager.access$600(CoronaSensorManager.this).setSupportsGps();
                    CoronaSensorManager.access$900(CoronaSensorManager.this).requestLocationUpdates("gps", 1000L, (float)CoronaSensorManager.access$800(CoronaSensorManager.this), CoronaSensorManager.access$600(CoronaSensorManager.this));
                    flag2 = true;
                }
            }
            if (flag1 && coronaactivity.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0)
            {
                CoronaSensorManager.access$600(CoronaSensorManager.this).setSupportsNetwork();
                CoronaSensorManager.access$900(CoronaSensorManager.this).requestLocationUpdates("network", 1000L, (float)CoronaSensorManager.access$800(CoronaSensorManager.this), CoronaSensorManager.access$600(CoronaSensorManager.this));
                flag2 = true;
            }
            if (!flag2)
            {
                Log.v("Corona", (new StringBuilder()).append("Warning: ").append("This application does not have permission to read your current location.").toString());
                Controller controller = Controller.getController();
                if (controller != null)
                {
                    controller.showNativeAlert("Corona", "This application does not have permission to read your current location.", new String[] {
                        "OK"
                    });
                    return;
                }
            }
        }
        if (true) goto _L1; else goto _L6
_L6:
    }

    _cls1.this._cls1()
    {
        this$0 = final_coronasensormanager;
        val$eventType = I.this;
        super();
    }
}
