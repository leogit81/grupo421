// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import com.ansca.corona.storage.ResourceServices;
import java.io.File;
import java.io.FileOutputStream;

// Referenced classes of package com.ansca.corona:
//            CameraView, CameraServices, Controller

public class CameraActivity extends Activity
{

    private static int sNextImageFileNumber = 1;
    private CameraView fCameraView;

    public CameraActivity()
    {
    }

    public static void clearCachedPhotos(Context context)
    {
        int i = 1;
_L3:
        if (i >= sNextImageFileNumber) goto _L2; else goto _L1
_L1:
        File file = createCameraShotFileObjectWith(context, i);
        if (file != null)
        {
            try
            {
                file.delete();
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }
        i++;
          goto _L3
_L2:
        sNextImageFileNumber = 1;
        return;
    }

    private static File createCameraShotFileObjectWith(Context context, int i)
    {
        if (context == null)
        {
            return null;
        } else
        {
            return new File(context.getCacheDir(), (new StringBuilder()).append("CameraShot").append(Integer.toString(i)).append(".jpg").toString());
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        ResourceServices resourceservices = new ResourceServices(this);
        FrameLayout framelayout = new FrameLayout(this);
        setContentView(framelayout);
        fCameraView = new CameraView(this);
        framelayout.addView(fCameraView);
        fCameraView.setTakePictureListener(new android.hardware.Camera.PictureCallback() {

            final CameraActivity this$0;

            public void onPictureTaken(byte abyte0[], Camera camera)
            {
                if (abyte0 != null && abyte0.length > 0 && Controller.isValid()) goto _L2; else goto _L1
_L1:
                return;
_L2:
                Uri uri;
                boolean flag;
                boolean flag1;
                Intent intent = getIntent();
                uri = null;
                if (intent != null)
                {
                    uri = getIntent().getData();
                    if (uri == null && getIntent().getExtras() != null)
                    {
                        uri = (Uri)getIntent().getExtras().get("output");
                    }
                }
                flag = true;
                if (uri == null)
                {
                    uri = Uri.fromFile(CameraActivity.createCameraShotFileObjectWith(CameraActivity.this, CameraActivity.sNextImageFileNumber));
                    flag = false;
                }
                flag1 = false;
                FileOutputStream fileoutputstream = new FileOutputStream(uri.getPath());
                fileoutputstream.write(abyte0);
                fileoutputstream.flush();
                fileoutputstream.close();
                flag1 = true;
                if (!flag)
                {
                    try
                    {
                        int i = 
// JavaClassFileOutputException: get_constant: invalid tag

            
            {
                this$0 = CameraActivity.this;
                super();
            }
        });
        FrameLayout framelayout1 = new FrameLayout(this);
        framelayout1.setBackgroundColor(Color.argb(192, 0, 0, 0));
        framelayout.addView(framelayout1, new LayoutParams(-1, -2, 80));
        ImageButton imagebutton = new ImageButton(this);
        imagebutton.setPadding(2, 2, 2, 2);
        imagebutton.setBackgroundColor(0);
        imagebutton.setImageResource(resourceservices.getDrawableResourceId("ic_menu_camera"));
        framelayout1.addView(imagebutton, new LayoutParams(-2, -2, 17));
        imagebutton.setOnClickListener(new android.view.View.OnClickListener() {

            final CameraActivity this$0;

            public void onClick(View view)
            {
                fCameraView.takePicture();
            }

            
            {
                this$0 = CameraActivity.this;
                super();
            }
        });
        if (CameraServices.getCameraCount() > 1)
        {
            ImageButton imagebutton1 = new ImageButton(this);
            imagebutton1.setPadding(2, 2, 2, 2);
            imagebutton1.setBackgroundColor(0);
            imagebutton1.setImageResource(resourceservices.getDrawableResourceId("ic_menu_refresh"));
            framelayout1.addView(imagebutton1, new LayoutParams(-2, -2, 21));
            imagebutton1.setOnClickListener(new android.view.View.OnClickListener() {

                final CameraActivity this$0;

                public void onClick(View view)
                {
                    int i = (1 + fCameraView.getSelectedCameraIndex()) % CameraServices.getCameraCount();
                    fCameraView.selectCameraByIndex(i);
                }

            
            {
                this$0 = CameraActivity.this;
                super();
            }
            });
        }
    }

    public boolean onKeyUp(int i, KeyEvent keyevent)
    {
        i;
        JVM INSTR lookupswitch 2: default 28
    //                   23: 35
    //                   27: 35;
           goto _L1 _L2 _L2
_L1:
        return onKeyUp(i, keyevent);
_L2:
        fCameraView.takePicture();
        if (true) goto _L1; else goto _L3
_L3:
    }




/*
    static int access$008()
    {
        int i = sNextImageFileNumber;
        sNextImageFileNumber = i + 1;
        return i;
    }

*/


}
