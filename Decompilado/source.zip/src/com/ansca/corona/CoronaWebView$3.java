// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            CoronaWebView, JavaToNativeShim

class val.id
    implements Runnable
{

    final CoronaWebView this$0;
    final int val$id;

    public void run()
    {
        JavaToNativeShim.webViewClosed(val$id);
    }

    ()
    {
        this$0 = final_coronawebview;
        val$id = I.this;
        super();
    }
}
