// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.media.AudioRecord;
import android.os.Process;
import com.ansca.corona.version.IAndroidVersionSpecific;
import java.util.LinkedList;

// Referenced classes of package com.ansca.corona:
//            AudioRecorder, Controller

private class myFreeBuffers extends Thread
{

    static final int MAX_BUFFERS = 5;
    private AudioRecord myAudioRecordInstance;
    private int myBufferSize;
    private LinkedList myBuffers;
    private float myFrameSeconds;
    private LinkedList myFreeBuffers;
    final AudioRecorder this$0;

    r getNextBuffer()
    {
        LinkedList linkedlist = myBuffers;
        linkedlist;
        JVM INSTR monitorenter ;
        r r;
        if (myBuffers.isEmpty())
        {
            break MISSING_BLOCK_LABEL_32;
        }
        r = (r)myBuffers.remove();
        return r;
        linkedlist;
        JVM INSTR monitorexit ;
        return null;
        Exception exception;
        exception;
        linkedlist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    void releaseBuffer(r r)
    {
        synchronized (myFreeBuffers)
        {
            myFreeBuffers.add(r);
            if (!AudioRecorder.access$000(AudioRecorder.this))
            {
                myFreeBuffers.clear();
            }
        }
        return;
        exception;
        linkedlist;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void run()
    {
        r r;
        int i;
        int j;
        int l;
        try
        {
            Process.setThreadPriority(-19);
            i = AudioRecord.getMinBufferSize(8000, Controller.getAndroidVersionSpecific().audioChannelMono(), 2);
            j = (int)(16000F * myFrameSeconds);
        }
        catch (Exception exception)
        {
            AudioRecorder.access$100(AudioRecorder.this, -1);
            return;
        }
        if (j < i)
        {
            j = i;
        }
        myBufferSize = j;
        myAudioRecordInstance = new AudioRecord(1, 8000, Controller.getAndroidVersionSpecific().audioChannelMono(), 2, myBufferSize);
        myFreeBuffers.add(new r(myBufferSize));
        myAudioRecordInstance.startRecording();
_L5:
        if (!AudioRecorder.access$000(AudioRecorder.this))
        {
            break MISSING_BLOCK_LABEL_270;
        }
        this;
        JVM INSTR monitorenter ;
        if (myFreeBuffers.isEmpty()) goto _L2; else goto _L1
_L1:
        r = (r)myFreeBuffers.remove();
_L7:
        this;
        JVM INSTR monitorexit ;
        if (r == null) goto _L4; else goto _L3
_L3:
        l = myAudioRecordInstance.read(r.myBuffer, myBufferSize);
        this;
        JVM INSTR monitorenter ;
        if (l <= 0)
        {
            break MISSING_BLOCK_LABEL_250;
        }
        r.myValidBytes = l;
        myBuffers.add(r);
        AudioRecorder.access$100(AudioRecorder.this, l);
_L8:
        this;
        JVM INSTR monitorexit ;
_L4:
        sleep(15L);
          goto _L5
_L2:
        int k = myBuffers.size();
        r = null;
        if (k >= 5) goto _L7; else goto _L6
_L6:
        r = new r(myBufferSize);
          goto _L7
        Exception exception1;
        exception1;
        this;
        JVM INSTR monitorexit ;
        throw exception1;
        myFreeBuffers.add(r);
          goto _L8
        Exception exception2;
        exception2;
        this;
        JVM INSTR monitorexit ;
        throw exception2;
        myAudioRecordInstance.stop();
        AudioRecorder.access$100(AudioRecorder.this, 0);
        return;
          goto _L5
    }

    void startRecording()
    {
        start();
    }

    void stopRecording()
    {
        AudioRecorder.access$002(AudioRecorder.this, false);
    }

    r()
    {
        this$0 = AudioRecorder.this;
        super();
        myFrameSeconds = 0.1F;
        myBuffers = new LinkedList();
        myFreeBuffers = new LinkedList();
    }
}
