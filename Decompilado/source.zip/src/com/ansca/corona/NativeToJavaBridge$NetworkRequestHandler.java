// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.events.EventManager;
import com.loopj.android.http.AsyncHttpResponseHandler;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;

// Referenced classes of package com.ansca.corona:
//            Controller, NativeToJavaBridge

private class fUrl extends AsyncHttpResponseHandler
{

    private String fFilePath;
    private boolean fHasErrorOccurred;
    private int fListenerId;
    private String fResponseMessage;
    private int fStatusCode;
    private String fUrl;
    final NativeToJavaBridge this$0;

    protected void handleResponseMessage(HttpResponse httpresponse)
    {
        if (fHasErrorOccurred)
        {
            onFailure(fResponseMessage);
            return;
        } else
        {
            fStatusCode = httpresponse.getStatusLine().getStatusCode();
            onSuccess(fResponseMessage);
            return;
        }
    }

    public void onFailure(String s)
    {
        if (fListenerId != 0)
        {
            if (s == null)
            {
                s = "";
            }
            EventManager eventmanager = Controller.getEventManager();
            if (eventmanager != null)
            {
                eventmanager.networkRequestEvent(fListenerId, s, fUrl);
            }
        }
    }

    public void onFailure(Throwable throwable)
    {
        String s;
        if (throwable != null)
        {
            s = throwable.getMessage();
        } else
        {
            s = "";
        }
        onFailure(s);
    }

    public void onStart()
    {
        fHasErrorOccurred = false;
        fResponseMessage = "";
    }

    public void onSuccess(String s)
    {
        if (fListenerId != 0)
        {
            EventManager eventmanager = Controller.getEventManager();
            if (eventmanager != null)
            {
                eventmanager.networkRequestEvent(fListenerId, s, fUrl, fStatusCode);
            }
        }
    }

    public void sendResponseMessage(HttpResponse httpresponse)
    {
        if (httpresponse == null) goto _L2; else goto _L1
_L1:
        if (httpresponse.getEntity() == null) goto _L2; else goto _L3
_L3:
        if (fFilePath == null) goto _L5; else goto _L4
_L4:
        FileOutputStream fileoutputstream = new FileOutputStream(new File(fFilePath));
        httpresponse.getEntity().writeTo(fileoutputstream);
        fileoutputstream.flush();
        fileoutputstream.close();
        fResponseMessage = fFilePath;
_L2:
        fHasErrorOccurred = false;
_L6:
        super.sendResponseMessage(httpresponse);
        return;
_L5:
        fResponseMessage = getResponseBody(httpresponse);
          goto _L2
        Exception exception;
        exception;
        fResponseMessage = exception.getMessage();
        fHasErrorOccurred = true;
          goto _L6
    }

    public (int i, String s, String s1)
    {
        this$0 = NativeToJavaBridge.this;
        super();
        fListenerId = i;
        String s2;
        if (s != null && !s.equals(""))
        {
            s2 = new String(s);
        } else
        {
            s2 = null;
        }
        fFilePath = s2;
        fStatusCode = -1;
        fUrl = s1;
    }
}
