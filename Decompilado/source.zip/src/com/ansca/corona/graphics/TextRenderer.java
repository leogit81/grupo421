// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.text.StaticLayout;
import android.text.TextPaint;
import java.util.HashMap;

// Referenced classes of package com.ansca.corona.graphics:
//            FontSettings, HorizontalAlignment, FontServices

public class TextRenderer
{

    private static HashMap sTextPaintCollection = new HashMap();
    private int fClipHeight;
    private int fClipWidth;
    private Context fContext;
    private FontSettings fFontSettings;
    private HorizontalAlignment fHorizontalAlignment;
    private String fText;
    private int fWrapWidth;

    public TextRenderer(Context context)
    {
        if (context == null)
        {
            throw new NullPointerException();
        } else
        {
            fContext = context;
            fFontSettings = new FontSettings();
            fHorizontalAlignment = HorizontalAlignment.LEFT;
            fWrapWidth = 0;
            fClipWidth = 0;
            fClipHeight = 0;
            fText = "";
            return;
        }
    }

    public Bitmap createBitmap()
    {
        if (fText == null || fText.length() <= 0 || fFontSettings.getPointSize() <= 0.0F)
        {
            return null;
        }
        FontServices fontservices = new FontServices(fContext);
        if (fontservices == null)
        {
            return null;
        }
        android.graphics.Typeface typeface = fontservices.fetchTypefaceFor(fFontSettings);
        if (typeface == null)
        {
            return null;
        }
        TextPaint textpaint;
        synchronized (sTextPaintCollection)
        {
            textpaint = (TextPaint)sTextPaintCollection.get(typeface);
        }
        if (textpaint == null)
        {
            textpaint = new TextPaint();
            textpaint.setARGB(255, 255, 255, 255);
            textpaint.setAntiAlias(true);
            textpaint.setTextAlign(android.graphics.Paint.Align.LEFT);
            textpaint.setTypeface(typeface);
            synchronized (sTextPaintCollection)
            {
                sTextPaintCollection.put(typeface, textpaint);
            }
        }
        textpaint.setTextSize(fFontSettings.getPointSize());
        android.graphics.Paint.FontMetricsInt fontmetricsint = textpaint.getFontMetricsInt();
        int i = fWrapWidth;
        if (i <= 0)
        {
            i = (int)(1.0F + StaticLayout.getDesiredWidth(fText, textpaint));
            if (i < 1)
            {
                i = 1;
            }
        }
        StaticLayout staticlayout = new StaticLayout(fText, textpaint, i, fHorizontalAlignment.toAndroidTextLayoutAlignment(), 1.0F, 1.0F, true);
        int j = fClipHeight;
        if (j <= 0)
        {
            j = (1 + (Math.abs(fontmetricsint.top) + Math.abs(fontmetricsint.bottom))) * staticlayout.getLineCount();
            if (j < 1)
            {
                j = 1;
            }
        }
        if (fClipWidth > 0 && i > fClipWidth)
        {
            i = fClipWidth;
        }
        if (fClipHeight > 0 && j > fClipHeight)
        {
            j = fClipHeight;
        }
        int k = i % 4;
        if (k > 0)
        {
            i += 4 - k;
            if (i > fClipWidth)
            {
                i -= 4;
            }
        }
        Bitmap bitmap = null;
        try
        {
            bitmap = Bitmap.createBitmap(i, j, android.graphics.Bitmap.Config.ALPHA_8);
            staticlayout.draw(new Canvas(bitmap));
        }
        catch (Exception exception2)
        {
            exception2.printStackTrace();
            return bitmap;
        }
        return bitmap;
        exception;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception;
        exception1;
        hashmap1;
        JVM INSTR monitorexit ;
        throw exception1;
    }

    public int getClipHeight()
    {
        return fClipHeight;
    }

    public int getClipWidth()
    {
        return fClipWidth;
    }

    public Context getContext()
    {
        return fContext;
    }

    public FontSettings getFontSettings()
    {
        return fFontSettings;
    }

    public HorizontalAlignment getHorizontalAlignment()
    {
        return fHorizontalAlignment;
    }

    public String getText()
    {
        return fText;
    }

    public int getWrapWidth()
    {
        return fWrapWidth;
    }

    public void setClipHeight(int i)
    {
        if (i < 0)
        {
            i = 0;
        }
        fClipHeight = i;
    }

    public void setClipWidth(int i)
    {
        if (i < 0)
        {
            i = 0;
        }
        fClipWidth = i;
    }

    public void setHorizontalAlignment(HorizontalAlignment horizontalalignment)
    {
        if (horizontalalignment == null)
        {
            throw new NullPointerException();
        } else
        {
            fHorizontalAlignment = horizontalalignment;
            return;
        }
    }

    public void setText(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fText = s;
    }

    public void setWrapWidth(int i)
    {
        if (i < 0)
        {
            i = 0;
        }
        fWrapWidth = i;
    }

}
