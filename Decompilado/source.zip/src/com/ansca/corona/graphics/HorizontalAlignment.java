// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;

import java.lang.reflect.Field;

public class HorizontalAlignment
{

    public static final HorizontalAlignment CENTER;
    public static final HorizontalAlignment LEFT;
    public static final HorizontalAlignment RIGHT;
    private int fAndroidGravityBitField;
    private android.graphics.Paint.Align fAndroidPaintAlignment;
    private android.text.Layout.Alignment fAndroidTextLayoutAlignment;
    private String fCoronaStringId;

    private HorizontalAlignment(String s, int i, android.text.Layout.Alignment alignment, android.graphics.Paint.Align align)
    {
        fCoronaStringId = s;
        fAndroidGravityBitField = i;
        fAndroidTextLayoutAlignment = alignment;
        fAndroidPaintAlignment = align;
    }

    public static HorizontalAlignment fromCoronaStringId(String s)
    {
        Field afield[];
        int i;
        int j;
        Field field;
        HorizontalAlignment horizontalalignment;
        boolean flag;
        try
        {
            afield = com/ansca/corona/graphics/HorizontalAlignment.getDeclaredFields();
            i = afield.length;
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        j = 0;
_L2:
        if (j >= i)
        {
            break; /* Loop/switch isn't completed */
        }
        field = afield[j];
        if (!field.getType().equals(com/ansca/corona/graphics/HorizontalAlignment))
        {
            break MISSING_BLOCK_LABEL_67;
        }
        horizontalalignment = (HorizontalAlignment)field.get(null);
        flag = horizontalalignment.fCoronaStringId.equals(s);
        if (flag)
        {
            return horizontalalignment;
        }
        j++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
        return null;
    }

    public int toAndroidGravityBitField()
    {
        return fAndroidGravityBitField;
    }

    public android.graphics.Paint.Align toAndroidPaintAlignment()
    {
        return fAndroidPaintAlignment;
    }

    public android.text.Layout.Alignment toAndroidTextLayoutAlignment()
    {
        return fAndroidTextLayoutAlignment;
    }

    public String toCoronaStringId()
    {
        return fCoronaStringId;
    }

    public String toString()
    {
        return fCoronaStringId;
    }

    static 
    {
        LEFT = new HorizontalAlignment("left", 3, android.text.Layout.Alignment.ALIGN_NORMAL, android.graphics.Paint.Align.LEFT);
        CENTER = new HorizontalAlignment("center", 1, android.text.Layout.Alignment.ALIGN_CENTER, android.graphics.Paint.Align.CENTER);
        RIGHT = new HorizontalAlignment("right", 5, android.text.Layout.Alignment.ALIGN_OPPOSITE, android.graphics.Paint.Align.RIGHT);
    }
}
