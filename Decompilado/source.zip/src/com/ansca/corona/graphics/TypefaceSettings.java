// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;


public class TypefaceSettings
    implements Cloneable
{

    private boolean fIsBold;
    private boolean fIsItalic;
    private String fName;

    public TypefaceSettings()
    {
        fName = null;
        fIsBold = false;
        fIsItalic = false;
    }

    public TypefaceSettings clone()
    {
        TypefaceSettings typefacesettings;
        try
        {
            typefacesettings = (TypefaceSettings)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return typefacesettings;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean equals(TypefaceSettings typefacesettings)
    {
        if (typefacesettings != this)
        {
            if (typefacesettings == null)
            {
                return false;
            }
            if (fName == null && typefacesettings.fName != null || fName != null && typefacesettings.fName == null)
            {
                return false;
            }
            if (fName != null && !fName.equals(typefacesettings.fName))
            {
                return false;
            }
            if (fIsBold != typefacesettings.fIsBold || fIsItalic != typefacesettings.fIsItalic)
            {
                return false;
            }
        }
        return true;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof TypefaceSettings))
        {
            return false;
        } else
        {
            return equals((TypefaceSettings)obj);
        }
    }

    public int getAndroidTypefaceStyle()
    {
        boolean flag = fIsBold;
        int i = 0;
        if (flag)
        {
            i = false | true;
        }
        if (fIsItalic)
        {
            i |= 2;
        }
        return i;
    }

    public String getName()
    {
        return fName;
    }

    public int hashCode()
    {
        int i = getAndroidTypefaceStyle();
        if (fName != null)
        {
            i ^= fName.hashCode();
        }
        return i;
    }

    public boolean isBold()
    {
        return fIsBold;
    }

    public boolean isItalic()
    {
        return fIsItalic;
    }

    public void setIsBold(boolean flag)
    {
        fIsBold = flag;
    }

    public void setIsItalic(boolean flag)
    {
        fIsItalic = flag;
    }

    public void setName(String s)
    {
        fName = s;
    }
}
