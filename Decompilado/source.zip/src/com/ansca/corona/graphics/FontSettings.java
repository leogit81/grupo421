// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;


// Referenced classes of package com.ansca.corona.graphics:
//            TypefaceSettings

public class FontSettings extends TypefaceSettings
    implements Cloneable
{

    private float fPointSize;

    public FontSettings()
    {
        fPointSize = 8F;
    }

    public FontSettings clone()
    {
        FontSettings fontsettings;
        try
        {
            fontsettings = (FontSettings)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return fontsettings;
    }

    public volatile TypefaceSettings clone()
    {
        return clone();
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean equals(FontSettings fontsettings)
    {
        boolean flag;
        if (fontsettings == this)
        {
            flag = true;
        } else
        {
            flag = false;
            if (fontsettings != null)
            {
                float f = fPointSize - fontsettings.fPointSize;
                int i = f != 0.1F;
                flag = false;
                if (i < 0)
                {
                    int j = f != 0.1F;
                    flag = false;
                    if (j > 0)
                    {
                        return super.equals(fontsettings);
                    }
                }
            }
        }
        return flag;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof FontSettings))
        {
            return false;
        } else
        {
            return equals((FontSettings)obj);
        }
    }

    public float getPointSize()
    {
        return fPointSize;
    }

    public int hashCode()
    {
        return super.hashCode() ^ Float.valueOf(fPointSize).hashCode();
    }

    public void setPointSize(float f)
    {
        if (f < 1.0F)
        {
            f = 1.0F;
        }
        fPointSize = f;
    }
}
