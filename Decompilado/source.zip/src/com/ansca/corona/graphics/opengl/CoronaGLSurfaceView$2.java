// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.content.Context;
import android.view.OrientationEventListener;
import com.ansca.corona.Controller;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.WindowOrientation;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            CoronaGLSurfaceView

class this._cls0 extends OrientationEventListener
{

    final CoronaGLSurfaceView this$0;

    public void onOrientationChanged(int i)
    {
        if (i != -1 && Controller.isValid() && canRender())
        {
            int j = (360 - i) % 360;
            WindowOrientation windoworientation = WindowOrientation.fromDegrees(getContext(), j);
            if (windoworientation != CoronaGLSurfaceView.access$000(CoronaGLSurfaceView.this) || CoronaGLSurfaceView.access$100(CoronaGLSurfaceView.this) == WindowOrientation.UNKNOWN)
            {
                CoronaGLSurfaceView.access$102(CoronaGLSurfaceView.this, CoronaGLSurfaceView.access$000(CoronaGLSurfaceView.this));
                CoronaGLSurfaceView.access$002(CoronaGLSurfaceView.this, windoworientation);
                if (CoronaGLSurfaceView.access$200(CoronaGLSurfaceView.this).hasFixedOrientation())
                {
                    EventManager eventmanager = Controller.getEventManager();
                    if (eventmanager != null)
                    {
                        eventmanager.orientationChanged(CoronaGLSurfaceView.access$000(CoronaGLSurfaceView.this).toCoronaIntegerId(), CoronaGLSurfaceView.access$100(CoronaGLSurfaceView.this).toCoronaIntegerId());
                        return;
                    }
                }
            }
        }
    }

    (Context context)
    {
        this$0 = CoronaGLSurfaceView.this;
        super(context);
    }
}
