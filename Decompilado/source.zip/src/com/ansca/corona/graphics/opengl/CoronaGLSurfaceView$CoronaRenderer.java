// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import com.ansca.corona.Controller;
import com.ansca.corona.JavaToNativeShim;
import com.ansca.corona.WindowOrientation;
import com.ansca.corona.events.EventManager;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            CoronaGLSurfaceView

private static class fLastViewHeight
    implements fLastViewHeight
{

    private static boolean sFirstSurface = true;
    private boolean fCanRender;
    private WindowOrientation fLastReceivedWindowOrientation;
    private int fLastViewHeight;
    private int fLastViewWidth;
    private CoronaGLSurfaceView fView;

    public boolean canRender()
    {
        return fCanRender;
    }

    public void clearFirstSurface()
    {
        sFirstSurface = true;
    }

    public void onDrawFrame(GL10 gl10)
    {
        Controller.updateRuntimeState(fCanRender);
    }

    public void onSurfaceChanged(GL10 gl10, int i, int j)
    {
        WindowOrientation windoworientation;
        WindowOrientation windoworientation1;
        windoworientation = CoronaGLSurfaceView.access$300(fView);
        windoworientation1 = CoronaGLSurfaceView.access$400(fView);
        if (windoworientation.isPortrait() && i > j || windoworientation.isLandscape() && i < j)
        {
            fCanRender = false;
            return;
        }
        JavaToNativeShim.resize(fView.getContext(), i, j, windoworientation);
        fCanRender = true;
        if (fLastReceivedWindowOrientation != WindowOrientation.UNKNOWN) goto _L2; else goto _L1
_L1:
        fLastReceivedWindowOrientation = windoworientation;
_L4:
        if (fLastViewWidth >= 0 && fLastViewHeight >= 0 && (fLastViewWidth != i || fLastViewHeight != j))
        {
            EventManager eventmanager1 = Controller.getEventManager();
            if (eventmanager1 != null)
            {
                eventmanager1.resize();
            }
        }
        fLastViewWidth = i;
        fLastViewHeight = j;
        return;
_L2:
        if (fLastReceivedWindowOrientation != windoworientation)
        {
            fLastReceivedWindowOrientation = windoworientation;
            EventManager eventmanager = Controller.getEventManager();
            if (eventmanager != null)
            {
                eventmanager.orientationChanged(windoworientation.toCoronaIntegerId(), windoworientation1.toCoronaIntegerId());
            }
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eglconfig)
    {
        if (!sFirstSurface)
        {
            fView.setNeedsSwap();
        }
        sFirstSurface = false;
        JavaToNativeShim.unloadResources();
    }


    public I(CoronaGLSurfaceView coronaglsurfaceview)
    {
        if (coronaglsurfaceview == null)
        {
            throw new NullPointerException();
        } else
        {
            fView = coronaglsurfaceview;
            fCanRender = false;
            fLastReceivedWindowOrientation = WindowOrientation.UNKNOWN;
            fLastViewWidth = -1;
            fLastViewHeight = -1;
            return;
        }
    }
}
