// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.content.Context;
import android.opengl.GLDebugHelper;
import android.opengl.GLES10;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.io.Writer;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

public class GLSurfaceView extends SurfaceView
    implements android.view.SurfaceHolder.Callback
{
    private abstract class BaseConfigChooser
        implements EGLConfigChooser
    {

        protected int mConfigSpec[];
        final GLSurfaceView this$0;

        private int[] filterConfigSpec(int ai[])
        {
            if (mEGLContextClientVersion != 2)
            {
                return ai;
            } else
            {
                int i = ai.length;
                int ai1[] = new int[i + 2];
                System.arraycopy(ai, 0, ai1, 0, i - 1);
                ai1[i - 1] = 12352;
                ai1[i] = 4;
                ai1[i + 1] = 12344;
                return ai1;
            }
        }

        public EGLConfig chooseConfig(EGL10 egl10, EGLDisplay egldisplay)
        {
            int ai[] = new int[1];
            if (!egl10.eglChooseConfig(egldisplay, mConfigSpec, null, 0, ai))
            {
                throw new IllegalArgumentException("eglChooseConfig failed");
            }
            int i = ai[0];
            if (i <= 0)
            {
                throw new IllegalArgumentException("No configs match configSpec");
            }
            EGLConfig aeglconfig[] = new EGLConfig[i];
            if (!egl10.eglChooseConfig(egldisplay, mConfigSpec, aeglconfig, i, ai))
            {
                throw new IllegalArgumentException("eglChooseConfig#2 failed");
            }
            EGLConfig eglconfig = chooseConfig(egl10, egldisplay, aeglconfig);
            if (eglconfig == null)
            {
                throw new IllegalArgumentException("No config chosen");
            } else
            {
                return eglconfig;
            }
        }

        abstract EGLConfig chooseConfig(EGL10 egl10, EGLDisplay egldisplay, EGLConfig aeglconfig[]);

        public BaseConfigChooser(int ai[])
        {
            this$0 = GLSurfaceView.this;
            super();
            mConfigSpec = filterConfigSpec(ai);
        }
    }

    private class ComponentSizeChooser extends BaseConfigChooser
    {

        protected int mAlphaSize;
        protected int mBlueSize;
        protected int mDepthSize;
        protected int mGreenSize;
        protected int mRedSize;
        protected int mStencilSize;
        private int mValue[];
        final GLSurfaceView this$0;

        private int findConfigAttrib(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig, int i, int j)
        {
            if (egl10.eglGetConfigAttrib(egldisplay, eglconfig, i, mValue))
            {
                j = mValue[0];
            }
            return j;
        }

        public EGLConfig chooseConfig(EGL10 egl10, EGLDisplay egldisplay, EGLConfig aeglconfig[])
        {
            EGLConfig eglconfig = null;
            int i = 1000;
            int j = aeglconfig.length;
            int k = 0;
            do
            {
                if (k >= j)
                {
                    break;
                }
                EGLConfig eglconfig1 = aeglconfig[k];
                if (findConfigAttrib(egl10, egldisplay, eglconfig1, 12325, 0) >= mDepthSize && findConfigAttrib(egl10, egldisplay, eglconfig1, 12326, 0) >= mStencilSize)
                {
                    int l = findConfigAttrib(egl10, egldisplay, eglconfig1, 12324, 0);
                    int i1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12323, 0);
                    int j1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12322, 0);
                    int k1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12321, 0);
                    int l1 = Math.abs(l - mRedSize) + Math.abs(i1 - mGreenSize) + Math.abs(j1 - mBlueSize) + Math.abs(k1 - mAlphaSize);
                    if (l1 < i)
                    {
                        i = l1;
                        eglconfig = eglconfig1;
                    }
                }
                k++;
            } while (true);
            return eglconfig;
        }

        public int getMinAlphaSize()
        {
            return mAlphaSize;
        }

        public void setMinAlphaSize(int i)
        {
            mAlphaSize = i;
        }

        public ComponentSizeChooser(int i, int j, int k, int l, int i1, int j1)
        {
            this$0 = GLSurfaceView.this;
            super(new int[] {
                12324, i, 12323, j, 12322, k, 12321, 0, 12325, i1, 
                12326, j1, 12327, 12344, 12344
            });
            mValue = new int[1];
            mRedSize = i;
            mGreenSize = j;
            mBlueSize = k;
            mAlphaSize = l;
            mDepthSize = i1;
            mStencilSize = j1;
        }
    }

    private class DefaultContextFactory
        implements EGLContextFactory
    {

        private int EGL_CONTEXT_CLIENT_VERSION;
        final GLSurfaceView this$0;

        public EGLContext createContext(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig)
        {
            int ai[] = new int[3];
            ai[0] = EGL_CONTEXT_CLIENT_VERSION;
            ai[1] = mEGLContextClientVersion;
            ai[2] = 12344;
            EGLContext eglcontext = EGL10.EGL_NO_CONTEXT;
            if (mEGLContextClientVersion == 0)
            {
                ai = null;
            }
            return egl10.eglCreateContext(egldisplay, eglconfig, eglcontext, ai);
        }

        public void destroyContext(EGL10 egl10, EGLDisplay egldisplay, EGLContext eglcontext)
        {
            if (!egl10.eglDestroyContext(egldisplay, eglcontext))
            {
                Log.e("DefaultContextFactory", (new StringBuilder()).append("display:").append(egldisplay).append(" context: ").append(eglcontext).toString());
                EglHelper.throwEglException("eglDestroyContex", egl10.eglGetError());
            }
        }

        private DefaultContextFactory()
        {
            this$0 = GLSurfaceView.this;
            super();
            EGL_CONTEXT_CLIENT_VERSION = 12440;
        }

    }

    private static class DefaultWindowSurfaceFactory
        implements EGLWindowSurfaceFactory
    {

        public EGLSurface createWindowSurface(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig, Object obj)
        {
            EGLSurface eglsurface;
            try
            {
                eglsurface = egl10.eglCreateWindowSurface(egldisplay, eglconfig, obj, null);
            }
            catch (IllegalArgumentException illegalargumentexception)
            {
                Log.e("GLSurfaceView", "eglCreateWindowSurface", illegalargumentexception);
                return null;
            }
            return eglsurface;
        }

        public void destroySurface(EGL10 egl10, EGLDisplay egldisplay, EGLSurface eglsurface)
        {
            egl10.eglDestroySurface(egldisplay, eglsurface);
        }

        private DefaultWindowSurfaceFactory()
        {
        }

    }

    public static interface EGLConfigChooser
    {

        public abstract EGLConfig chooseConfig(EGL10 egl10, EGLDisplay egldisplay);
    }

    public static interface EGLContextFactory
    {

        public abstract EGLContext createContext(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig);

        public abstract void destroyContext(EGL10 egl10, EGLDisplay egldisplay, EGLContext eglcontext);
    }

    public static interface EGLWindowSurfaceFactory
    {

        public abstract EGLSurface createWindowSurface(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig, Object obj);

        public abstract void destroySurface(EGL10 egl10, EGLDisplay egldisplay, EGLSurface eglsurface);
    }

    private static class EglHelper
    {

        EGL10 mEgl;
        EGLConfig mEglConfig;
        EGLContext mEglContext;
        EGLDisplay mEglDisplay;
        EGLSurface mEglSurface;
        private WeakReference mGLSurfaceViewWeakRef;
        private boolean mHasRetriedCreatingSurface;

        private void destroySurfaceImp()
        {
            if (mEglSurface != null && mEglSurface != EGL10.EGL_NO_SURFACE)
            {
                mEgl.eglMakeCurrent(mEglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
                if (glsurfaceview != null)
                {
                    glsurfaceview.mEGLWindowSurfaceFactory.destroySurface(mEgl, mEglDisplay, mEglSurface);
                }
                mEglSurface = null;
            }
        }

        public static String formatEglError(String s, int i)
        {
            return (new StringBuilder()).append(s).append(" failed: ").append(getErrorString(i)).toString();
        }

        public static String getErrorString(int i)
        {
            switch (i)
            {
            default:
                return Integer.toHexString(i);

            case 12288: 
                return "EGL_SUCCESS";

            case 12289: 
                return "EGL_NOT_INITIALIZED";

            case 12290: 
                return "EGL_BAD_ACCESS";

            case 12291: 
                return "EGL_BAD_ALLOC";

            case 12292: 
                return "EGL_BAD_ATTRIBUTE";

            case 12293: 
                return "EGL_BAD_CONFIG";

            case 12294: 
                return "EGL_BAD_CONTEXT";

            case 12295: 
                return "EGL_BAD_CURRENT_SURFACE";

            case 12296: 
                return "EGL_BAD_DISPLAY";

            case 12297: 
                return "EGL_BAD_MATCH";

            case 12298: 
                return "EGL_BAD_NATIVE_PIXMAP";

            case 12299: 
                return "EGL_BAD_NATIVE_WINDOW";

            case 12300: 
                return "EGL_BAD_PARAMETER";

            case 12301: 
                return "EGL_BAD_SURFACE";

            case 12302: 
                return "EGL_CONTEXT_LOST";
            }
        }

        public static void logEglErrorAsWarning(String s, String s1, int i)
        {
            Log.w(s, formatEglError(s1, i));
        }

        private boolean recreateSurface()
        {
            destroySurfaceImp();
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview != null && mEglContext != null)
            {
                SurfaceHolder surfaceholder = glsurfaceview.getHolder();
                if (surfaceholder != null && surfaceholder.getSurface() != null && surfaceholder.getSurface().isValid())
                {
                    glsurfaceview.mEGLContextFactory.destroyContext(mEgl, mEglDisplay, mEglContext);
                }
                mEglContext = null;
            }
            start();
            return createSurface();
        }

        private void throwEglException(String s)
        {
            throwEglException(s, mEgl.eglGetError());
        }

        public static void throwEglException(String s, int i)
        {
            throw new RuntimeException(formatEglError(s, i));
        }

        GL createGL()
        {
            GL gl = mEglContext.getGL();
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview != null)
            {
                if (glsurfaceview.mGLWrapper != null)
                {
                    gl = glsurfaceview.mGLWrapper.wrap(gl);
                }
                if ((3 & glsurfaceview.mDebugFlags) != 0)
                {
                    int i = 1 & glsurfaceview.mDebugFlags;
                    int j = 0;
                    if (i != 0)
                    {
                        j = false | true;
                    }
                    int k = 2 & glsurfaceview.mDebugFlags;
                    LogWriter logwriter = null;
                    if (k != 0)
                    {
                        logwriter = new LogWriter();
                    }
                    gl = GLDebugHelper.wrap(gl, j, logwriter);
                }
            }
            return gl;
        }

        public boolean createSurface()
        {
            GLSurfaceView glsurfaceview;
            if (mEgl == null)
            {
                throw new RuntimeException("egl not initialized");
            }
            if (mEglDisplay == null)
            {
                throw new RuntimeException("eglDisplay not initialized");
            }
            if (mEglConfig == null)
            {
                throw new RuntimeException("mEglConfig not initialized");
            }
            destroySurfaceImp();
            mEglSurface = null;
            glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview != null)
            {
                SurfaceHolder surfaceholder = glsurfaceview.getHolder();
                if (surfaceholder != null && surfaceholder.getSurface() != null && surfaceholder.getSurface().isValid())
                {
                    mEglSurface = glsurfaceview.mEGLWindowSurfaceFactory.createWindowSurface(mEgl, mEglDisplay, mEglConfig, surfaceholder);
                }
            }
            if (mEglSurface == null || mEglSurface == EGL10.EGL_NO_SURFACE)
            {
                if (mEgl.eglGetError() == 12299)
                {
                    Log.e("EglHelper", "createWindowSurface returned EGL_BAD_NATIVE_WINDOW.");
                }
                return false;
            }
            if (!mEgl.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext))
            {
                logEglErrorAsWarning("EGLHelper", "eglMakeCurrent", mEgl.eglGetError());
                return false;
            }
            if (mHasRetriedCreatingSurface) goto _L2; else goto _L1
_L1:
            String s = GLES10.glGetString(7937);
            if (s == null || !s.equals("PowerVR SGX 540") || !(glsurfaceview.mEGLConfigChooser instanceof ComponentSizeChooser) || ((ComponentSizeChooser)glsurfaceview.mEGLConfigChooser).getMinAlphaSize() <= 0) goto _L2; else goto _L3
_L3:
            int i;
            i = ((ComponentSizeChooser)glsurfaceview.mEGLConfigChooser).getMinAlphaSize();
            ((ComponentSizeChooser)glsurfaceview.mEGLConfigChooser).setMinAlphaSize(0);
            boolean flag1 = recreateSurface();
            boolean flag = flag1;
_L5:
            if (!flag)
            {
                mHasRetriedCreatingSurface = true;
                ((ComponentSizeChooser)glsurfaceview.mEGLConfigChooser).setMinAlphaSize(i);
                return recreateSurface();
            }
_L2:
            return true;
            Exception exception;
            exception;
            flag = false;
            if (true) goto _L5; else goto _L4
_L4:
        }

        public void destroySurface()
        {
            destroySurfaceImp();
        }

        public void finish()
        {
            if (mEglContext != null)
            {
                GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
                if (glsurfaceview != null)
                {
                    glsurfaceview.mEGLContextFactory.destroyContext(mEgl, mEglDisplay, mEglContext);
                }
                mEglContext = null;
            }
            if (mEglDisplay != null)
            {
                mEgl.eglTerminate(mEglDisplay);
                mEglDisplay = null;
            }
        }

        public void start()
        {
            mEgl = (EGL10)EGLContext.getEGL();
            mEglDisplay = mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            if (mEglDisplay == EGL10.EGL_NO_DISPLAY)
            {
                throw new RuntimeException("eglGetDisplay failed");
            }
            int ai[] = new int[2];
            if (!mEgl.eglInitialize(mEglDisplay, ai))
            {
                throw new RuntimeException("eglInitialize failed");
            }
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview == null)
            {
                mEglConfig = null;
                mEglContext = null;
            } else
            {
                mEglConfig = glsurfaceview.mEGLConfigChooser.chooseConfig(mEgl, mEglDisplay);
                mEglContext = glsurfaceview.mEGLContextFactory.createContext(mEgl, mEglDisplay, mEglConfig);
            }
            if (mEglContext == null || mEglContext == EGL10.EGL_NO_CONTEXT)
            {
                mEglContext = null;
                throwEglException("createContext");
            }
            mEglSurface = null;
        }

        public int swap()
        {
            if (mEgl == null || mEglDisplay == null || mEglSurface == null)
            {
                return 12289;
            }
            if (!mEgl.eglSwapBuffers(mEglDisplay, mEglSurface))
            {
                return mEgl.eglGetError();
            } else
            {
                return 12288;
            }
        }

        public EglHelper(WeakReference weakreference)
        {
            mHasRetriedCreatingSurface = false;
            mGLSurfaceViewWeakRef = weakreference;
        }
    }

    static class GLThread extends Thread
    {

        private EglHelper mEglHelper;
        private ArrayList mEventQueue;
        private boolean mExited;
        private WeakReference mGLSurfaceViewWeakRef;
        private boolean mHasSurface;
        private boolean mHaveEglContext;
        private boolean mHaveEglSurface;
        private int mHeight;
        private boolean mPaused;
        private boolean mRenderComplete;
        private int mRenderMode;
        private boolean mRequestPaused;
        private boolean mRequestRender;
        private boolean mShouldExit;
        private boolean mShouldReleaseEglContext;
        private boolean mSizeChanged;
        private boolean mSurfaceIsBad;
        private boolean mWaitingForSurface;
        private int mWidth;

        private void guardedRun()
            throws InterruptedException
        {
            GL10 gl10;
            boolean flag;
            boolean flag1;
            boolean flag2;
            boolean flag3;
            boolean flag4;
            boolean flag5;
            boolean flag6;
            boolean flag7;
            int i;
            int j;
            Runnable runnable;
            mEglHelper = new EglHelper(mGLSurfaceViewWeakRef);
            mHaveEglContext = false;
            mHaveEglSurface = false;
            gl10 = null;
            flag = false;
            flag1 = false;
            flag2 = false;
            flag3 = false;
            flag4 = false;
            flag5 = false;
            flag6 = false;
            flag7 = false;
            i = 0;
            j = 0;
            runnable = null;
            if (true) goto _L2; else goto _L1
_L1:
            glthreadmanager1;
            JVM INSTR monitorenter ;
_L2:
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                if (!mShouldExit)
                {
                    break MISSING_BLOCK_LABEL_104;
                }
            }
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                stopEglSurfaceLocked();
                stopEglContextLocked();
            }
            return;
            exception5;
            glthreadmanager4;
            JVM INSTR monitorexit ;
            throw exception5;
            if (mEventQueue.isEmpty()) goto _L4; else goto _L3
_L3:
            runnable = (Runnable)mEventQueue.remove(0);
_L9:
            glthreadmanager1;
            JVM INSTR monitorexit ;
            if (runnable == null)
            {
                break MISSING_BLOCK_LABEL_497;
            }
            runnable.run();
            runnable = null;
              goto _L2
_L4:
            if (mPaused != mRequestPaused)
            {
                mRequestPaused;
                mPaused = mRequestPaused;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            if (!mShouldReleaseEglContext)
            {
                break MISSING_BLOCK_LABEL_201;
            }
            stopEglSurfaceLocked();
            stopEglContextLocked();
            mShouldReleaseEglContext = false;
            flag7 = true;
            if (!flag3)
            {
                break MISSING_BLOCK_LABEL_217;
            }
            stopEglSurfaceLocked();
            stopEglContextLocked();
            flag3 = false;
            if (!mHasSurface && !mWaitingForSurface)
            {
                if (mHaveEglSurface)
                {
                    stopEglSurfaceLocked();
                }
                mWaitingForSurface = true;
                mSurfaceIsBad = false;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            if (mHasSurface && mWaitingForSurface)
            {
                mWaitingForSurface = false;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            if (!flag6)
            {
                break MISSING_BLOCK_LABEL_305;
            }
            flag5 = false;
            flag6 = false;
            mRenderComplete = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
            if (!readyToDraw())
            {
                break MISSING_BLOCK_LABEL_488;
            }
            if (mHaveEglContext) goto _L6; else goto _L5
_L5:
            if (!flag7) goto _L8; else goto _L7
_L7:
            flag7 = false;
_L6:
            if (!mHaveEglContext || mHaveEglSurface)
            {
                break MISSING_BLOCK_LABEL_354;
            }
            mHaveEglSurface = true;
            flag1 = true;
            flag2 = true;
            flag4 = true;
            if (!mHaveEglSurface)
            {
                break MISSING_BLOCK_LABEL_488;
            }
            if (!mSizeChanged)
            {
                break MISSING_BLOCK_LABEL_393;
            }
            flag4 = true;
            i = mWidth;
            j = mHeight;
            flag5 = true;
            flag1 = true;
            mSizeChanged = false;
            mRequestRender = false;
            GLSurfaceView.sGLThreadManager.notifyAll();
              goto _L9
            exception2;
            glthreadmanager1;
            JVM INSTR monitorexit ;
            throw exception2;
            Exception exception;
            exception;
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                stopEglSurfaceLocked();
                stopEglContextLocked();
            }
            throw exception;
_L8:
            boolean flag8 = GLSurfaceView.sGLThreadManager.tryAcquireEglContextLocked(this);
            if (!flag8) goto _L6; else goto _L10
_L10:
            mEglHelper.start();
            mHaveEglContext = true;
            flag = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
              goto _L6
            RuntimeException runtimeexception;
            runtimeexception;
            GLSurfaceView.sGLThreadManager.releaseEglContextLocked(this);
            throw runtimeexception;
            GLSurfaceView.sGLThreadManager.wait();
            if (!flag1) goto _L12; else goto _L11
_L11:
            if (mEglHelper.createSurface()) goto _L14; else goto _L13
_L13:
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                mSurfaceIsBad = true;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
              goto _L2
            exception4;
            glthreadmanager3;
            JVM INSTR monitorexit ;
            throw exception4;
_L12:
            if (!flag2)
            {
                break MISSING_BLOCK_LABEL_570;
            }
            gl10 = (GL10)mEglHelper.createGL();
            GLSurfaceView.sGLThreadManager.checkGLDriver(gl10);
            flag2 = false;
            if (!flag) goto _L16; else goto _L15
_L15:
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview == null) goto _L18; else goto _L17
_L17:
            glsurfaceview.mRenderer.onSurfaceCreated(gl10, mEglHelper.mEglConfig);
              goto _L18
_L16:
            if (!flag4) goto _L20; else goto _L19
_L19:
            GLSurfaceView glsurfaceview1 = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview1 == null) goto _L22; else goto _L21
_L21:
            glsurfaceview1.mRenderer.onSurfaceChanged(gl10, i, j);
              goto _L22
_L20:
            GLSurfaceView glsurfaceview2 = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview2 == null || i <= 0 || j <= 0) goto _L2; else goto _L23
_L23:
            glsurfaceview2.mRenderer.onDrawFrame(gl10);
            if (!glsurfaceview2.mNeedsSwap) goto _L2; else goto _L24
_L24:
            int k = mEglHelper.swap();
            k;
            JVM INSTR lookupswitch 2: default 736
        //                       12288: 767
        //                       12302: 785;
               goto _L25 _L26 _L27
_L26:
            break MISSING_BLOCK_LABEL_767;
_L25:
            EglHelper.logEglErrorAsWarning("GLThread", "eglSwapBuffers", k);
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                mSurfaceIsBad = true;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
_L28:
            if (flag5)
            {
                flag6 = true;
            }
            glsurfaceview2.mNeedsSwap = false;
              goto _L2
_L27:
            flag3 = true;
              goto _L28
            exception3;
            glthreadmanager2;
            JVM INSTR monitorexit ;
            throw exception3;
            exception1;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception1;
_L14:
            flag1 = false;
              goto _L12
_L18:
            flag = false;
              goto _L16
_L22:
            flag4 = false;
              goto _L20
        }

        private boolean readyToDraw()
        {
            return !mPaused && mHasSurface && !mSurfaceIsBad && mWidth > 0 && mHeight > 0 && (mRequestRender || mRenderMode == 1);
        }

        private void stopEglContextLocked()
        {
            if (mHaveEglContext)
            {
                mEglHelper.finish();
                mHaveEglContext = false;
                GLSurfaceView.sGLThreadManager.releaseEglContextLocked(this);
            }
        }

        private void stopEglSurfaceLocked()
        {
            if (mHaveEglSurface)
            {
                mHaveEglSurface = false;
                mEglHelper.destroySurface();
            }
        }

        public boolean ableToDraw()
        {
            return mHaveEglContext && mHaveEglSurface && readyToDraw();
        }

        public int getRenderMode()
        {
            int i;
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                i = mRenderMode;
            }
            return i;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public boolean hasGLSurface()
        {
            return mHasSurface;
        }

        public void onPause()
        {
            GLThreadManager glthreadmanager = GLSurfaceView.sGLThreadManager;
            glthreadmanager;
            JVM INSTR monitorenter ;
            mRequestPaused = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
_L1:
            boolean flag;
            if (mExited)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            flag = mPaused;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            GLSurfaceView.sGLThreadManager.wait();
              goto _L1
            InterruptedException interruptedexception;
            interruptedexception;
            Thread.currentThread().interrupt();
              goto _L1
            Exception exception;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
        }

        public void onResume()
        {
            GLThreadManager glthreadmanager = GLSurfaceView.sGLThreadManager;
            glthreadmanager;
            JVM INSTR monitorenter ;
            mRequestPaused = false;
            mRequestRender = true;
            mRenderComplete = false;
            GLSurfaceView.sGLThreadManager.notifyAll();
_L1:
            boolean flag;
            if (mExited || !mPaused)
            {
                break MISSING_BLOCK_LABEL_75;
            }
            flag = mRenderComplete;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_75;
            }
            GLSurfaceView.sGLThreadManager.wait();
              goto _L1
            InterruptedException interruptedexception;
            interruptedexception;
            Thread.currentThread().interrupt();
              goto _L1
            Exception exception;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
        }

        public void onWindowResize(int i, int j)
        {
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                if (mHasSurface)
                {
                    mWidth = i;
                    mHeight = j;
                    mSizeChanged = true;
                    mRequestRender = true;
                    mRenderComplete = false;
                    GLSurfaceView.sGLThreadManager.notifyAll();
                }
            }
            return;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void queueEvent(Runnable runnable)
        {
            if (runnable == null)
            {
                throw new IllegalArgumentException("r must not be null");
            }
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                mEventQueue.add(runnable);
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            return;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void requestExitAndWait()
        {
            GLThreadManager glthreadmanager = GLSurfaceView.sGLThreadManager;
            glthreadmanager;
            JVM INSTR monitorenter ;
            mShouldExit = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
_L1:
            boolean flag = mExited;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_51;
            }
            GLSurfaceView.sGLThreadManager.wait();
              goto _L1
            InterruptedException interruptedexception;
            interruptedexception;
            Thread.currentThread().interrupt();
              goto _L1
            Exception exception;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
        }

        public void requestReleaseEglContextLocked()
        {
            mShouldReleaseEglContext = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
        }

        public void requestRender()
        {
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                mRequestRender = true;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            return;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void run()
        {
            Exception exception;
            setName((new StringBuilder()).append("GLThread ").append(getId()).toString());
            try
            {
                guardedRun();
            }
            catch (InterruptedException interruptedexception)
            {
                GLSurfaceView.sGLThreadManager.threadExiting(this);
                return;
            }
            finally
            {
                GLSurfaceView.sGLThreadManager.threadExiting(this);
            }
            GLSurfaceView.sGLThreadManager.threadExiting(this);
            return;
            throw exception;
        }

        public void setRenderMode(int i)
        {
            if (i < 0 || i > 1)
            {
                throw new IllegalArgumentException("renderMode");
            }
            synchronized (GLSurfaceView.sGLThreadManager)
            {
                mRenderMode = i;
                GLSurfaceView.sGLThreadManager.notifyAll();
            }
            return;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void surfaceCreated()
        {
            GLThreadManager glthreadmanager = GLSurfaceView.sGLThreadManager;
            glthreadmanager;
            JVM INSTR monitorenter ;
            mHasSurface = true;
            GLSurfaceView.sGLThreadManager.notifyAll();
_L1:
            boolean flag;
            if (!mWaitingForSurface)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            flag = mExited;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            GLSurfaceView.sGLThreadManager.wait();
              goto _L1
            InterruptedException interruptedexception;
            interruptedexception;
            Thread.currentThread().interrupt();
              goto _L1
            Exception exception;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
        }

        public void surfaceDestroyed()
        {
            GLThreadManager glthreadmanager = GLSurfaceView.sGLThreadManager;
            glthreadmanager;
            JVM INSTR monitorenter ;
            mHasSurface = false;
            GLSurfaceView.sGLThreadManager.notifyAll();
_L1:
            boolean flag;
            if (mWaitingForSurface)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            flag = mExited;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            GLSurfaceView.sGLThreadManager.wait();
              goto _L1
            InterruptedException interruptedexception;
            interruptedexception;
            Thread.currentThread().interrupt();
              goto _L1
            Exception exception;
            exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
            throw exception;
            glthreadmanager;
            JVM INSTR monitorexit ;
        }


/*
        static boolean access$1102(GLThread glthread, boolean flag)
        {
            glthread.mExited = flag;
            return flag;
        }

*/

        GLThread(WeakReference weakreference)
        {
            mEventQueue = new ArrayList();
            mSizeChanged = true;
            mWidth = 0;
            mHeight = 0;
            mRequestRender = true;
            mRenderMode = 1;
            mGLSurfaceViewWeakRef = weakreference;
        }
    }

    private static class GLThreadManager
    {

        private static String TAG = "GLThreadManager";
        private static final int kGLES_20 = 0x20000;
        private static final String kMSM7K_RENDERER_PREFIX = "Q3Dimension MSM7500 ";
        private GLThread mEglOwner;
        private boolean mGLESDriverCheckComplete;
        private int mGLESVersion;
        private boolean mGLESVersionCheckComplete;
        private boolean mLimitedGLESContexts;
        private boolean mMultipleGLESContextsAllowed;

        private void checkGLESVersion()
        {
            if (!mGLESVersionCheckComplete)
            {
                mGLESVersion = 0;
                try
                {
                    Class class1 = Class.forName("android.os.SystemProperties");
                    Class aclass[] = new Class[2];
                    aclass[0] = java/lang/String;
                    aclass[1] = Integer.TYPE;
                    Method method = class1.getMethod("getInt", aclass);
                    Object aobj[] = new Object[2];
                    aobj[0] = "ro.opengles.version";
                    aobj[1] = Integer.valueOf(0);
                    mGLESVersion = ((Integer)method.invoke(null, aobj)).intValue();
                }
                catch (Exception exception) { }
                if (mGLESVersion >= 0x20000)
                {
                    mMultipleGLESContextsAllowed = true;
                }
                mGLESVersionCheckComplete = true;
            }
        }

        public void checkGLDriver(GL10 gl10)
        {
            boolean flag = true;
            this;
            JVM INSTR monitorenter ;
            String s;
            if (mGLESDriverCheckComplete)
            {
                break MISSING_BLOCK_LABEL_75;
            }
            checkGLESVersion();
            s = gl10.glGetString(7937);
            if (mGLESVersion >= 0x20000)
            {
                break MISSING_BLOCK_LABEL_58;
            }
            boolean flag1;
            if (!s.startsWith("Q3Dimension MSM7500 "))
            {
                flag1 = flag;
            } else
            {
                flag1 = false;
            }
            mMultipleGLESContextsAllowed = flag1;
            notifyAll();
            if (mMultipleGLESContextsAllowed)
            {
                flag = false;
            }
            mLimitedGLESContexts = flag;
            mGLESDriverCheckComplete = true;
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public void releaseEglContextLocked(GLThread glthread)
        {
            if (mEglOwner == glthread)
            {
                mEglOwner = null;
            }
            notifyAll();
        }

        public boolean shouldReleaseEGLContextWhenPausing()
        {
            this;
            JVM INSTR monitorenter ;
            boolean flag = mLimitedGLESContexts;
            this;
            JVM INSTR monitorexit ;
            return flag;
            Exception exception;
            exception;
            throw exception;
        }

        public boolean shouldTerminateEGLWhenPausing()
        {
            this;
            JVM INSTR monitorenter ;
            boolean flag;
            checkGLESVersion();
            flag = mMultipleGLESContextsAllowed;
            boolean flag1;
            if (!flag)
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            this;
            JVM INSTR monitorexit ;
            return flag1;
            Exception exception;
            exception;
            throw exception;
        }

        public void threadExiting(GLThread glthread)
        {
            this;
            JVM INSTR monitorenter ;
            glthread.mExited = true;
            if (mEglOwner == glthread)
            {
                mEglOwner = null;
            }
            notifyAll();
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public boolean tryAcquireEglContextLocked(GLThread glthread)
        {
            if (mEglOwner == glthread || mEglOwner == null)
            {
                mEglOwner = glthread;
                notifyAll();
            } else
            {
                checkGLESVersion();
                if (!mMultipleGLESContextsAllowed)
                {
                    if (mEglOwner != null)
                    {
                        mEglOwner.requestReleaseEglContextLocked();
                    }
                    return false;
                }
            }
            return true;
        }


        private GLThreadManager()
        {
        }

    }

    public static interface GLWrapper
    {

        public abstract GL wrap(GL gl);
    }

    static class LogWriter extends Writer
    {

        private StringBuilder mBuilder;

        private void flushBuilder()
        {
            if (mBuilder.length() > 0)
            {
                Log.v("GLSurfaceView", mBuilder.toString());
                mBuilder.delete(0, mBuilder.length());
            }
        }

        public void close()
        {
            flushBuilder();
        }

        public void flush()
        {
            flushBuilder();
        }

        public void write(char ac[], int i, int j)
        {
            int k = 0;
            while (k < j) 
            {
                char c = ac[i + k];
                if (c == '\n')
                {
                    flushBuilder();
                } else
                {
                    mBuilder.append(c);
                }
                k++;
            }
        }

        LogWriter()
        {
            mBuilder = new StringBuilder();
        }
    }

    public static interface Renderer
    {

        public abstract void onDrawFrame(GL10 gl10);

        public abstract void onSurfaceChanged(GL10 gl10, int i, int j);

        public abstract void onSurfaceCreated(GL10 gl10, EGLConfig eglconfig);
    }

    private class SimpleEGLConfigChooser extends ComponentSizeChooser
    {

        final GLSurfaceView this$0;

        public SimpleEGLConfigChooser(boolean flag)
        {
            this$0 = GLSurfaceView.this;
            byte byte0;
            if (flag)
            {
                byte0 = 16;
            } else
            {
                byte0 = 0;
            }
            super(4, 4, 4, 0, byte0, 0);
            mRedSize = 5;
            mGreenSize = 6;
            mBlueSize = 5;
        }
    }


    public static final int DEBUG_CHECK_GL_ERROR = 1;
    public static final int DEBUG_LOG_GL_CALLS = 2;
    private static final boolean LOG_ATTACH_DETACH = false;
    private static final boolean LOG_EGL = false;
    private static final boolean LOG_PAUSE_RESUME = false;
    private static final boolean LOG_RENDERER = false;
    private static final boolean LOG_RENDERER_DRAW_FRAME = false;
    private static final boolean LOG_SURFACE = false;
    private static final boolean LOG_THREADS = false;
    public static final int RENDERMODE_CONTINUOUSLY = 1;
    public static final int RENDERMODE_WHEN_DIRTY = 0;
    private static final String TAG = "GLSurfaceView";
    private static final GLThreadManager sGLThreadManager = new GLThreadManager();
    private int mDebugFlags;
    private boolean mDetached;
    private EGLConfigChooser mEGLConfigChooser;
    private int mEGLContextClientVersion;
    private EGLContextFactory mEGLContextFactory;
    private EGLWindowSurfaceFactory mEGLWindowSurfaceFactory;
    private GLThread mGLThread;
    private GLWrapper mGLWrapper;
    private boolean mNeedsSwap;
    private boolean mPreserveEGLContextOnPause;
    private Renderer mRenderer;
    private final WeakReference mThisWeakRef;

    public GLSurfaceView(Context context)
    {
        super(context);
        mThisWeakRef = new WeakReference(this);
        mNeedsSwap = true;
        init();
    }

    public GLSurfaceView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mThisWeakRef = new WeakReference(this);
        mNeedsSwap = true;
        init();
    }

    private void checkRenderThreadState()
    {
        if (mGLThread != null)
        {
            throw new IllegalStateException("setRenderer has already been called for this instance.");
        } else
        {
            return;
        }
    }

    private void init()
    {
        getHolder().addCallback(this);
    }

    public boolean canRender()
    {
        return mGLThread != null;
    }

    public void clearNeedsSwap()
    {
        mNeedsSwap = false;
    }

    protected void finalize()
        throws Throwable
    {
        if (mGLThread != null)
        {
            mGLThread.requestExitAndWait();
        }
        super.finalize();
        return;
        Exception exception;
        exception;
        super.finalize();
        throw exception;
    }

    public int getDebugFlags()
    {
        return mDebugFlags;
    }

    public boolean getPreserveEGLContextOnPause()
    {
        return mPreserveEGLContextOnPause;
    }

    public int getRenderMode()
    {
        return mGLThread.getRenderMode();
    }

    protected boolean hasGLSurface()
    {
        GLThread glthread = mGLThread;
        if (glthread == null)
        {
            return false;
        } else
        {
            return glthread.hasGLSurface();
        }
    }

    protected void onAttachedToWindow()
    {
        super.onAttachedToWindow();
        if (mDetached && mRenderer != null)
        {
            int i = 1;
            if (mGLThread != null)
            {
                i = mGLThread.getRenderMode();
            }
            mGLThread = new GLThread(mThisWeakRef);
            if (i != 1)
            {
                mGLThread.setRenderMode(i);
            }
            mGLThread.start();
        }
        mDetached = false;
    }

    protected void onDetachedFromWindow()
    {
        if (mGLThread != null)
        {
            mGLThread.requestExitAndWait();
        }
        mDetached = true;
        super.onDetachedFromWindow();
    }

    public void onPause()
    {
        mGLThread.onPause();
    }

    public void onResume()
    {
        mGLThread.onResume();
    }

    public void queueEvent(Runnable runnable)
    {
        mGLThread.queueEvent(runnable);
    }

    public void requestRender()
    {
        mGLThread.requestRender();
    }

    public void setDebugFlags(int i)
    {
        mDebugFlags = i;
    }

    public void setEGLConfigChooser(int i, int j, int k, int l, int i1, int j1)
    {
        setEGLConfigChooser(((EGLConfigChooser) (new ComponentSizeChooser(i, j, k, l, i1, j1))));
    }

    public void setEGLConfigChooser(EGLConfigChooser eglconfigchooser)
    {
        checkRenderThreadState();
        mEGLConfigChooser = eglconfigchooser;
    }

    public void setEGLConfigChooser(boolean flag)
    {
        setEGLConfigChooser(((EGLConfigChooser) (new SimpleEGLConfigChooser(flag))));
    }

    public void setEGLContextClientVersion(int i)
    {
        checkRenderThreadState();
        mEGLContextClientVersion = i;
    }

    public void setEGLContextFactory(EGLContextFactory eglcontextfactory)
    {
        checkRenderThreadState();
        mEGLContextFactory = eglcontextfactory;
    }

    public void setEGLWindowSurfaceFactory(EGLWindowSurfaceFactory eglwindowsurfacefactory)
    {
        checkRenderThreadState();
        mEGLWindowSurfaceFactory = eglwindowsurfacefactory;
    }

    public void setGLWrapper(GLWrapper glwrapper)
    {
        mGLWrapper = glwrapper;
    }

    public void setNeedsSwap()
    {
        mNeedsSwap = true;
    }

    public void setPreserveEGLContextOnPause(boolean flag)
    {
        mPreserveEGLContextOnPause = flag;
    }

    public void setRenderMode(int i)
    {
        mGLThread.setRenderMode(i);
    }

    public void setRenderer(Renderer renderer)
    {
        checkRenderThreadState();
        if (mEGLConfigChooser == null)
        {
            mEGLConfigChooser = new SimpleEGLConfigChooser(true);
        }
        if (mEGLContextFactory == null)
        {
            mEGLContextFactory = new DefaultContextFactory();
        }
        if (mEGLWindowSurfaceFactory == null)
        {
            mEGLWindowSurfaceFactory = new DefaultWindowSurfaceFactory();
        }
        mRenderer = renderer;
        mGLThread = new GLThread(mThisWeakRef);
        mGLThread.start();
    }

    public void surfaceChanged(SurfaceHolder surfaceholder, int i, int j, int k)
    {
        if (surfaceholder == null || surfaceholder.getSurface() == null || !surfaceholder.getSurface().isValid())
        {
            return;
        } else
        {
            mGLThread.surfaceCreated();
            mGLThread.onWindowResize(j, k);
            return;
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceholder)
    {
    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        mGLThread.surfaceDestroyed();
    }




/*
    static boolean access$1002(GLSurfaceView glsurfaceview, boolean flag)
    {
        glsurfaceview.mNeedsSwap = flag;
        return flag;
    }

*/








}
