// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.util.Log;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            GLSurfaceView

private static class <init>
    implements <init>
{

    public EGLSurface createWindowSurface(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig, Object obj)
    {
        EGLSurface eglsurface;
        try
        {
            eglsurface = egl10.eglCreateWindowSurface(egldisplay, eglconfig, obj, null);
        }
        catch (IllegalArgumentException illegalargumentexception)
        {
            Log.e("GLSurfaceView", "eglCreateWindowSurface", illegalargumentexception);
            return null;
        }
        return eglsurface;
    }

    public void destroySurface(EGL10 egl10, EGLDisplay egldisplay, EGLSurface eglsurface)
    {
        egl10.eglDestroySurface(egldisplay, eglsurface);
    }

    private ()
    {
    }

    ( )
    {
        this();
    }
}
