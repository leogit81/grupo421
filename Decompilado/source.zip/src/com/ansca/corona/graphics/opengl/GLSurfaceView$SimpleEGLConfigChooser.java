// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;


// Referenced classes of package com.ansca.corona.graphics.opengl:
//            GLSurfaceView

private class mBlueSize extends mBlueSize
{

    final GLSurfaceView this$0;

    public (boolean flag)
    {
        this$0 = GLSurfaceView.this;
        byte byte0;
        if (flag)
        {
            byte0 = 16;
        } else
        {
            byte0 = 0;
        }
        super(GLSurfaceView.this, 4, 4, 4, 0, byte0, 0);
        mRedSize = 5;
        mGreenSize = 6;
        mBlueSize = 5;
    }
}
