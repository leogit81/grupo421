// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.SurfaceHolder;
import com.ansca.corona.Controller;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.JavaToNativeShim;
import com.ansca.corona.MessageBasedTimer;
import com.ansca.corona.TimeSpan;
import com.ansca.corona.WindowOrientation;
import com.ansca.corona.events.EventManager;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            GLSurfaceView

public class CoronaGLSurfaceView extends GLSurfaceView
{
    private static class CoronaRenderer
        implements GLSurfaceView.Renderer
    {

        private static boolean sFirstSurface = true;
        private boolean fCanRender;
        private WindowOrientation fLastReceivedWindowOrientation;
        private int fLastViewHeight;
        private int fLastViewWidth;
        private CoronaGLSurfaceView fView;

        public boolean canRender()
        {
            return fCanRender;
        }

        public void clearFirstSurface()
        {
            sFirstSurface = true;
        }

        public void onDrawFrame(GL10 gl10)
        {
            Controller.updateRuntimeState(fCanRender);
        }

        public void onSurfaceChanged(GL10 gl10, int i, int j)
        {
            WindowOrientation windoworientation;
            WindowOrientation windoworientation1;
            windoworientation = fView.fCurrentWindowOrientation;
            windoworientation1 = fView.fPreviousWindowOrientation;
            if (windoworientation.isPortrait() && i > j || windoworientation.isLandscape() && i < j)
            {
                fCanRender = false;
                return;
            }
            JavaToNativeShim.resize(fView.getContext(), i, j, windoworientation);
            fCanRender = true;
            if (fLastReceivedWindowOrientation != WindowOrientation.UNKNOWN) goto _L2; else goto _L1
_L1:
            fLastReceivedWindowOrientation = windoworientation;
_L4:
            if (fLastViewWidth >= 0 && fLastViewHeight >= 0 && (fLastViewWidth != i || fLastViewHeight != j))
            {
                EventManager eventmanager1 = Controller.getEventManager();
                if (eventmanager1 != null)
                {
                    eventmanager1.resize();
                }
            }
            fLastViewWidth = i;
            fLastViewHeight = j;
            return;
_L2:
            if (fLastReceivedWindowOrientation != windoworientation)
            {
                fLastReceivedWindowOrientation = windoworientation;
                EventManager eventmanager = Controller.getEventManager();
                if (eventmanager != null)
                {
                    eventmanager.orientationChanged(windoworientation.toCoronaIntegerId(), windoworientation1.toCoronaIntegerId());
                }
            }
            if (true) goto _L4; else goto _L3
_L3:
        }

        public void onSurfaceCreated(GL10 gl10, EGLConfig eglconfig)
        {
            if (!sFirstSurface)
            {
                fView.setNeedsSwap();
            }
            sFirstSurface = false;
            JavaToNativeShim.unloadResources();
        }


        public CoronaRenderer(CoronaGLSurfaceView coronaglsurfaceview)
        {
            if (coronaglsurfaceview == null)
            {
                throw new NullPointerException();
            } else
            {
                fView = coronaglsurfaceview;
                fCanRender = false;
                fLastReceivedWindowOrientation = WindowOrientation.UNKNOWN;
                fLastViewWidth = -1;
                fLastViewHeight = -1;
                return;
            }
        }
    }


    private CoronaActivity fActivity;
    private WindowOrientation fCurrentDeviceOrientation;
    private WindowOrientation fCurrentWindowOrientation;
    private OrientationEventListener fOrientationListener;
    private WindowOrientation fPreviousDeviceOrientation;
    private WindowOrientation fPreviousWindowOrientation;
    private CoronaRenderer fRenderer;
    private MessageBasedTimer fWatchdogTimer;

    public CoronaGLSurfaceView(CoronaActivity coronaactivity)
    {
        super(coronaactivity);
        if (coronaactivity == null)
        {
            throw new NullPointerException();
        } else
        {
            fActivity = coronaactivity;
            fCurrentWindowOrientation = WindowOrientation.fromCurrentWindowUsing(coronaactivity);
            fPreviousWindowOrientation = fCurrentWindowOrientation;
            fWatchdogTimer = new MessageBasedTimer();
            fWatchdogTimer.setHandler(new Handler());
            fWatchdogTimer.setInterval(TimeSpan.fromSeconds(1L));
            fWatchdogTimer.setListener(new com.ansca.corona.MessageBasedTimer.Listener() {

                final CoronaGLSurfaceView this$0;

                public void onTimerElapsed()
                {
                    SurfaceHolder surfaceholder;
                    for (surfaceholder = getHolder(); surfaceholder == null || surfaceholder.getSurface() == null || hasGLSurface() && canRender();)
                    {
                        return;
                    }

                    surfaceChanged(surfaceholder, 1, getWidth(), getHeight());
                }

            
            {
                this$0 = CoronaGLSurfaceView.this;
                super();
            }
            });
            fCurrentDeviceOrientation = fCurrentWindowOrientation;
            fPreviousDeviceOrientation = WindowOrientation.UNKNOWN;
            fOrientationListener = new OrientationEventListener(getContext()) {

                final CoronaGLSurfaceView this$0;

                public void onOrientationChanged(int i)
                {
                    if (i != -1 && Controller.isValid() && canRender())
                    {
                        int j = (360 - i) % 360;
                        WindowOrientation windoworientation = WindowOrientation.fromDegrees(getContext(), j);
                        if (windoworientation != fCurrentDeviceOrientation || fPreviousDeviceOrientation == WindowOrientation.UNKNOWN)
                        {
                            fPreviousDeviceOrientation = fCurrentDeviceOrientation;
                            fCurrentDeviceOrientation = windoworientation;
                            if (fActivity.hasFixedOrientation())
                            {
                                EventManager eventmanager = Controller.getEventManager();
                                if (eventmanager != null)
                                {
                                    eventmanager.orientationChanged(fCurrentDeviceOrientation.toCoronaIntegerId(), fPreviousDeviceOrientation.toCoronaIntegerId());
                                    return;
                                }
                            }
                        }
                    }
                }

            
            {
                this$0 = CoronaGLSurfaceView.this;
                super(context);
            }
            };
            setEGLContextClientVersion(2);
            setEGLConfigChooser(8, 8, 8, 8, 0, 0);
            fRenderer = new CoronaRenderer(this);
            setRenderer(fRenderer);
            setRenderMode(0);
            getHolder().setFormat(1);
            setDebugFlags(3);
            return;
        }
    }

    public boolean canRender()
    {
        return fRenderer != null && fRenderer.canRender() && super.canRender();
    }

    public void clearFirstSurface()
    {
        fRenderer.clearFirstSurface();
    }

    public CoronaActivity getActivity()
    {
        return fActivity;
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
        if (!fOrientationListener.canDetectOrientation())
        {
            WindowOrientation windoworientation;
            if (configuration.orientation == 2)
            {
                windoworientation = WindowOrientation.LANDSCAPE_RIGHT;
            } else
            {
                windoworientation = WindowOrientation.PORTRAIT_UPRIGHT;
            }
            if (windoworientation != fCurrentDeviceOrientation || fPreviousDeviceOrientation == WindowOrientation.UNKNOWN)
            {
                fPreviousDeviceOrientation = fCurrentDeviceOrientation;
                fCurrentDeviceOrientation = windoworientation;
                if (fActivity.hasFixedOrientation())
                {
                    EventManager eventmanager = Controller.getEventManager();
                    if (eventmanager != null)
                    {
                        eventmanager.orientationChanged(fCurrentDeviceOrientation.toCoronaIntegerId(), fPreviousDeviceOrientation.toCoronaIntegerId());
                    }
                }
            }
        }
    }

    public void onResumeCoronaRuntime()
    {
        fWatchdogTimer.start();
        if (fOrientationListener.canDetectOrientation())
        {
            fOrientationListener.enable();
        }
    }

    public void onSuspendCoronaRuntime()
    {
        fWatchdogTimer.stop();
        if (fOrientationListener.canDetectOrientation())
        {
            fOrientationListener.disable();
        }
    }

    public void surfaceChanged(SurfaceHolder surfaceholder, int i, int j, int k)
    {
        if (surfaceholder == null || surfaceholder.getSurface() == null || !surfaceholder.getSurface().isValid())
        {
            return;
        }
        WindowOrientation windoworientation = WindowOrientation.fromCurrentWindowUsing(fActivity);
        if (windoworientation.isSupportedBy(fActivity) && fCurrentWindowOrientation != windoworientation)
        {
            fPreviousWindowOrientation = fCurrentWindowOrientation;
            fCurrentWindowOrientation = windoworientation;
        }
        super.surfaceChanged(surfaceholder, i, j, k);
    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        fWatchdogTimer.stop();
        super.surfaceDestroyed(surfaceholder);
    }



/*
    static WindowOrientation access$002(CoronaGLSurfaceView coronaglsurfaceview, WindowOrientation windoworientation)
    {
        coronaglsurfaceview.fCurrentDeviceOrientation = windoworientation;
        return windoworientation;
    }

*/



/*
    static WindowOrientation access$102(CoronaGLSurfaceView coronaglsurfaceview, WindowOrientation windoworientation)
    {
        coronaglsurfaceview.fPreviousDeviceOrientation = windoworientation;
        return windoworientation;
    }

*/



}
