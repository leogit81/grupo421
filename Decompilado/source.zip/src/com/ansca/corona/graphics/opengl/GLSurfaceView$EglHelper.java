// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.opengl.GLDebugHelper;
import android.opengl.GLES10;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import java.lang.ref.WeakReference;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            GLSurfaceView

private static class mGLSurfaceViewWeakRef
{

    EGL10 mEgl;
    EGLConfig mEglConfig;
    EGLContext mEglContext;
    EGLDisplay mEglDisplay;
    EGLSurface mEglSurface;
    private WeakReference mGLSurfaceViewWeakRef;
    private boolean mHasRetriedCreatingSurface;

    private void destroySurfaceImp()
    {
        if (mEglSurface != null && mEglSurface != EGL10.EGL_NO_SURFACE)
        {
            mEgl.eglMakeCurrent(mEglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview != null)
            {
                GLSurfaceView.access$500(glsurfaceview).destroySurface(mEgl, mEglDisplay, mEglSurface);
            }
            mEglSurface = null;
        }
    }

    public static String formatEglError(String s, int i)
    {
        return (new StringBuilder()).append(s).append(" failed: ").append(getErrorString(i)).toString();
    }

    public static String getErrorString(int i)
    {
        switch (i)
        {
        default:
            return Integer.toHexString(i);

        case 12288: 
            return "EGL_SUCCESS";

        case 12289: 
            return "EGL_NOT_INITIALIZED";

        case 12290: 
            return "EGL_BAD_ACCESS";

        case 12291: 
            return "EGL_BAD_ALLOC";

        case 12292: 
            return "EGL_BAD_ATTRIBUTE";

        case 12293: 
            return "EGL_BAD_CONFIG";

        case 12294: 
            return "EGL_BAD_CONTEXT";

        case 12295: 
            return "EGL_BAD_CURRENT_SURFACE";

        case 12296: 
            return "EGL_BAD_DISPLAY";

        case 12297: 
            return "EGL_BAD_MATCH";

        case 12298: 
            return "EGL_BAD_NATIVE_PIXMAP";

        case 12299: 
            return "EGL_BAD_NATIVE_WINDOW";

        case 12300: 
            return "EGL_BAD_PARAMETER";

        case 12301: 
            return "EGL_BAD_SURFACE";

        case 12302: 
            return "EGL_CONTEXT_LOST";
        }
    }

    public static void logEglErrorAsWarning(String s, String s1, int i)
    {
        Log.w(s, formatEglError(s1, i));
    }

    private boolean recreateSurface()
    {
        destroySurfaceImp();
        GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
        if (glsurfaceview != null && mEglContext != null)
        {
            SurfaceHolder surfaceholder = glsurfaceview.getHolder();
            if (surfaceholder != null && surfaceholder.getSurface() != null && surfaceholder.getSurface().isValid())
            {
                GLSurfaceView.access$400(glsurfaceview).destroyContext(mEgl, mEglDisplay, mEglContext);
            }
            mEglContext = null;
        }
        start();
        return createSurface();
    }

    private void throwEglException(String s)
    {
        throwEglException(s, mEgl.eglGetError());
    }

    public static void throwEglException(String s, int i)
    {
        throw new RuntimeException(formatEglError(s, i));
    }

    GL createGL()
    {
        GL gl = mEglContext.getGL();
        GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
        if (glsurfaceview != null)
        {
            if (GLSurfaceView.access$600(glsurfaceview) != null)
            {
                gl = GLSurfaceView.access$600(glsurfaceview).wrap(gl);
            }
            if ((3 & GLSurfaceView.access$700(glsurfaceview)) != 0)
            {
                int i = 1 & GLSurfaceView.access$700(glsurfaceview);
                int j = 0;
                if (i != 0)
                {
                    j = false | true;
                }
                int k = 2 & GLSurfaceView.access$700(glsurfaceview);
                formatEglError formateglerror = null;
                if (k != 0)
                {
                    formateglerror = new <init>();
                }
                gl = GLDebugHelper.wrap(gl, j, formateglerror);
            }
        }
        return gl;
    }

    public boolean createSurface()
    {
        GLSurfaceView glsurfaceview;
        if (mEgl == null)
        {
            throw new RuntimeException("egl not initialized");
        }
        if (mEglDisplay == null)
        {
            throw new RuntimeException("eglDisplay not initialized");
        }
        if (mEglConfig == null)
        {
            throw new RuntimeException("mEglConfig not initialized");
        }
        destroySurfaceImp();
        mEglSurface = null;
        glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
        if (glsurfaceview != null)
        {
            SurfaceHolder surfaceholder = glsurfaceview.getHolder();
            if (surfaceholder != null && surfaceholder.getSurface() != null && surfaceholder.getSurface().isValid())
            {
                mEglSurface = GLSurfaceView.access$500(glsurfaceview).createWindowSurface(mEgl, mEglDisplay, mEglConfig, surfaceholder);
            }
        }
        if (mEglSurface == null || mEglSurface == EGL10.EGL_NO_SURFACE)
        {
            if (mEgl.eglGetError() == 12299)
            {
                Log.e("EglHelper", "createWindowSurface returned EGL_BAD_NATIVE_WINDOW.");
            }
            return false;
        }
        if (!mEgl.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext))
        {
            logEglErrorAsWarning("EGLHelper", "eglMakeCurrent", mEgl.eglGetError());
            return false;
        }
        if (mHasRetriedCreatingSurface) goto _L2; else goto _L1
_L1:
        String s = GLES10.glGetString(7937);
        if (s == null || !s.equals("PowerVR SGX 540") || !(GLSurfaceView.access$300(glsurfaceview) instanceof izeChooser) || ((izeChooser)GLSurfaceView.access$300(glsurfaceview)).getMinAlphaSize() <= 0) goto _L2; else goto _L3
_L3:
        int i;
        i = ((izeChooser)GLSurfaceView.access$300(glsurfaceview)).getMinAlphaSize();
        ((izeChooser)GLSurfaceView.access$300(glsurfaceview)).setMinAlphaSize(0);
        boolean flag1 = recreateSurface();
        boolean flag = flag1;
_L5:
        if (!flag)
        {
            mHasRetriedCreatingSurface = true;
            ((izeChooser)GLSurfaceView.access$300(glsurfaceview)).setMinAlphaSize(i);
            return recreateSurface();
        }
_L2:
        return true;
        Exception exception;
        exception;
        flag = false;
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void destroySurface()
    {
        destroySurfaceImp();
    }

    public void finish()
    {
        if (mEglContext != null)
        {
            GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
            if (glsurfaceview != null)
            {
                GLSurfaceView.access$400(glsurfaceview).destroyContext(mEgl, mEglDisplay, mEglContext);
            }
            mEglContext = null;
        }
        if (mEglDisplay != null)
        {
            mEgl.eglTerminate(mEglDisplay);
            mEglDisplay = null;
        }
    }

    public void start()
    {
        mEgl = (EGL10)EGLContext.getEGL();
        mEglDisplay = mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
        if (mEglDisplay == EGL10.EGL_NO_DISPLAY)
        {
            throw new RuntimeException("eglGetDisplay failed");
        }
        int ai[] = new int[2];
        if (!mEgl.eglInitialize(mEglDisplay, ai))
        {
            throw new RuntimeException("eglInitialize failed");
        }
        GLSurfaceView glsurfaceview = (GLSurfaceView)mGLSurfaceViewWeakRef.get();
        if (glsurfaceview == null)
        {
            mEglConfig = null;
            mEglContext = null;
        } else
        {
            mEglConfig = GLSurfaceView.access$300(glsurfaceview).chooseConfig(mEgl, mEglDisplay);
            mEglContext = GLSurfaceView.access$400(glsurfaceview).createContext(mEgl, mEglDisplay, mEglConfig);
        }
        if (mEglContext == null || mEglContext == EGL10.EGL_NO_CONTEXT)
        {
            mEglContext = null;
            throwEglException("createContext");
        }
        mEglSurface = null;
    }

    public int swap()
    {
        if (mEgl == null || mEglDisplay == null || mEglSurface == null)
        {
            return 12289;
        }
        if (!mEgl.eglSwapBuffers(mEglDisplay, mEglSurface))
        {
            return mEgl.eglGetError();
        } else
        {
            return 12288;
        }
    }

    public hooser(WeakReference weakreference)
    {
        mHasRetriedCreatingSurface = false;
        mGLSurfaceViewWeakRef = weakreference;
    }
}
