// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            GLSurfaceView

private class mStencilSize extends mStencilSize
{

    protected int mAlphaSize;
    protected int mBlueSize;
    protected int mDepthSize;
    protected int mGreenSize;
    protected int mRedSize;
    protected int mStencilSize;
    private int mValue[];
    final GLSurfaceView this$0;

    private int findConfigAttrib(EGL10 egl10, EGLDisplay egldisplay, EGLConfig eglconfig, int i, int j)
    {
        if (egl10.eglGetConfigAttrib(egldisplay, eglconfig, i, mValue))
        {
            j = mValue[0];
        }
        return j;
    }

    public EGLConfig chooseConfig(EGL10 egl10, EGLDisplay egldisplay, EGLConfig aeglconfig[])
    {
        EGLConfig eglconfig = null;
        int i = 1000;
        int j = aeglconfig.length;
        int k = 0;
        do
        {
            if (k >= j)
            {
                break;
            }
            EGLConfig eglconfig1 = aeglconfig[k];
            if (findConfigAttrib(egl10, egldisplay, eglconfig1, 12325, 0) >= mDepthSize && findConfigAttrib(egl10, egldisplay, eglconfig1, 12326, 0) >= mStencilSize)
            {
                int l = findConfigAttrib(egl10, egldisplay, eglconfig1, 12324, 0);
                int i1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12323, 0);
                int j1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12322, 0);
                int k1 = findConfigAttrib(egl10, egldisplay, eglconfig1, 12321, 0);
                int l1 = Math.abs(l - mRedSize) + Math.abs(i1 - mGreenSize) + Math.abs(j1 - mBlueSize) + Math.abs(k1 - mAlphaSize);
                if (l1 < i)
                {
                    i = l1;
                    eglconfig = eglconfig1;
                }
            }
            k++;
        } while (true);
        return eglconfig;
    }

    public int getMinAlphaSize()
    {
        return mAlphaSize;
    }

    public void setMinAlphaSize(int i)
    {
        mAlphaSize = i;
    }

    public I(int i, int j, int k, int l, int i1, int j1)
    {
        this$0 = GLSurfaceView.this;
        super(GLSurfaceView.this, new int[] {
            12324, i, 12323, j, 12322, k, 12321, 0, 12325, i1, 
            12326, j1, 12327, 12344, 12344
        });
        mValue = new int[1];
        mRedSize = i;
        mGreenSize = j;
        mBlueSize = k;
        mAlphaSize = l;
        mDepthSize = i1;
        mStencilSize = j1;
    }
}
