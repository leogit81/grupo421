// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics.opengl;

import android.view.SurfaceHolder;

// Referenced classes of package com.ansca.corona.graphics.opengl:
//            CoronaGLSurfaceView

class this._cls0
    implements com.ansca.corona.ener
{

    final CoronaGLSurfaceView this$0;

    public void onTimerElapsed()
    {
        SurfaceHolder surfaceholder;
        for (surfaceholder = getHolder(); surfaceholder == null || surfaceholder.getSurface() == null || hasGLSurface() && canRender();)
        {
            return;
        }

        surfaceChanged(surfaceholder, 1, getWidth(), getHeight());
    }

    ()
    {
        this$0 = CoronaGLSurfaceView.this;
        super();
    }
}
