// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;

import android.content.Context;
import android.graphics.Typeface;
import com.ansca.corona.ApplicationContextProvider;
import com.ansca.corona.storage.FileServices;
import java.io.File;
import java.io.FilenameFilter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ansca.corona.graphics:
//            TypefaceInfo, TypefaceSettings

public class FontServices extends ApplicationContextProvider
{

    private static HashMap sTypefaceCollection = new HashMap();

    public FontServices(Context context)
    {
        super(context);
    }

    public String[] fetchAllSystemFontNames()
    {
        FilenameFilter filenamefilter = new FilenameFilter() {

            final FontServices this$0;

            public boolean accept(File file, String s1)
            {
                return s1.endsWith(".ttf");
            }

            
            {
                this$0 = FontServices.this;
                super();
            }
        };
        ArrayList arraylist = new ArrayList();
        File afile[] = (new File("/system/fonts/")).listFiles(filenamefilter);
        int i = afile.length;
        for (int j = 0; j < i; j++)
        {
            String s = afile[j].getName();
            arraylist.add(s.subSequence(0, s.lastIndexOf(".ttf")).toString());
        }

        return (String[])arraylist.toArray(new String[arraylist.size()]);
    }

    public Typeface fetchTypefaceFor(TypefaceInfo typefaceinfo)
    {
        if (typefaceinfo != null) goto _L2; else goto _L1
_L1:
        Typeface typeface = null;
_L4:
        return typeface;
_L2:
        synchronized (sTypefaceCollection)
        {
            typeface = (Typeface)sTypefaceCollection.get(typefaceinfo);
        }
        if (typeface != null) goto _L4; else goto _L3
_L3:
        if (typefaceinfo.getName() == null || typefaceinfo.getName().length() <= 0) goto _L6; else goto _L5
_L5:
        String s;
        FileServices fileservices;
        s = (new StringBuilder()).append(typefaceinfo.getName()).append(".ttf").toString();
        fileservices = new FileServices(getApplicationContext());
        if (fileservices.doesAssetFileExist(s))
        {
            break MISSING_BLOCK_LABEL_135;
        }
        s = (new StringBuilder()).append(typefaceinfo.getName()).append(".otf").toString();
        if (!fileservices.doesAssetFileExist(s))
        {
            s = null;
        }
        if (s == null)
        {
            break MISSING_BLOCK_LABEL_165;
        }
        File file1 = fileservices.extractAssetFile(s);
        if (file1 == null)
        {
            break MISSING_BLOCK_LABEL_165;
        }
        Typeface typeface2 = Typeface.createFromFile(file1);
        typeface = typeface2;
_L9:
        if (typeface != null)
        {
            break MISSING_BLOCK_LABEL_225;
        }
        Typeface typeface1;
        File file = new File((new StringBuilder()).append("/system/fonts/").append(typefaceinfo.getName()).append(".ttf").toString());
        if (!file.exists())
        {
            break MISSING_BLOCK_LABEL_225;
        }
        typeface1 = Typeface.createFromFile(file);
        typeface = typeface1;
_L8:
        if (typeface == null)
        {
            System.out.println((new StringBuilder()).append("WARNING: Could not load font ").append(typefaceinfo.getName()).append(". Using default.").toString());
        }
_L6:
        if (typeface == null)
        {
            if (typefaceinfo.isBold())
            {
                typeface = Typeface.DEFAULT_BOLD;
            } else
            {
                typeface = Typeface.DEFAULT;
            }
            if (typeface == null)
            {
                typeface = Typeface.create((String)null, typefaceinfo.getAndroidTypefaceStyle());
            }
        }
        if (typeface == null) goto _L4; else goto _L7
_L7:
        synchronized (sTypefaceCollection)
        {
            sTypefaceCollection.put(typefaceinfo, typeface);
        }
        return typeface;
        exception1;
        hashmap1;
        JVM INSTR monitorexit ;
        throw exception1;
        exception;
        hashmap;
        JVM INSTR monitorexit ;
        throw exception;
        Exception exception3;
        exception3;
          goto _L8
        Exception exception2;
        exception2;
          goto _L9
    }

    public Typeface fetchTypefaceFor(TypefaceSettings typefacesettings)
    {
        if (typefacesettings == null)
        {
            return null;
        } else
        {
            return fetchTypefaceFor(new TypefaceInfo(typefacesettings));
        }
    }

}
