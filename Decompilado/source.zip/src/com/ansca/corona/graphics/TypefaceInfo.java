// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.graphics;


// Referenced classes of package com.ansca.corona.graphics:
//            TypefaceSettings

public class TypefaceInfo
{

    private TypefaceSettings fSettings;

    public TypefaceInfo(TypefaceSettings typefacesettings)
    {
        if (typefacesettings == null)
        {
            throw new NullPointerException();
        } else
        {
            fSettings = typefacesettings.clone();
            return;
        }
    }

    public boolean equals(TypefaceInfo typefaceinfo)
    {
        if (typefaceinfo == null)
        {
            return false;
        } else
        {
            return equals(typefaceinfo.fSettings);
        }
    }

    public boolean equals(TypefaceSettings typefacesettings)
    {
        if (typefacesettings == null)
        {
            return false;
        } else
        {
            return fSettings.equals(typefacesettings);
        }
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof TypefaceInfo)
        {
            return equals((TypefaceInfo)obj);
        }
        if (obj instanceof TypefaceSettings)
        {
            return equals((TypefaceSettings)obj);
        } else
        {
            return false;
        }
    }

    public int getAndroidTypefaceStyle()
    {
        return fSettings.getAndroidTypefaceStyle();
    }

    public String getName()
    {
        return fSettings.getName();
    }

    public int hashCode()
    {
        return fSettings.hashCode();
    }

    public boolean isBold()
    {
        return fSettings.isBold();
    }

    public boolean isItalic()
    {
        return fSettings.isItalic();
    }
}
