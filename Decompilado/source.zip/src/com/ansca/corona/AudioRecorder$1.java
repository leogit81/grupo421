// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.media.MediaRecorder;
import java.io.PrintStream;

// Referenced classes of package com.ansca.corona:
//            AudioRecorder

class this._cls0
    implements android.media.ErrorListener
{

    final AudioRecorder this$0;

    public void onError(MediaRecorder mediarecorder, int i, int j)
    {
        System.out.println((new StringBuilder()).append("MediaRecorder error ").append(i).append(" ").append(j).toString());
        stopRecording();
    }

    orListener()
    {
        this$0 = AudioRecorder.this;
        super();
    }
}
