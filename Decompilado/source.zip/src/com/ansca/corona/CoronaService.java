// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class CoronaService extends Service
{
    private static class Binder extends android.os.Binder
    {

        private CoronaService fService;

        CoronaService getService()
        {
            return fService;
        }

        public Binder(CoronaService coronaservice)
        {
            fService = coronaservice;
        }
    }


    private Binder fBinder;

    public CoronaService()
    {
        fBinder = null;
    }

    public IBinder onBind(Intent intent)
    {
        if (fBinder == null)
        {
            fBinder = new Binder(this);
        }
        return fBinder;
    }

    public void onCreate()
    {
    }

    public void onDestroy()
    {
    }

    public int onStartCommand(Intent intent, int i, int j)
    {
        return 1;
    }
}
