// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            R

public static final class 
{

    public static final int com_facebook_login_activity_progress_bar = 0x7f050005;
    public static final int com_facebook_picker_activity_circle = 0x7f050004;
    public static final int com_facebook_picker_checkbox = 0x7f050007;
    public static final int com_facebook_picker_checkbox_stub = 0x7f05000b;
    public static final int com_facebook_picker_divider = 0x7f05000f;
    public static final int com_facebook_picker_done_button = 0x7f05000e;
    public static final int com_facebook_picker_image = 0x7f050008;
    public static final int com_facebook_picker_list_section_header = 0x7f05000c;
    public static final int com_facebook_picker_list_view = 0x7f050003;
    public static final int com_facebook_picker_profile_pic_stub = 0x7f050009;
    public static final int com_facebook_picker_row_activity_circle = 0x7f050006;
    public static final int com_facebook_picker_title = 0x7f05000a;
    public static final int com_facebook_picker_title_bar = 0x7f050011;
    public static final int com_facebook_picker_title_bar_stub = 0x7f050010;
    public static final int com_facebook_picker_top_bar = 0x7f05000d;
    public static final int com_facebook_placepickerfragment_search_box_stub = 0x7f050012;
    public static final int com_facebook_usersettingsfragment_login_button = 0x7f050017;
    public static final int com_facebook_usersettingsfragment_logo_image = 0x7f050015;
    public static final int com_facebook_usersettingsfragment_profile_name = 0x7f050016;
    public static final int large = 0x7f050002;
    public static final int normal = 0x7f050001;
    public static final int picker_subtitle = 0x7f050014;
    public static final int search_box = 0x7f050013;
    public static final int small = 0x7f050000;

    public ()
    {
    }
}
