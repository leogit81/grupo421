// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.util.Log;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Hashtable;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreConnectionListener, GoogleStore, GoogleStoreConnection, GoogleStorePurchaseNotification, 
//            StoreTransactionErrorType, GoogleStorePurchaseState, StoreTransactionResultSettings, GoogleStoreNotification, 
//            GoogleStoreFetchPendingPurchasesRequest, GoogleStoreRequest, GoogleStoreResponseCode, StoreTransactionState, 
//            GoogleStorePurchaseRequest

private class fStore
    implements GoogleStoreConnectionListener
{

    private GoogleStore fStore;
    final GoogleStore this$0;

    public void onConnectionClosed()
    {
    }

    public void onConnectionLost()
    {
        if (fStore.isEnabled() && GoogleStore.access$100(fStore) != null)
        {
            Log.v("Corona", "The connection to the Google Marketplace was lost unexpectedly. Attempting to restore the connection.");
            GoogleStore.access$100(fStore).open();
        }
    }

    public void onConnectionOpened()
    {
        GoogleStore.access$000(fStore);
    }

    public void onReceivedNotification(GoogleStoreNotification googlestorenotification)
    {
        if (googlestorenotification == null)
        {
            return;
        }
        if (googlestorenotification instanceof GoogleStorePurchaseNotification)
        {
            GoogleStorePurchaseNotification googlestorepurchasenotification = (GoogleStorePurchaseNotification)googlestorenotification;
            StoreTransactionErrorType storetransactionerrortype = StoreTransactionErrorType.NONE;
            if (googlestorepurchasenotification.getPurchaseState() == GoogleStorePurchaseState.CANCELED)
            {
                storetransactionerrortype = StoreTransactionErrorType.PAYMENT_CANCELED;
            }
            StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
            storetransactionresultsettings.setState(googlestorepurchasenotification.getPurchaseState().toTransactionState());
            storetransactionresultsettings.setErrorType(storetransactionerrortype);
            storetransactionresultsettings.setProductName(googlestorepurchasenotification.getProductStringId());
            storetransactionresultsettings.setReceipt(googlestorepurchasenotification.getSignedData());
            storetransactionresultsettings.setSignature(googlestorepurchasenotification.getSignature());
            storetransactionresultsettings.setTransactionStringId(googlestorepurchasenotification.getNotificationStringId());
            storetransactionresultsettings.setTransactionTime(googlestorepurchasenotification.getPurchaseTime());
            raiseTransactionEventFor(storetransactionresultsettings);
            return;
        } else
        {
            ArrayList arraylist = new ArrayList(1);
            arraylist.add(googlestorenotification.getNotificationStringId());
            GoogleStore _tmp = fStore;
            GoogleStoreFetchPendingPurchasesRequest googlestorefetchpendingpurchasesrequest = new GoogleStoreFetchPendingPurchasesRequest(GoogleStore.access$300().nextLong(), arraylist);
            GoogleStore.access$400(fStore).add(googlestorefetchpendingpurchasesrequest);
            GoogleStore.access$000(fStore);
            return;
        }
    }

    public void onReceivedResponse(long l, GoogleStoreResponseCode googlestoreresponsecode)
    {
        if (googlestoreresponsecode != null)
        {
            Long long1 = Long.valueOf(l);
            GoogleStoreRequest googlestorerequest = (GoogleStoreRequest)GoogleStore.access$200(fStore).get(long1);
            if (googlestorerequest != null)
            {
                GoogleStore.access$200(fStore).remove(long1);
                if (googlestoreresponsecode.isError())
                {
                    StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
                    if (googlestoreresponsecode == GoogleStoreResponseCode.USER_CANCELED)
                    {
                        storetransactionresultsettings.setState(StoreTransactionState.CANCELED);
                    } else
                    {
                        storetransactionresultsettings.setState(StoreTransactionState.FAILED);
                    }
                    storetransactionresultsettings.setErrorType(googlestoreresponsecode.toTransactionErrorType());
                    if (googlestorerequest instanceof GoogleStorePurchaseRequest)
                    {
                        storetransactionresultsettings.setProductName(((GoogleStorePurchaseRequest)googlestorerequest).getProductName());
                    }
                    raiseTransactionEventFor(storetransactionresultsettings);
                    return;
                }
            }
        }
    }

    public (GoogleStore googlestore1)
    {
        this$0 = GoogleStore.this;
        super();
        if (googlestore1 == null)
        {
            throw new NullPointerException();
        } else
        {
            fStore = googlestore1;
            return;
        }
    }
}
