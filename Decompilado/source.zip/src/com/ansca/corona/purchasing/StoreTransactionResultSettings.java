// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import java.util.Date;

// Referenced classes of package com.ansca.corona.purchasing:
//            StoreTransactionState, StoreTransactionErrorType

public class StoreTransactionResultSettings
{

    private String fErrorMessage;
    private StoreTransactionErrorType fErrorType;
    private String fOriginalReceipt;
    private String fOriginalTransactionStringId;
    private Date fOriginalTransactionTime;
    private String fProductName;
    private String fReceipt;
    private String fSignature;
    private StoreTransactionState fState;
    private String fTransactionStringId;
    private Date fTransactionTime;

    public StoreTransactionResultSettings()
    {
        fState = StoreTransactionState.UNDEFINED;
        fErrorType = StoreTransactionErrorType.UNKNOWN;
        fErrorMessage = "";
        fProductName = "";
        fSignature = "";
        fReceipt = "";
        fTransactionStringId = "";
        fTransactionTime = null;
        fOriginalReceipt = "";
        fOriginalTransactionStringId = "";
        fOriginalTransactionTime = null;
    }

    public String getErrorMessage()
    {
        return fErrorMessage;
    }

    public StoreTransactionErrorType getErrorType()
    {
        return fErrorType;
    }

    public String getOriginalReceipt()
    {
        return fOriginalReceipt;
    }

    public String getOriginalTransactionStringId()
    {
        return fOriginalTransactionStringId;
    }

    public Date getOriginalTransactionTime()
    {
        if (fOriginalTransactionTime == null)
        {
            return null;
        } else
        {
            return new Date(fOriginalTransactionTime.getTime());
        }
    }

    public String getProductName()
    {
        return fProductName;
    }

    public String getReceipt()
    {
        return fReceipt;
    }

    public String getSignature()
    {
        return fSignature;
    }

    public StoreTransactionState getState()
    {
        return fState;
    }

    public String getTransactionStringId()
    {
        return fTransactionStringId;
    }

    public Date getTransactionTime()
    {
        if (fTransactionTime == null)
        {
            return null;
        } else
        {
            return new Date(fTransactionTime.getTime());
        }
    }

    public boolean hasOriginalTransactionTime()
    {
        return fOriginalTransactionTime != null;
    }

    public boolean hasTransactionTime()
    {
        return fTransactionTime != null;
    }

    public void setErrorMessage(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fErrorMessage = s;
    }

    public void setErrorType(StoreTransactionErrorType storetransactionerrortype)
    {
        if (storetransactionerrortype == null)
        {
            storetransactionerrortype = StoreTransactionErrorType.UNKNOWN;
        }
        fErrorType = storetransactionerrortype;
    }

    public void setOriginalReceipt(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fOriginalReceipt = s;
    }

    public void setOriginalTransactionStringId(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fOriginalTransactionStringId = s;
    }

    public void setOriginalTransactionTime(Date date)
    {
        fOriginalTransactionTime = date;
    }

    public void setProductName(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fProductName = s;
    }

    public void setReceipt(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fReceipt = s;
    }

    public void setSignature(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fSignature = s;
    }

    public void setState(StoreTransactionState storetransactionstate)
    {
        if (storetransactionstate == null)
        {
            storetransactionstate = StoreTransactionState.UNDEFINED;
        }
        fState = storetransactionstate;
    }

    public void setTransactionStringId(String s)
    {
        if (s == null)
        {
            s = "";
        }
        fTransactionStringId = s;
    }

    public void setTransactionTime(Date date)
    {
        fTransactionTime = date;
    }
}
