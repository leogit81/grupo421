// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.Intent;

public class GoogleStoreNotification
{

    protected String fNotificationStringId;

    protected GoogleStoreNotification()
    {
        fNotificationStringId = "";
    }

    public static GoogleStoreNotification forId(String s)
    {
        if (s == null || s.length() <= 0)
        {
            return null;
        } else
        {
            GoogleStoreNotification googlestorenotification = new GoogleStoreNotification();
            googlestorenotification.fNotificationStringId = s;
            return googlestorenotification;
        }
    }

    public static GoogleStoreNotification from(Intent intent)
    {
        if (intent == null)
        {
            return null;
        }
        GoogleStoreNotification googlestorenotification;
        try
        {
            googlestorenotification = forId(intent.getStringExtra("notification_id"));
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
            return null;
        }
        return googlestorenotification;
    }

    public String getNotificationStringId()
    {
        return fNotificationStringId;
    }
}
