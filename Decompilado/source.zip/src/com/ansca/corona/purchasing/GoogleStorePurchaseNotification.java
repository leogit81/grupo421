// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import java.util.Date;
import org.json.JSONObject;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreNotification, GoogleStorePurchaseState

public class GoogleStorePurchaseNotification extends GoogleStoreNotification
{

    private String fDeveloperPayload;
    private String fPackageName;
    private String fProductStringId;
    private String fPurchaseOrderStringId;
    private GoogleStorePurchaseState fPurchaseState;
    private Date fPurchaseTime;
    private String fSignature;
    private String fSignedData;

    protected GoogleStorePurchaseNotification()
    {
        fPurchaseState = GoogleStorePurchaseState.REFUNDED;
        fProductStringId = "";
        fPackageName = "";
        fPurchaseTime = new Date(0L);
        fPurchaseOrderStringId = "";
        fSignedData = "";
        fSignature = "";
        fDeveloperPayload = "";
    }

    public static GoogleStorePurchaseNotification from(JSONObject jsonobject, String s, String s1)
    {
        if (jsonobject == null)
        {
            return null;
        }
        GoogleStorePurchaseNotification googlestorepurchasenotification = new GoogleStorePurchaseNotification();
        try
        {
            googlestorepurchasenotification.fPurchaseState = GoogleStorePurchaseState.fromOrdinal(jsonobject.getInt("purchaseState"));
            googlestorepurchasenotification.fProductStringId = jsonobject.getString("productId");
            googlestorepurchasenotification.fPackageName = jsonobject.getString("packageName");
            googlestorepurchasenotification.fPurchaseTime = new Date(jsonobject.getLong("purchaseTime"));
            googlestorepurchasenotification.fPurchaseOrderStringId = jsonobject.optString("orderId", "");
            googlestorepurchasenotification.fNotificationStringId = jsonobject.optString("notificationId", "");
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
            return null;
        }
        if (s == null)
        {
            s = "";
        }
        googlestorepurchasenotification.fSignedData = s;
        if (s1 == null)
        {
            s1 = "";
        }
        googlestorepurchasenotification.fSignature = s1;
        googlestorepurchasenotification.fDeveloperPayload = jsonobject.optString("developerPayload", "");
        return googlestorepurchasenotification;
    }

    public String getDeveloperPayload()
    {
        return fDeveloperPayload;
    }

    public String getPackageName()
    {
        return fPackageName;
    }

    public String getProductStringId()
    {
        return fProductStringId;
    }

    public String getPurchaseOrderStringId()
    {
        return fPurchaseOrderStringId;
    }

    public GoogleStorePurchaseState getPurchaseState()
    {
        return fPurchaseState;
    }

    public Date getPurchaseTime()
    {
        return new Date(fPurchaseTime.getTime());
    }

    public String getSignature()
    {
        return fSignature;
    }

    public String getSignedData()
    {
        return fSignedData;
    }
}
