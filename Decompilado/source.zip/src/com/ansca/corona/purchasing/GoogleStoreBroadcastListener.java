// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.Context;
import android.content.Intent;

public interface GoogleStoreBroadcastListener
{

    public abstract void onReceive(Context context, Intent intent);
}
