// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import com.ansca.corona.CoronaEnvironment;
import java.util.Arrays;
import java.util.LinkedHashSet;

// Referenced classes of package com.ansca.corona.purchasing:
//            StoreName

public class StoreServices
{

    public static final String AMAZON_MARKETPLACE_APP_PACKAGE_NAME = "com.amazon.venezia";
    public static final String GOOGLE_MARKETPLACE_APP_PACKAGE_NAME_1 = "com.android.vending";
    public static final String GOOGLE_MARKETPLACE_APP_PACKAGE_NAME_2 = "com.google.android.feedback";
    public static final String SAMSUNG_MARKETPLACE_APP_PACKAGE_NAME = "com.sec.android.app.samsungapps";

    private StoreServices()
    {
    }

    public static String[] getAvailableAppStoreNames()
    {
        LinkedHashSet linkedhashset = new LinkedHashSet();
        String s = Build.MANUFACTURER.toLowerCase();
        if (isPackageNameInstalled("com.android.vending") || isPackageNameInstalled("com.google.android.feedback"))
        {
            linkedhashset.add("google");
        }
        if (isPackageNameInstalled("com.amazon.venezia"))
        {
            linkedhashset.add("amazon");
        }
        if (isPackageNameInstalled("com.sec.android.app.samsungapps"))
        {
            linkedhashset.add("samsung");
        }
        String s1 = System.getProperty("ro.nook.manufacturer");
        if (s.contains("barnes") && s.contains("noble") || s1 != null && s1.length() > 0)
        {
            linkedhashset.add("nook");
        }
        int i = linkedhashset.size();
        String as[] = null;
        if (i > 0)
        {
            as = (String[])linkedhashset.toArray(new String[0]);
        }
        return as;
    }

    public static String[] getAvailableInAppStoreNames()
    {
        boolean flag = isInAppStoreAvailable("google");
        String as[] = null;
        if (flag)
        {
            as = new String[1];
            as[0] = "google";
        }
        return as;
    }

    public static String getDefaultInAppStoreName()
    {
        if (isInAppStoreAvailable("google"))
        {
            return "google";
        } else
        {
            return "none";
        }
    }

    public static String getStoreApplicationWasPurchasedFrom()
    {
        String s;
        try
        {
            Context context = CoronaEnvironment.getApplicationContext();
            s = StoreName.fromPackageName(context.getPackageManager().getInstallerPackageName(context.getPackageName()));
        }
        catch (Exception exception)
        {
            return "none";
        }
        return s;
    }

    public static String getTargetedAppStoreName()
    {
        String s = null;
        ApplicationInfo applicationinfo;
        Context context = CoronaEnvironment.getApplicationContext();
        applicationinfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
        s = null;
        if (applicationinfo == null)
        {
            break MISSING_BLOCK_LABEL_63;
        }
        Bundle bundle = applicationinfo.metaData;
        s = null;
        if (bundle == null)
        {
            break MISSING_BLOCK_LABEL_63;
        }
        s = applicationinfo.metaData.getString("targetedAppStore");
        if (s == null)
        {
            break MISSING_BLOCK_LABEL_63;
        }
        String s1 = s.trim();
        s = s1;
_L2:
        if (s == null || s.length() <= 0)
        {
            s = "none";
        }
        return s;
        Exception exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public static boolean isAppStoreAvailable(String s)
    {
        String as[];
        if (!StoreName.isNotValid(s))
        {
            if ((as = getAvailableAppStoreNames()) != null && Arrays.binarySearch(as, s) >= 0)
            {
                return true;
            }
        }
        return false;
    }

    public static boolean isInAppStoreAvailable(String s)
    {
        if (!StoreName.isNotValid(s)) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if (!s.equals("google"))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!isPackageNameInstalled("com.android.vending") && !isPackageNameInstalled("com.google.android.feedback")) goto _L1; else goto _L3
_L3:
        return true;
        if (!s.equals("amazon")) goto _L1; else goto _L4
_L4:
        return false;
    }

    private static boolean isPackageNameInstalled(String s)
    {
        if (s == null || s.length() <= 0)
        {
            return false;
        }
        try
        {
            CoronaEnvironment.getApplicationContext().getPackageManager().getPackageInfo(s, 1);
        }
        catch (Exception exception)
        {
            return false;
        }
        return true;
    }
}
