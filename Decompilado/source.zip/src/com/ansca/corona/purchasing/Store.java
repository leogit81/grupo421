// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.app.Activity;
import com.ansca.corona.Controller;
import com.ansca.corona.JavaToNativeShim;
import com.ansca.corona.events.EventManager;
import com.ansca.corona.events.RunnableEvent;

// Referenced classes of package com.ansca.corona.purchasing:
//            StoreTransactionResultSettings

public abstract class Store
{

    private Activity fActivity;
    private boolean fIsEnabled;

    public Store()
    {
        fIsEnabled = false;
        fActivity = null;
    }

    public abstract boolean canMakePurchases();

    public abstract void confirmTransaction(String s);

    public void disable()
    {
        if (!fIsEnabled)
        {
            return;
        } else
        {
            fIsEnabled = false;
            onDisabled();
            return;
        }
    }

    public void enable()
    {
        if (fIsEnabled)
        {
            return;
        }
        if (fActivity == null)
        {
            throw new IllegalStateException();
        } else
        {
            fIsEnabled = true;
            onEnabled();
            return;
        }
    }

    public Activity getActivity()
    {
        return fActivity;
    }

    public boolean isDisabled()
    {
        return !fIsEnabled;
    }

    public boolean isEnabled()
    {
        return fIsEnabled;
    }

    protected void onDisabled()
    {
    }

    protected abstract void onEnabled();

    public abstract void purchase(String s);

    protected void raiseTransactionEventFor(final StoreTransactionResultSettings result)
    {
        EventManager eventmanager;
        if (result != null)
        {
            if ((eventmanager = Controller.getEventManager()) != null)
            {
                eventmanager.addEvent(new RunnableEvent(new Runnable() {

                    final Store this$0;
                    final StoreTransactionResultSettings val$result;

                    public void run()
                    {
                        if (Controller.isValid())
                        {
                            JavaToNativeShim.storeTransactionEvent(result);
                        }
                    }

            
            {
                this$0 = Store.this;
                result = storetransactionresultsettings;
                super();
            }
                }));
                return;
            }
        }
    }

    public abstract void restorePurchases();

    public void setActivity(Activity activity)
    {
        fActivity = activity;
    }
}
