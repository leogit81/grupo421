// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.app.Activity;
import android.util.Log;

// Referenced classes of package com.ansca.corona.purchasing:
//            Store, StoreTransactionResultSettings, StoreTransactionState, StoreTransactionErrorType, 
//            StoreServices, GoogleStore, StoreName

public class StoreProxy extends Store
{

    private static final String STORE_NOT_SUPPORTED_WARNING_MESSAGE = "This application does not support in-app purchases on this device.";
    private Store fStore;

    public StoreProxy()
    {
        fStore = null;
    }

    private void setStoreTo(Store store)
    {
        if (store != fStore)
        {
            if (fStore != null)
            {
                fStore.disable();
            }
            fStore = store;
            if (fStore != null)
            {
                fStore.setActivity(getActivity());
                if (isEnabled())
                {
                    fStore.enable();
                    return;
                } else
                {
                    fStore.disable();
                    return;
                }
            }
        }
    }

    public boolean canMakePurchases()
    {
        if (fStore == null)
        {
            return false;
        } else
        {
            return fStore.canMakePurchases();
        }
    }

    public void confirmTransaction(String s)
    {
        if (fStore == null)
        {
            StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
            storetransactionresultsettings.setState(StoreTransactionState.FAILED);
            storetransactionresultsettings.setErrorType(StoreTransactionErrorType.CLIENT_INVALID);
            storetransactionresultsettings.setErrorMessage("This application does not support in-app purchases on this device.");
            storetransactionresultsettings.setTransactionStringId(s);
            raiseTransactionEventFor(storetransactionresultsettings);
            logStoreNotSupportedWarning();
            return;
        } else
        {
            fStore.confirmTransaction(s);
            return;
        }
    }

    public void disable()
    {
        super.disable();
        if (fStore != null)
        {
            fStore.disable();
        }
    }

    public void enable()
    {
        super.enable();
        if (fStore != null)
        {
            fStore.enable();
        }
    }

    public void logStoreNotSupportedWarning()
    {
        Log.v("Corona", "This application does not support in-app purchases on this device.");
    }

    protected void onEnabled()
    {
    }

    public void purchase(String s)
    {
        if (fStore == null)
        {
            StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
            storetransactionresultsettings.setState(StoreTransactionState.FAILED);
            storetransactionresultsettings.setErrorType(StoreTransactionErrorType.CLIENT_INVALID);
            storetransactionresultsettings.setErrorMessage("This application does not support in-app purchases on this device.");
            storetransactionresultsettings.setProductName(s);
            raiseTransactionEventFor(storetransactionresultsettings);
            logStoreNotSupportedWarning();
            return;
        } else
        {
            fStore.purchase(s);
            return;
        }
    }

    public void restorePurchases()
    {
        if (fStore == null)
        {
            StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
            storetransactionresultsettings.setState(StoreTransactionState.FAILED);
            storetransactionresultsettings.setErrorType(StoreTransactionErrorType.CLIENT_INVALID);
            storetransactionresultsettings.setErrorMessage("This application does not support in-app purchases on this device.");
            raiseTransactionEventFor(storetransactionresultsettings);
            logStoreNotSupportedWarning();
            return;
        } else
        {
            fStore.restorePurchases();
            return;
        }
    }

    public void setActivity(Activity activity)
    {
        super.setActivity(activity);
        if (fStore != null)
        {
            fStore.setActivity(activity);
        }
    }

    public void useDefaultStore()
    {
        useStore(StoreServices.getDefaultInAppStoreName());
    }

    public void useGoogleStore()
    {
        setStoreTo(new GoogleStore());
    }

    public void useNoStore()
    {
        setStoreTo(null);
    }

    public void useStore(String s)
    {
        if (StoreName.isValid(s) && s.equals("google"))
        {
            useGoogleStore();
            return;
        } else
        {
            useNoStore();
            return;
        }
    }
}
