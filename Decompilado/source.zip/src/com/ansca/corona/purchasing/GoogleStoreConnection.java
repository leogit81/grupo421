// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreConnectionState, GoogleStoreConnectionListener, GoogleStoreRequestError, GoogleStoreSendRequestResult, 
//            GoogleStoreRequest, GoogleStorePurchaseRequest, GoogleStoreBroadcastListener, GoogleStoreBroadcastReceiver, 
//            GoogleStorePurchaseNotification, GoogleStoreNotification, GoogleStoreResponseCode

public class GoogleStoreConnection
    implements ServiceConnection
{
    private class GoogleStoreEventHandler
        implements GoogleStoreBroadcastListener
    {

        private GoogleStoreConnection fConnection;
        final GoogleStoreConnection this$0;

        public void dispose()
        {
            GoogleStoreBroadcastReceiver.removeListener(this);
        }

        public void onReceive(Context context, Intent intent)
        {
            if (context != null && intent != null) goto _L2; else goto _L1
_L1:
            String s;
            return;
_L2:
            if ((s = intent.getAction()) == null || s.length() <= 0)
            {
                continue; /* Loop/switch isn't completed */
            }
            if (!s.equals("com.android.vending.billing.PURCHASE_STATE_CHANGED")) goto _L4; else goto _L3
_L3:
            if (fConnection.fConnectionListener == null)
            {
                continue; /* Loop/switch isn't completed */
            }
            String s1;
            String s2;
            JSONArray jsonarray;
            int j;
            GoogleStorePurchaseNotification googlestorepurchasenotification;
            try
            {
                s1 = intent.getStringExtra("inapp_signed_data");
                s2 = intent.getStringExtra("inapp_signature");
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
                return;
            }
            if (s1 == null)
            {
                continue; /* Loop/switch isn't completed */
            }
            if (s1.length() <= 0)
            {
                continue; /* Loop/switch isn't completed */
            }
            jsonarray = (new JSONObject(s1)).optJSONArray("orders");
            if (jsonarray == null)
            {
                continue; /* Loop/switch isn't completed */
            }
            j = 0;
_L5:
            if (j >= jsonarray.length())
            {
                continue; /* Loop/switch isn't completed */
            }
            googlestorepurchasenotification = GoogleStorePurchaseNotification.from(jsonarray.getJSONObject(j), s1, s2);
            if (googlestorepurchasenotification == null)
            {
                break MISSING_BLOCK_LABEL_142;
            }
            fConnection.fConnectionListener.onReceivedNotification(googlestorepurchasenotification);
            j++;
            if (true) goto _L5; else goto _L4
_L4:
            if (!s.equals("com.android.vending.billing.IN_APP_NOTIFY"))
            {
                break; /* Loop/switch isn't completed */
            }
            if (fConnection.fConnectionListener != null)
            {
                GoogleStoreNotification googlestorenotification = GoogleStoreNotification.from(intent);
                if (googlestorenotification != null)
                {
                    fConnection.fConnectionListener.onReceivedNotification(googlestorenotification);
                    return;
                }
            }
            if (true) goto _L1; else goto _L6
_L6:
            if (s.equals("com.android.vending.billing.RESPONSE_CODE"))
            {
                if (fConnection.fConnectionListener != null)
                {
                    long l = intent.getLongExtra("request_id", -1L);
                    int i = intent.getIntExtra("response_code", GoogleStoreResponseCode.ERROR.ordinal());
                    fConnection.fConnectionListener.onReceivedResponse(l, GoogleStoreResponseCode.fromOrdinal(i));
                    return;
                }
            } else
            {
                Log.v("Corona", (new StringBuilder()).append("Received unkown action name '").append(s).append("' from the Android Marketplace.").toString());
                return;
            }
            if (true) goto _L1; else goto _L7
_L7:
        }

        public GoogleStoreEventHandler(GoogleStoreConnection googlestoreconnection1)
        {
            this$0 = GoogleStoreConnection.this;
            super();
            if (googlestoreconnection1 == null)
            {
                throw new NullPointerException();
            } else
            {
                fConnection = googlestoreconnection1;
                GoogleStoreBroadcastReceiver.addListener(this);
                return;
            }
        }
    }

    private static interface IMarketBillingService
        extends IInterface
    {

        public abstract Bundle sendBillingRequest(Bundle bundle)
            throws RemoteException;
    }

    public static abstract class IMarketBillingService.Stub extends Binder
        implements IMarketBillingService
    {

        private static final String DESCRIPTOR = "com.android.vending.billing.IMarketBillingService";
        static final int TRANSACTION_sendBillingRequest = 1;

        public static IMarketBillingService asInterface(IBinder ibinder)
        {
            if (ibinder == null)
            {
                return null;
            }
            IInterface iinterface = ibinder.queryLocalInterface("com.android.vending.billing.IMarketBillingService");
            if (iinterface != null && (iinterface instanceof IMarketBillingService))
            {
                return (IMarketBillingService)iinterface;
            } else
            {
                return new Proxy(ibinder);
            }
        }

        public IBinder asBinder()
        {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
            throws RemoteException
        {
            int k;
            Bundle bundle;
            switch (i)
            {
            default:
                return super.onTransact(i, parcel, parcel1, j);

            case 1598968902: 
                parcel1.writeString("com.android.vending.billing.IMarketBillingService");
                return true;

            case 1: // '\001'
                parcel.enforceInterface("com.android.vending.billing.IMarketBillingService");
                k = parcel.readInt();
                bundle = null;
                break;
            }
            if (k != 0)
            {
                bundle = (Bundle)Bundle.CREATOR.createFromParcel(parcel);
            }
            Bundle bundle1 = sendBillingRequest(bundle);
            parcel1.writeNoException();
            if (bundle1 != null)
            {
                parcel1.writeInt(1);
                bundle1.writeToParcel(parcel1, 1);
                return true;
            } else
            {
                parcel1.writeInt(0);
                return true;
            }
        }

        public IMarketBillingService.Stub()
        {
            attachInterface(this, "com.android.vending.billing.IMarketBillingService");
        }
    }

    private static class IMarketBillingService.Stub.Proxy
        implements IMarketBillingService
    {

        private IBinder mRemote;

        public IBinder asBinder()
        {
            return mRemote;
        }

        public String getInterfaceDescriptor()
        {
            return "com.android.vending.billing.IMarketBillingService";
        }

        public Bundle sendBillingRequest(Bundle bundle)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.android.vending.billing.IMarketBillingService");
            if (bundle == null) goto _L2; else goto _L1
_L1:
            parcel.writeInt(1);
            bundle.writeToParcel(parcel, 0);
_L3:
            Bundle bundle1;
            mRemote.transact(1, parcel, parcel1, 0);
            parcel1.readException();
            if (parcel1.readInt() == 0)
            {
                break MISSING_BLOCK_LABEL_100;
            }
            bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(parcel1);
_L4:
            parcel1.recycle();
            parcel.recycle();
            return bundle1;
_L2:
            parcel.writeInt(0);
              goto _L3
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
            bundle1 = null;
              goto _L4
        }

        public IMarketBillingService.Stub.Proxy(IBinder ibinder)
        {
            mRemote = ibinder;
        }
    }


    private GoogleStoreConnectionListener fConnectionListener;
    private GoogleStoreConnectionState fConnectionState;
    private Context fContext;
    private IMarketBillingService fServiceInterface;
    private GoogleStoreEventHandler fStoreEventHandler;

    public GoogleStoreConnection(Context context)
    {
        if (context == null)
        {
            throw new NullPointerException();
        } else
        {
            fContext = context;
            fConnectionState = GoogleStoreConnectionState.CLOSED;
            fServiceInterface = null;
            fStoreEventHandler = null;
            fConnectionListener = null;
            return;
        }
    }

    public void close()
    {
        if (fConnectionState != GoogleStoreConnectionState.OPEN)
        {
            return;
        }
        try
        {
            fConnectionState = GoogleStoreConnectionState.CLOSING;
            fContext.unbindService(this);
            return;
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public GoogleStoreConnectionState getConnectionState()
    {
        return fConnectionState;
    }

    public GoogleStoreConnectionListener getListener()
    {
        return fConnectionListener;
    }

    public boolean isOpen()
    {
        return fConnectionState == GoogleStoreConnectionState.OPEN;
    }

    public void onServiceConnected(ComponentName componentname, IBinder ibinder)
    {
        if (ibinder != null)
        {
            fServiceInterface = IMarketBillingService.Stub.asInterface(ibinder);
            fConnectionState = GoogleStoreConnectionState.OPEN;
            if (fStoreEventHandler == null)
            {
                fStoreEventHandler = new GoogleStoreEventHandler(this);
            }
            if (fConnectionListener != null)
            {
                fConnectionListener.onConnectionOpened();
                return;
            }
        }
    }

    public void onServiceDisconnected(ComponentName componentname)
    {
label0:
        {
            boolean flag;
            if (fConnectionState != GoogleStoreConnectionState.CLOSING)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            fServiceInterface = null;
            fConnectionState = GoogleStoreConnectionState.CLOSED;
            if (fStoreEventHandler != null)
            {
                fStoreEventHandler.dispose();
                fStoreEventHandler = null;
            }
            if (fConnectionListener != null)
            {
                if (!flag)
                {
                    break label0;
                }
                fConnectionListener.onConnectionLost();
            }
            return;
        }
        fConnectionListener.onConnectionClosed();
    }

    public void open()
    {
        if (fConnectionState == GoogleStoreConnectionState.CLOSED) goto _L2; else goto _L1
_L1:
        return;
_L2:
        boolean flag1;
        fConnectionState = GoogleStoreConnectionState.OPENING;
        Intent intent = new Intent("com.android.vending.billing.MarketBillingService.BIND");
        flag1 = fContext.bindService(intent, this, 1);
        boolean flag = flag1;
_L4:
        if (!flag)
        {
            fConnectionState = GoogleStoreConnectionState.CLOSED;
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        exception.printStackTrace();
        flag = false;
          goto _L4
    }

    public GoogleStoreSendRequestResult send(GoogleStoreRequest googlestorerequest)
    {
        if (googlestorerequest != null) goto _L2; else goto _L1
_L1:
        GoogleStoreSendRequestResult googlestoresendrequestresult = GoogleStoreSendRequestResult.failedWith(GoogleStoreRequestError.INVALID_REQUEST);
_L4:
        return googlestoresendrequestresult;
_L2:
        boolean flag;
        if (!isOpen())
        {
            return GoogleStoreSendRequestResult.failedWith(GoogleStoreRequestError.CONNECTION_ERROR);
        }
        Bundle bundle = googlestorerequest.toBundle();
        IMarketBillingService imarketbillingservice;
        Bundle bundle1;
        Bundle bundle2;
        PendingIntent pendingintent;
        try
        {
            imarketbillingservice = fServiceInterface;
        }
        catch (RemoteException remoteexception)
        {
            onServiceDisconnected(null);
            return GoogleStoreSendRequestResult.failedWith(GoogleStoreRequestError.CONNECTION_ERROR);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
            return GoogleStoreSendRequestResult.failedWith(GoogleStoreRequestError.MARKETPLACE_ERROR);
        }
        bundle1 = null;
        if (imarketbillingservice == null)
        {
            break MISSING_BLOCK_LABEL_91;
        }
        bundle1 = null;
        if (bundle == null)
        {
            break MISSING_BLOCK_LABEL_91;
        }
        bundle.putInt("API_VERSION", 2);
        bundle.putString("PACKAGE_NAME", fContext.getPackageName());
        bundle2 = fServiceInterface.sendBillingRequest(bundle);
        bundle1 = bundle2;
        googlestoresendrequestresult = GoogleStoreSendRequestResult.from(bundle1);
        if (googlestoresendrequestresult.hasFailed() || !(googlestorerequest instanceof GoogleStorePurchaseRequest))
        {
            continue; /* Loop/switch isn't completed */
        }
        pendingintent = (PendingIntent)bundle1.getParcelable("PURCHASE_INTENT");
        flag = false;
        if (pendingintent == null)
        {
            break MISSING_BLOCK_LABEL_158;
        }
        fContext.startIntentSender(pendingintent.getIntentSender(), new Intent(), 0, 0, 0);
        flag = true;
_L5:
        if (!flag)
        {
            return GoogleStoreSendRequestResult.failedWith(GoogleStoreRequestError.MARKETPLACE_ERROR);
        }
        if (true) goto _L4; else goto _L3
_L3:
        Exception exception1;
        exception1;
        exception1.printStackTrace();
        flag = false;
          goto _L5
    }

    public void setListener(GoogleStoreConnectionListener googlestoreconnectionlistener)
    {
        fConnectionListener = googlestoreconnectionlistener;
    }

}
