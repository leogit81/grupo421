// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


public final class GoogleStoreRequestError extends Enum
{

    private static final GoogleStoreRequestError $VALUES[];
    public static final GoogleStoreRequestError CONNECTION_ERROR;
    public static final GoogleStoreRequestError INVALID_REQUEST;
    public static final GoogleStoreRequestError MARKETPLACE_ERROR;
    public static final GoogleStoreRequestError NONE;

    private GoogleStoreRequestError(String s, int i)
    {
        super(s, i);
    }

    public static GoogleStoreRequestError valueOf(String s)
    {
        return (GoogleStoreRequestError)Enum.valueOf(com/ansca/corona/purchasing/GoogleStoreRequestError, s);
    }

    public static GoogleStoreRequestError[] values()
    {
        return (GoogleStoreRequestError[])$VALUES.clone();
    }

    static 
    {
        NONE = new GoogleStoreRequestError("NONE", 0);
        INVALID_REQUEST = new GoogleStoreRequestError("INVALID_REQUEST", 1);
        CONNECTION_ERROR = new GoogleStoreRequestError("CONNECTION_ERROR", 2);
        MARKETPLACE_ERROR = new GoogleStoreRequestError("MARKETPLACE_ERROR", 3);
        GoogleStoreRequestError agooglestorerequesterror[] = new GoogleStoreRequestError[4];
        agooglestorerequesterror[0] = NONE;
        agooglestorerequesterror[1] = INVALID_REQUEST;
        agooglestorerequesterror[2] = CONNECTION_ERROR;
        agooglestorerequesterror[3] = MARKETPLACE_ERROR;
        $VALUES = agooglestorerequesterror;
    }
}
