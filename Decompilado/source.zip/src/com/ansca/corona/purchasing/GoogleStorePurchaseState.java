// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


// Referenced classes of package com.ansca.corona.purchasing:
//            StoreTransactionState

public final class GoogleStorePurchaseState extends Enum
{

    private static final GoogleStorePurchaseState $VALUES[];
    public static final GoogleStorePurchaseState CANCELED;
    public static final GoogleStorePurchaseState PURCHASED;
    public static final GoogleStorePurchaseState REFUNDED;

    private GoogleStorePurchaseState(String s, int i)
    {
        super(s, i);
    }

    public static GoogleStorePurchaseState fromOrdinal(int i)
    {
        GoogleStorePurchaseState agooglestorepurchasestate[] = values();
        if (i < 0 || i >= agooglestorepurchasestate.length)
        {
            return REFUNDED;
        } else
        {
            return agooglestorepurchasestate[i];
        }
    }

    public static GoogleStorePurchaseState valueOf(String s)
    {
        return (GoogleStorePurchaseState)Enum.valueOf(com/ansca/corona/purchasing/GoogleStorePurchaseState, s);
    }

    public static GoogleStorePurchaseState[] values()
    {
        return (GoogleStorePurchaseState[])$VALUES.clone();
    }

    public StoreTransactionState toTransactionState()
    {
        if (this == PURCHASED)
        {
            return StoreTransactionState.PURCHASED;
        }
        if (this == CANCELED)
        {
            return StoreTransactionState.CANCELED;
        }
        if (this == REFUNDED)
        {
            return StoreTransactionState.REFUNDED;
        } else
        {
            return StoreTransactionState.FAILED;
        }
    }

    static 
    {
        PURCHASED = new GoogleStorePurchaseState("PURCHASED", 0);
        CANCELED = new GoogleStorePurchaseState("CANCELED", 1);
        REFUNDED = new GoogleStorePurchaseState("REFUNDED", 2);
        GoogleStorePurchaseState agooglestorepurchasestate[] = new GoogleStorePurchaseState[3];
        agooglestorepurchasestate[0] = PURCHASED;
        agooglestorepurchasestate[1] = CANCELED;
        agooglestorepurchasestate[2] = REFUNDED;
        $VALUES = agooglestorepurchasestate;
    }
}
