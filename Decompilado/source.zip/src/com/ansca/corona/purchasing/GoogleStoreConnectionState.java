// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


public final class GoogleStoreConnectionState extends Enum
{

    private static final GoogleStoreConnectionState $VALUES[];
    public static final GoogleStoreConnectionState CLOSED;
    public static final GoogleStoreConnectionState CLOSING;
    public static final GoogleStoreConnectionState OPEN;
    public static final GoogleStoreConnectionState OPENING;

    private GoogleStoreConnectionState(String s, int i)
    {
        super(s, i);
    }

    public static GoogleStoreConnectionState valueOf(String s)
    {
        return (GoogleStoreConnectionState)Enum.valueOf(com/ansca/corona/purchasing/GoogleStoreConnectionState, s);
    }

    public static GoogleStoreConnectionState[] values()
    {
        return (GoogleStoreConnectionState[])$VALUES.clone();
    }

    static 
    {
        OPENING = new GoogleStoreConnectionState("OPENING", 0);
        OPEN = new GoogleStoreConnectionState("OPEN", 1);
        CLOSING = new GoogleStoreConnectionState("CLOSING", 2);
        CLOSED = new GoogleStoreConnectionState("CLOSED", 3);
        GoogleStoreConnectionState agooglestoreconnectionstate[] = new GoogleStoreConnectionState[4];
        agooglestoreconnectionstate[0] = OPENING;
        agooglestoreconnectionstate[1] = OPEN;
        agooglestoreconnectionstate[2] = CLOSING;
        agooglestoreconnectionstate[3] = CLOSED;
        $VALUES = agooglestoreconnectionstate;
    }
}
