// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


// Referenced classes of package com.ansca.corona.purchasing:
//            StoreTransactionErrorType

public final class GoogleStoreResponseCode extends Enum
{

    private static final GoogleStoreResponseCode $VALUES[];
    public static final GoogleStoreResponseCode BILLING_UNAVAILABLE;
    public static final GoogleStoreResponseCode DEVELOPER_ERROR;
    public static final GoogleStoreResponseCode ERROR;
    public static final GoogleStoreResponseCode ITEM_UNAVAILABLE;
    public static final GoogleStoreResponseCode OK;
    public static final GoogleStoreResponseCode SERVICE_UNAVAILABLE;
    public static final GoogleStoreResponseCode USER_CANCELED;

    private GoogleStoreResponseCode(String s, int i)
    {
        super(s, i);
    }

    public static GoogleStoreResponseCode fromOrdinal(int i)
    {
        GoogleStoreResponseCode agooglestoreresponsecode[] = values();
        if (i < 0 || i >= agooglestoreresponsecode.length)
        {
            return ERROR;
        } else
        {
            return agooglestoreresponsecode[i];
        }
    }

    public static GoogleStoreResponseCode valueOf(String s)
    {
        return (GoogleStoreResponseCode)Enum.valueOf(com/ansca/corona/purchasing/GoogleStoreResponseCode, s);
    }

    public static GoogleStoreResponseCode[] values()
    {
        return (GoogleStoreResponseCode[])$VALUES.clone();
    }

    public boolean isError()
    {
        return !isSuccess();
    }

    public boolean isSuccess()
    {
        return this == OK;
    }

    public StoreTransactionErrorType toTransactionErrorType()
    {
        if (this == OK)
        {
            return StoreTransactionErrorType.NONE;
        }
        if (this == USER_CANCELED)
        {
            return StoreTransactionErrorType.PAYMENT_CANCELED;
        }
        if (this == SERVICE_UNAVAILABLE || this == DEVELOPER_ERROR || this == ITEM_UNAVAILABLE)
        {
            return StoreTransactionErrorType.CLIENT_INVALID;
        }
        if (this == BILLING_UNAVAILABLE)
        {
            return StoreTransactionErrorType.PAYMENT_NOT_ALLOWED;
        } else
        {
            return StoreTransactionErrorType.UNKNOWN;
        }
    }

    static 
    {
        OK = new GoogleStoreResponseCode("OK", 0);
        USER_CANCELED = new GoogleStoreResponseCode("USER_CANCELED", 1);
        SERVICE_UNAVAILABLE = new GoogleStoreResponseCode("SERVICE_UNAVAILABLE", 2);
        BILLING_UNAVAILABLE = new GoogleStoreResponseCode("BILLING_UNAVAILABLE", 3);
        ITEM_UNAVAILABLE = new GoogleStoreResponseCode("ITEM_UNAVAILABLE", 4);
        DEVELOPER_ERROR = new GoogleStoreResponseCode("DEVELOPER_ERROR", 5);
        ERROR = new GoogleStoreResponseCode("ERROR", 6);
        GoogleStoreResponseCode agooglestoreresponsecode[] = new GoogleStoreResponseCode[7];
        agooglestoreresponsecode[0] = OK;
        agooglestoreresponsecode[1] = USER_CANCELED;
        agooglestoreresponsecode[2] = SERVICE_UNAVAILABLE;
        agooglestoreresponsecode[3] = BILLING_UNAVAILABLE;
        agooglestoreresponsecode[4] = ITEM_UNAVAILABLE;
        agooglestoreresponsecode[5] = DEVELOPER_ERROR;
        agooglestoreresponsecode[6] = ERROR;
        $VALUES = agooglestoreresponsecode;
    }
}
