// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


public class StoreName
{

    public static final String AMAZON = "amazon";
    public static final String GOOGLE = "google";
    public static final String NONE = "none";
    public static final String NOOK = "nook";
    public static final String SAMSUNG = "samsung";
    public static final String UNKNOWN = "unknown";

    private StoreName()
    {
    }

    public static String fromPackageName(String s)
    {
        if (s == null || s.length() <= 0)
        {
            return "none";
        }
        if (s.equals("com.android.vending") || s.equals("com.google.android.feedback"))
        {
            return "google";
        }
        if (s.equals("com.amazon.venezia"))
        {
            return "amazon";
        }
        if (s.equals("com.sec.android.app.samsungapps"))
        {
            return "samsung";
        } else
        {
            return "unknown";
        }
    }

    public static boolean isNotValid(String s)
    {
        return !isValid(s);
    }

    public static boolean isValid(String s)
    {
        return s != null && (s.equals("google") || s.equals("amazon") || s.equals("nook") || s.equals("samsung"));
    }
}
