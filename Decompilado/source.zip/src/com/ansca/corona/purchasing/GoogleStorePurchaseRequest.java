// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.os.Bundle;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreRequest

public class GoogleStorePurchaseRequest extends GoogleStoreRequest
{

    private String fProductName;

    public GoogleStorePurchaseRequest(String s)
    {
        if (s == null || s.length() <= 0)
        {
            throw new NullPointerException();
        } else
        {
            fProductName = s;
            return;
        }
    }

    public String getProductName()
    {
        return fProductName;
    }

    public Bundle toBundle()
    {
        Bundle bundle = new Bundle();
        bundle.putString("BILLING_REQUEST", "REQUEST_PURCHASE");
        bundle.putString("ITEM_ID", fProductName);
        return bundle;
    }
}
