// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.Context;
import android.util.Log;
import com.ansca.corona.CoronaEnvironment;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Hashtable;

// Referenced classes of package com.ansca.corona.purchasing:
//            Store, GoogleStoreConnection, GoogleStoreRequest, GoogleStoreSendRequestResult, 
//            GoogleStoreRequestError, StoreTransactionResultSettings, StoreTransactionState, StoreTransactionErrorType, 
//            GoogleStorePurchaseRequest, GoogleStoreConfirmPendingPurchasesRequest, GoogleStoreRestoreRequest, GoogleStoreConnectionListener, 
//            GoogleStorePurchaseNotification, GoogleStorePurchaseState, GoogleStoreNotification, GoogleStoreFetchPendingPurchasesRequest, 
//            GoogleStoreResponseCode

public class GoogleStore extends Store
{
    private class GoogleStoreConnectionEventHandler
        implements GoogleStoreConnectionListener
    {

        private GoogleStore fStore;
        final GoogleStore this$0;

        public void onConnectionClosed()
        {
        }

        public void onConnectionLost()
        {
            if (fStore.isEnabled() && fStore.fConnection != null)
            {
                Log.v("Corona", "The connection to the Google Marketplace was lost unexpectedly. Attempting to restore the connection.");
                fStore.fConnection.open();
            }
        }

        public void onConnectionOpened()
        {
            fStore.sendRequests();
        }

        public void onReceivedNotification(GoogleStoreNotification googlestorenotification)
        {
            if (googlestorenotification == null)
            {
                return;
            }
            if (googlestorenotification instanceof GoogleStorePurchaseNotification)
            {
                GoogleStorePurchaseNotification googlestorepurchasenotification = (GoogleStorePurchaseNotification)googlestorenotification;
                StoreTransactionErrorType storetransactionerrortype = StoreTransactionErrorType.NONE;
                if (googlestorepurchasenotification.getPurchaseState() == GoogleStorePurchaseState.CANCELED)
                {
                    storetransactionerrortype = StoreTransactionErrorType.PAYMENT_CANCELED;
                }
                StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
                storetransactionresultsettings.setState(googlestorepurchasenotification.getPurchaseState().toTransactionState());
                storetransactionresultsettings.setErrorType(storetransactionerrortype);
                storetransactionresultsettings.setProductName(googlestorepurchasenotification.getProductStringId());
                storetransactionresultsettings.setReceipt(googlestorepurchasenotification.getSignedData());
                storetransactionresultsettings.setSignature(googlestorepurchasenotification.getSignature());
                storetransactionresultsettings.setTransactionStringId(googlestorepurchasenotification.getNotificationStringId());
                storetransactionresultsettings.setTransactionTime(googlestorepurchasenotification.getPurchaseTime());
                raiseTransactionEventFor(storetransactionresultsettings);
                return;
            } else
            {
                ArrayList arraylist = new ArrayList(1);
                arraylist.add(googlestorenotification.getNotificationStringId());
                GoogleStore _tmp = fStore;
                GoogleStoreFetchPendingPurchasesRequest googlestorefetchpendingpurchasesrequest = new GoogleStoreFetchPendingPurchasesRequest(GoogleStore.sRandomNumberGenerator.nextLong(), arraylist);
                fStore.fRequestQueue.add(googlestorefetchpendingpurchasesrequest);
                fStore.sendRequests();
                return;
            }
        }

        public void onReceivedResponse(long l, GoogleStoreResponseCode googlestoreresponsecode)
        {
            if (googlestoreresponsecode != null)
            {
                Long long1 = Long.valueOf(l);
                GoogleStoreRequest googlestorerequest = (GoogleStoreRequest)fStore.fSentRequests.get(long1);
                if (googlestorerequest != null)
                {
                    fStore.fSentRequests.remove(long1);
                    if (googlestoreresponsecode.isError())
                    {
                        StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
                        if (googlestoreresponsecode == GoogleStoreResponseCode.USER_CANCELED)
                        {
                            storetransactionresultsettings.setState(StoreTransactionState.CANCELED);
                        } else
                        {
                            storetransactionresultsettings.setState(StoreTransactionState.FAILED);
                        }
                        storetransactionresultsettings.setErrorType(googlestoreresponsecode.toTransactionErrorType());
                        if (googlestorerequest instanceof GoogleStorePurchaseRequest)
                        {
                            storetransactionresultsettings.setProductName(((GoogleStorePurchaseRequest)googlestorerequest).getProductName());
                        }
                        raiseTransactionEventFor(storetransactionresultsettings);
                        return;
                    }
                }
            }
        }

        public GoogleStoreConnectionEventHandler(GoogleStore googlestore1)
        {
            this$0 = GoogleStore.this;
            super();
            if (googlestore1 == null)
            {
                throw new NullPointerException();
            } else
            {
                fStore = googlestore1;
                return;
            }
        }
    }


    private static SecureRandom sRandomNumberGenerator = new SecureRandom();
    private GoogleStoreConnection fConnection;
    private boolean fHasPermission;
    private ArrayList fRequestQueue;
    private Hashtable fSentRequests;

    public GoogleStore()
    {
        fConnection = null;
        fRequestQueue = new ArrayList();
        fSentRequests = new Hashtable();
        fHasPermission = false;
        try
        {
            if (CoronaEnvironment.getApplicationContext().checkCallingOrSelfPermission("com.android.vending.BILLING") == 0)
            {
                fHasPermission = true;
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    private void sendRequests()
    {
        if (!isDisabled()) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (fConnection != null && !fConnection.isOpen())
        {
            fConnection.open();
        }
_L5:
        GoogleStoreRequest googlestorerequest;
        GoogleStoreSendRequestResult googlestoresendrequestresult;
        while (fRequestQueue.size() > 0 && !isDisabled() && fConnection != null && fConnection.isOpen()) 
        {
            googlestorerequest = (GoogleStoreRequest)fRequestQueue.get(0);
            googlestoresendrequestresult = fConnection.send(googlestorerequest);
            if (googlestoresendrequestresult == null || !googlestoresendrequestresult.wasSuccessful())
            {
                continue; /* Loop/switch isn't completed */
            }
            fRequestQueue.remove(0);
            fSentRequests.put(Long.valueOf(googlestoresendrequestresult.getRequestId()), googlestorerequest);
        }
        if (true) goto _L1; else goto _L3
_L3:
        if (googlestoresendrequestresult != null && googlestoresendrequestresult.getError() != GoogleStoreRequestError.INVALID_REQUEST && googlestoresendrequestresult.getError() != GoogleStoreRequestError.MARKETPLACE_ERROR) goto _L1; else goto _L4
_L4:
        fRequestQueue.remove(0);
        StoreTransactionResultSettings storetransactionresultsettings = new StoreTransactionResultSettings();
        storetransactionresultsettings.setState(StoreTransactionState.FAILED);
        storetransactionresultsettings.setErrorType(StoreTransactionErrorType.CLIENT_INVALID);
        if (googlestorerequest instanceof GoogleStorePurchaseRequest)
        {
            storetransactionresultsettings.setProductName(((GoogleStorePurchaseRequest)googlestorerequest).getProductName());
        }
        if (googlestoresendrequestresult != null)
        {
            if (googlestoresendrequestresult.getError() == GoogleStoreRequestError.INVALID_REQUEST)
            {
                storetransactionresultsettings.setErrorMessage("The request was invalid.");
            } else
            if (googlestoresendrequestresult.getError() == GoogleStoreRequestError.MARKETPLACE_ERROR)
            {
                storetransactionresultsettings.setErrorMessage("The Android Marketplace app has not been properly configured with an account.");
            }
        }
        raiseTransactionEventFor(storetransactionresultsettings);
          goto _L5
    }

    public boolean canMakePurchases()
    {
        return fHasPermission;
    }

    public void confirmTransaction(String s)
    {
        if (isDisabled())
        {
            return;
        } else
        {
            long l = sRandomNumberGenerator.nextLong();
            ArrayList arraylist = new ArrayList(1);
            arraylist.add(s);
            GoogleStoreConfirmPendingPurchasesRequest googlestoreconfirmpendingpurchasesrequest = new GoogleStoreConfirmPendingPurchasesRequest(l, arraylist);
            fRequestQueue.add(googlestoreconfirmpendingpurchasesrequest);
            sendRequests();
            return;
        }
    }

    protected void onDisabled()
    {
        if (fConnection == null)
        {
            return;
        } else
        {
            fConnection.setListener(null);
            fConnection.close();
            fConnection = null;
            return;
        }
    }

    protected void onEnabled()
    {
        if (fConnection != null)
        {
            onDisabled();
        }
        fConnection = new GoogleStoreConnection(getActivity());
        fConnection.setListener(new GoogleStoreConnectionEventHandler(this));
        fConnection.open();
    }

    public void purchase(String s)
    {
        while (isDisabled() || s == null || s.length() <= 0) 
        {
            return;
        }
        GoogleStorePurchaseRequest googlestorepurchaserequest = new GoogleStorePurchaseRequest(s);
        fRequestQueue.add(googlestorepurchaserequest);
        sendRequests();
    }

    public void restorePurchases()
    {
        if (isDisabled())
        {
            return;
        } else
        {
            GoogleStoreRestoreRequest googlestorerestorerequest = new GoogleStoreRestoreRequest(sRandomNumberGenerator.nextLong());
            fRequestQueue.add(googlestorerestorerequest);
            sendRequests();
            return;
        }
    }






}
