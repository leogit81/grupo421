// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreConnection

public static abstract class attachInterface extends Binder
    implements attachInterface
{
    private static class Proxy
        implements GoogleStoreConnection.IMarketBillingService
    {

        private IBinder mRemote;

        public IBinder asBinder()
        {
            return mRemote;
        }

        public String getInterfaceDescriptor()
        {
            return "com.android.vending.billing.IMarketBillingService";
        }

        public Bundle sendBillingRequest(Bundle bundle)
            throws RemoteException
        {
            Parcel parcel;
            Parcel parcel1;
            parcel = Parcel.obtain();
            parcel1 = Parcel.obtain();
            parcel.writeInterfaceToken("com.android.vending.billing.IMarketBillingService");
            if (bundle == null) goto _L2; else goto _L1
_L1:
            parcel.writeInt(1);
            bundle.writeToParcel(parcel, 0);
_L3:
            Bundle bundle1;
            mRemote.transact(1, parcel, parcel1, 0);
            parcel1.readException();
            if (parcel1.readInt() == 0)
            {
                break MISSING_BLOCK_LABEL_100;
            }
            bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(parcel1);
_L4:
            parcel1.recycle();
            parcel.recycle();
            return bundle1;
_L2:
            parcel.writeInt(0);
              goto _L3
            Exception exception;
            exception;
            parcel1.recycle();
            parcel.recycle();
            throw exception;
            bundle1 = null;
              goto _L4
        }

        public Proxy(IBinder ibinder)
        {
            mRemote = ibinder;
        }
    }


    private static final String DESCRIPTOR = "com.android.vending.billing.IMarketBillingService";
    static final int TRANSACTION_sendBillingRequest = 1;

    public static Proxy.mRemote asInterface(IBinder ibinder)
    {
        if (ibinder == null)
        {
            return null;
        }
        android.os.IInterface iinterface = ibinder.queryLocalInterface("com.android.vending.billing.IMarketBillingService");
        if (iinterface != null && (iinterface instanceof Proxy.mRemote))
        {
            return (Proxy.mRemote)iinterface;
        } else
        {
            return new Proxy(ibinder);
        }
    }

    public IBinder asBinder()
    {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
        throws RemoteException
    {
        int k;
        Bundle bundle;
        switch (i)
        {
        default:
            return super.onTransact(i, parcel, parcel1, j);

        case 1598968902: 
            parcel1.writeString("com.android.vending.billing.IMarketBillingService");
            return true;

        case 1: // '\001'
            parcel.enforceInterface("com.android.vending.billing.IMarketBillingService");
            k = parcel.readInt();
            bundle = null;
            break;
        }
        if (k != 0)
        {
            bundle = (Bundle)Bundle.CREATOR.Stub(parcel);
        }
        Bundle bundle1 = sendBillingRequest(bundle);
        parcel1.writeNoException();
        if (bundle1 != null)
        {
            parcel1.writeInt(1);
            bundle1.writeToParcel(parcel1, 1);
            return true;
        } else
        {
            parcel1.writeInt(0);
            return true;
        }
    }

    public Proxy.mRemote()
    {
        attachInterface(this, "com.android.vending.billing.IMarketBillingService");
    }
}
