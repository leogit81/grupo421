// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import java.lang.reflect.Field;

public class StoreTransactionState
{

    public static final StoreTransactionState CANCELED = new StoreTransactionState(5);
    public static final StoreTransactionState FAILED = new StoreTransactionState(3);
    public static final StoreTransactionState PURCHASED = new StoreTransactionState(2);
    public static final StoreTransactionState PURCHASING = new StoreTransactionState(1);
    public static final StoreTransactionState REFUNDED = new StoreTransactionState(6);
    public static final StoreTransactionState RESTORED = new StoreTransactionState(4);
    public static final StoreTransactionState UNDEFINED = new StoreTransactionState(0);
    private int fStateId;

    private StoreTransactionState(int i)
    {
        fStateId = i;
    }

    public static StoreTransactionState fromValue(int i)
    {
        Field afield[];
        int j;
        int k;
        Field field;
        StoreTransactionState storetransactionstate;
        int l;
        try
        {
            afield = com/ansca/corona/purchasing/StoreTransactionState.getDeclaredFields();
            j = afield.length;
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        k = 0;
_L2:
        if (k >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        field = afield[k];
        if (!field.getType().equals(com/ansca/corona/purchasing/StoreTransactionState))
        {
            break MISSING_BLOCK_LABEL_64;
        }
        storetransactionstate = (StoreTransactionState)field.get(null);
        l = storetransactionstate.toValue();
        if (l == i)
        {
            return storetransactionstate;
        }
        k++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
        return UNDEFINED;
    }

    public int toValue()
    {
        return fStateId;
    }

}
