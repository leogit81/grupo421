// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.os.Bundle;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreRequest

public class GoogleStoreRestoreRequest extends GoogleStoreRequest
{

    private long fNonce;

    public GoogleStoreRestoreRequest(long l)
    {
        fNonce = l;
    }

    public long getNonce()
    {
        return fNonce;
    }

    public Bundle toBundle()
    {
        Bundle bundle = new Bundle();
        bundle.putString("BILLING_REQUEST", "RESTORE_TRANSACTIONS");
        bundle.putLong("NONCE", fNonce);
        return bundle;
    }
}
