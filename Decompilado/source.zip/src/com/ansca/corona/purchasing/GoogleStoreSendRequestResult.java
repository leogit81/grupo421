// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.os.Bundle;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreRequestError

public class GoogleStoreSendRequestResult
{

    private GoogleStoreRequestError fErrorType;
    private long fRequestId;

    protected GoogleStoreSendRequestResult(long l, GoogleStoreRequestError googlestorerequesterror)
    {
        if (googlestorerequesterror != null) goto _L2; else goto _L1
_L1:
        if (l >= 0L)
        {
            googlestorerequesterror = GoogleStoreRequestError.NONE;
        } else
        {
            googlestorerequesterror = GoogleStoreRequestError.INVALID_REQUEST;
        }
_L4:
        fRequestId = l;
        fErrorType = googlestorerequesterror;
        return;
_L2:
        if (googlestorerequesterror != GoogleStoreRequestError.NONE)
        {
            l = -1L;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static GoogleStoreSendRequestResult failedWith(GoogleStoreRequestError googlestorerequesterror)
    {
        return new GoogleStoreSendRequestResult(-1L, googlestorerequesterror);
    }

    public static GoogleStoreSendRequestResult from(Bundle bundle)
    {
        long l = -1L;
        if (bundle != null)
        {
            l = bundle.getLong("REQUEST_ID", -1L);
        }
        return fromRequestId(l);
    }

    public static GoogleStoreSendRequestResult fromRequestId(long l)
    {
        return new GoogleStoreSendRequestResult(l, GoogleStoreRequestError.NONE);
    }

    public GoogleStoreRequestError getError()
    {
        return fErrorType;
    }

    public long getRequestId()
    {
        return fRequestId;
    }

    public boolean hasFailed()
    {
        return !wasSuccessful();
    }

    public boolean wasSuccessful()
    {
        return fErrorType == GoogleStoreRequestError.NONE;
    }
}
