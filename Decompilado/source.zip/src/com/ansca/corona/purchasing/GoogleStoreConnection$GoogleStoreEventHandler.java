// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreBroadcastListener, GoogleStoreBroadcastReceiver, GoogleStoreConnection, GoogleStorePurchaseNotification, 
//            GoogleStoreConnectionListener, GoogleStoreNotification, GoogleStoreResponseCode

private class fConnection
    implements GoogleStoreBroadcastListener
{

    private GoogleStoreConnection fConnection;
    final GoogleStoreConnection this$0;

    public void dispose()
    {
        GoogleStoreBroadcastReceiver.removeListener(this);
    }

    public void onReceive(Context context, Intent intent)
    {
        if (context != null && intent != null) goto _L2; else goto _L1
_L1:
        String s;
        return;
_L2:
        if ((s = intent.getAction()) == null || s.length() <= 0)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!s.equals("com.android.vending.billing.PURCHASE_STATE_CHANGED")) goto _L4; else goto _L3
_L3:
        if (GoogleStoreConnection.access$000(fConnection) == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        String s1;
        String s2;
        JSONArray jsonarray;
        int j;
        GoogleStorePurchaseNotification googlestorepurchasenotification;
        try
        {
            s1 = intent.getStringExtra("inapp_signed_data");
            s2 = intent.getStringExtra("inapp_signature");
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
            return;
        }
        if (s1 == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (s1.length() <= 0)
        {
            continue; /* Loop/switch isn't completed */
        }
        jsonarray = (new JSONObject(s1)).optJSONArray("orders");
        if (jsonarray == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        j = 0;
_L5:
        if (j >= jsonarray.length())
        {
            continue; /* Loop/switch isn't completed */
        }
        googlestorepurchasenotification = GoogleStorePurchaseNotification.from(jsonarray.getJSONObject(j), s1, s2);
        if (googlestorepurchasenotification == null)
        {
            break MISSING_BLOCK_LABEL_142;
        }
        GoogleStoreConnection.access$000(fConnection).onReceivedNotification(googlestorepurchasenotification);
        j++;
        if (true) goto _L5; else goto _L4
_L4:
        if (!s.equals("com.android.vending.billing.IN_APP_NOTIFY"))
        {
            break; /* Loop/switch isn't completed */
        }
        if (GoogleStoreConnection.access$000(fConnection) != null)
        {
            GoogleStoreNotification googlestorenotification = GoogleStoreNotification.from(intent);
            if (googlestorenotification != null)
            {
                GoogleStoreConnection.access$000(fConnection).onReceivedNotification(googlestorenotification);
                return;
            }
        }
        if (true) goto _L1; else goto _L6
_L6:
        if (s.equals("com.android.vending.billing.RESPONSE_CODE"))
        {
            if (GoogleStoreConnection.access$000(fConnection) != null)
            {
                long l = intent.getLongExtra("request_id", -1L);
                int i = intent.getIntExtra("response_code", GoogleStoreResponseCode.ERROR.ordinal());
                GoogleStoreConnection.access$000(fConnection).onReceivedResponse(l, GoogleStoreResponseCode.fromOrdinal(i));
                return;
            }
        } else
        {
            Log.v("Corona", (new StringBuilder()).append("Received unkown action name '").append(s).append("' from the Android Marketplace.").toString());
            return;
        }
        if (true) goto _L1; else goto _L7
_L7:
    }

    public (GoogleStoreConnection googlestoreconnection1)
    {
        this$0 = GoogleStoreConnection.this;
        super();
        if (googlestoreconnection1 == null)
        {
            throw new NullPointerException();
        } else
        {
            fConnection = googlestoreconnection1;
            GoogleStoreBroadcastReceiver.addListener(this);
            return;
        }
    }
}
