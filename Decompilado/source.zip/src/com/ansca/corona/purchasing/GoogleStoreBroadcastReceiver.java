// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreBroadcastListener

public class GoogleStoreBroadcastReceiver extends BroadcastReceiver
{

    private static ArrayList sListeners = new ArrayList();

    public GoogleStoreBroadcastReceiver()
    {
    }

    public static void addListener(GoogleStoreBroadcastListener googlestorebroadcastlistener)
    {
        while (googlestorebroadcastlistener == null || sListeners.indexOf(googlestorebroadcastlistener) >= 0) 
        {
            return;
        }
        sListeners.add(googlestorebroadcastlistener);
    }

    public static void removeListener(GoogleStoreBroadcastListener googlestorebroadcastlistener)
    {
        if (googlestorebroadcastlistener == null)
        {
            return;
        } else
        {
            sListeners.remove(googlestorebroadcastlistener);
            return;
        }
    }

    public void onReceive(Context context, Intent intent)
    {
        Iterator iterator = sListeners.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            GoogleStoreBroadcastListener googlestorebroadcastlistener = (GoogleStoreBroadcastListener)iterator.next();
            if (googlestorebroadcastlistener != null)
            {
                googlestorebroadcastlistener.onReceive(context, intent);
            }
        } while (true);
    }

}
