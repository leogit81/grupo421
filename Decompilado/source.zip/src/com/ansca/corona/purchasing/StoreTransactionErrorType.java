// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import java.lang.reflect.Field;

public class StoreTransactionErrorType
{

    public static final StoreTransactionErrorType CLIENT_INVALID = new StoreTransactionErrorType(2);
    public static final StoreTransactionErrorType NONE = new StoreTransactionErrorType(0);
    public static final StoreTransactionErrorType PAYMENT_CANCELED = new StoreTransactionErrorType(3);
    public static final StoreTransactionErrorType PAYMENT_INVALID = new StoreTransactionErrorType(4);
    public static final StoreTransactionErrorType PAYMENT_NOT_ALLOWED = new StoreTransactionErrorType(5);
    public static final StoreTransactionErrorType UNKNOWN = new StoreTransactionErrorType(1);
    private int fNumericId;

    private StoreTransactionErrorType(int i)
    {
        fNumericId = i;
    }

    public static StoreTransactionErrorType fromValue(int i)
    {
        Field afield[];
        int j;
        int k;
        Field field;
        StoreTransactionErrorType storetransactionerrortype;
        int l;
        try
        {
            afield = com/ansca/corona/purchasing/StoreTransactionErrorType.getDeclaredFields();
            j = afield.length;
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        k = 0;
_L2:
        if (k >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        field = afield[k];
        if (!field.getType().equals(com/ansca/corona/purchasing/StoreTransactionErrorType))
        {
            break MISSING_BLOCK_LABEL_64;
        }
        storetransactionerrortype = (StoreTransactionErrorType)field.get(null);
        l = storetransactionerrortype.toValue();
        if (l == i)
        {
            return storetransactionerrortype;
        }
        k++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L1
_L1:
        return UNKNOWN;
    }

    public int toValue()
    {
        return fNumericId;
    }

}
