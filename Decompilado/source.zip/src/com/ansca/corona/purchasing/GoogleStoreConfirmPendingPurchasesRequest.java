// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.os.Bundle;
import java.util.Collection;
import java.util.Collections;

// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreRequest

public class GoogleStoreConfirmPendingPurchasesRequest extends GoogleStoreRequest
{

    private long fNonce;
    private Collection fNotificationStringIds;

    public GoogleStoreConfirmPendingPurchasesRequest(long l, Collection collection)
    {
        if (collection == null)
        {
            throw new NullPointerException();
        }
        if (collection.size() <= 0)
        {
            throw new IllegalArgumentException();
        } else
        {
            fNonce = l;
            fNotificationStringIds = Collections.unmodifiableCollection(collection);
            return;
        }
    }

    public long getNonce()
    {
        return fNonce;
    }

    public Iterable getNotificationStringIds()
    {
        return fNotificationStringIds;
    }

    public Bundle toBundle()
    {
        Bundle bundle = new Bundle();
        bundle.putString("BILLING_REQUEST", "CONFIRM_NOTIFICATIONS");
        bundle.putStringArray("NOTIFY_IDS", (String[])fNotificationStringIds.toArray(new String[0]));
        return bundle;
    }
}
