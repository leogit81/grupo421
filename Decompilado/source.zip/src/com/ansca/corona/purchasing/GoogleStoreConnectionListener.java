// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;


// Referenced classes of package com.ansca.corona.purchasing:
//            GoogleStoreNotification, GoogleStoreResponseCode

public interface GoogleStoreConnectionListener
{

    public abstract void onConnectionClosed();

    public abstract void onConnectionLost();

    public abstract void onConnectionOpened();

    public abstract void onReceivedNotification(GoogleStoreNotification googlestorenotification);

    public abstract void onReceivedResponse(long l, GoogleStoreResponseCode googlestoreresponsecode);
}
