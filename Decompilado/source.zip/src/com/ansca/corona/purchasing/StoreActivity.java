// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona.purchasing;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

public class StoreActivity extends Activity
{

    public static final String EXTRA_FULL_SCREEN = "full_screen";
    public static final String EXTRA_NOOK_APP_EAN = "nook_app_ean";
    private boolean fHasShownStore;

    public StoreActivity()
    {
    }

    public void finish()
    {
        super.finish();
        if ((0x10000 & getIntent().getFlags()) != 0)
        {
            overridePendingTransition(0, 0);
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        finish();
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if (getIntent().getStringExtra("nook_app_ean") == null)
        {
            finish();
            return;
        }
        byte byte0 = 1;
        if (android.os.Build.VERSION.SDK_INT >= 9)
        {
            byte0 = 7;
        }
        setRequestedOrientation(byte0);
        if (getIntent().getBooleanExtra("full_screen", false))
        {
            getWindow().addFlags(1024);
            getWindow().clearFlags(2048);
        } else
        {
            getWindow().addFlags(2048);
            getWindow().clearFlags(1024);
        }
        fHasShownStore = false;
    }

    protected void onResume()
    {
        super.onResume();
        if (!fHasShownStore)
        {
            fHasShownStore = true;
            Intent intent = new Intent();
            intent.setAction("com.bn.sdk.shop.details");
            intent.putExtra("product_details_ean", getIntent().getStringExtra("nook_app_ean"));
            startActivityForResult(intent, 1);
        }
    }
}
