// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.LuaType;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public abstract class CoronaData
    implements Cloneable, Serializable, Parcelable
{
    public static class Boolean extends Value
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        public static final Boolean FALSE = new Boolean(false);
        public static final Boolean TRUE = new Boolean(true);
        private boolean fValue;

        public static Boolean from(boolean flag)
        {
            if (flag)
            {
                return TRUE;
            } else
            {
                return FALSE;
            }
        }

        public boolean equals(boolean flag)
        {
            return fValue == flag;
        }

        public boolean getValue()
        {
            return fValue;
        }

        public Object getValueAsObject()
        {
            return java.lang.Boolean.valueOf(fValue);
        }

        public boolean pushTo(LuaState luastate)
        {
            luastate.pushBoolean(fValue);
            return true;
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "boolean");
            xmlserializer.attribute("", "value", java.lang.Boolean.toString(fValue));
            xmlserializer.endTag("", "boolean");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            int j;
            if (fValue)
            {
                j = 1;
            } else
            {
                j = 0;
            }
            parcel.writeByte((byte)j);
        }


        public Boolean(boolean flag)
        {
            fValue = flag;
        }
    }

    private static class Boolean.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public Boolean createFromParcel(Parcel parcel)
        {
            boolean flag;
            if (parcel.readByte() != 0)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            return Boolean.from(flag);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public Boolean[] newArray(int i)
        {
            return new Boolean[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private Boolean.ParcelableCreator()
        {
        }

    }

    public static class Double extends Value
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        private double fValue;

        public boolean equals(double d)
        {
            return fValue == d;
        }

        public double getValue()
        {
            return fValue;
        }

        public Object getValueAsObject()
        {
            return java.lang.Double.valueOf(fValue);
        }

        public boolean pushTo(LuaState luastate)
        {
            luastate.pushNumber(fValue);
            return true;
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "double");
            xmlserializer.attribute("", "value", java.lang.Double.toString(fValue));
            xmlserializer.endTag("", "double");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            parcel.writeDouble(fValue);
        }


        public Double(double d)
        {
            fValue = d;
        }
    }

    private static class Double.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public Double createFromParcel(Parcel parcel)
        {
            return new Double(parcel.readDouble());
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public Double[] newArray(int i)
        {
            return new Double[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private Double.ParcelableCreator()
        {
        }

    }

    public static class List extends CoronaData
        implements Iterable
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        private ArrayList fCollection;

        public static List from(JSONArray jsonarray)
            throws JSONException
        {
            List list;
            if (jsonarray == null)
            {
                list = null;
            } else
            {
                list = new List();
                int i = 0;
                while (i < jsonarray.length()) 
                {
                    list.add(CoronaData.from(jsonarray.get(i)));
                    i++;
                }
            }
            return list;
        }

        public void add(CoronaData coronadata)
        {
            if (coronadata == null)
            {
                return;
            } else
            {
                fCollection.add(coronadata);
                return;
            }
        }

        public void clear()
        {
            fCollection.clear();
        }

        public List clone()
        {
            List list = (List)clone();
            list.fCollection = new ArrayList();
            for (Iterator iterator1 = fCollection.iterator(); iterator1.hasNext(); list.add((CoronaData)iterator1.next())) { }
            return list;
        }

        public volatile CoronaData clone()
        {
            return clone();
        }

        public volatile Object clone()
            throws CloneNotSupportedException
        {
            return clone();
        }

        public Iterator iterator()
        {
            return fCollection.iterator();
        }

        public boolean pushTo(LuaState luastate)
        {
            int i = fCollection.size();
            if (i <= 0)
            {
                luastate.newTable();
            } else
            {
                luastate.newTable(i, 0);
                int j = luastate.getTop();
                int k = 0;
                while (k < i) 
                {
                    CoronaData coronadata = (CoronaData)fCollection.get(k);
                    if (coronadata != null && coronadata.pushTo(luastate))
                    {
                        luastate.rawSet(j, k + 1);
                    }
                    k++;
                }
            }
            return true;
        }

        public boolean remove(CoronaData coronadata)
        {
            if (coronadata == null)
            {
                return false;
            } else
            {
                return fCollection.remove(coronadata);
            }
        }

        public int size()
        {
            return fCollection.size();
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "list");
            Iterator iterator1 = fCollection.iterator();
            do
            {
                if (!iterator1.hasNext())
                {
                    break;
                }
                CoronaData coronadata = (CoronaData)iterator1.next();
                if (coronadata != null)
                {
                    coronadata.writeTo(xmlserializer);
                }
            } while (true);
            xmlserializer.endTag("", "list");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            parcel.writeInt(fCollection.size());
            Iterator iterator1 = fCollection.iterator();
            do
            {
                if (!iterator1.hasNext())
                {
                    break;
                }
                CoronaData coronadata = (CoronaData)iterator1.next();
                if (coronadata != null)
                {
                    parcel.writeParcelable(coronadata, i);
                }
            } while (true);
        }


        public List()
        {
            fCollection = new ArrayList();
        }
    }

    private static class List.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public List createFromParcel(Parcel parcel)
        {
            List list = new List();
            ClassLoader classloader = getClass().getClassLoader();
            int i = parcel.readInt();
            for (int j = 0; j < i; j++)
            {
                list.add((CoronaData)parcel.readParcelable(classloader));
            }

            return list;
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public List[] newArray(int i)
        {
            return new List[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private List.ParcelableCreator()
        {
        }

    }

    public static class Proxy extends CoronaData
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        private CoronaData fData;

        public Proxy clone()
        {
            return (Proxy)clone();
        }

        public volatile CoronaData clone()
        {
            return clone();
        }

        public volatile Object clone()
            throws CloneNotSupportedException
        {
            return clone();
        }

        public CoronaData getData()
        {
            return fData;
        }

        public boolean pushTo(LuaState luastate)
        {
            if (fData == null)
            {
                return false;
            } else
            {
                return fData.pushTo(luastate);
            }
        }

        public void setData(CoronaData coronadata)
        {
            fData = coronadata;
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "proxy");
            if (fData != null)
            {
                fData.writeTo(xmlserializer);
            }
            xmlserializer.endTag("", "proxy");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            int j;
            if (fData != null)
            {
                j = 1;
            } else
            {
                j = 0;
            }
            parcel.writeByte((byte)j);
            if (fData != null)
            {
                parcel.writeParcelable(fData, i);
            }
        }


        public Proxy()
        {
            this(null);
        }

        public Proxy(CoronaData coronadata)
        {
            fData = coronadata;
        }
    }

    private static class Proxy.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public Proxy createFromParcel(Parcel parcel)
        {
            Proxy proxy = new Proxy();
            if (parcel.readByte() != 0)
            {
                proxy.setData((CoronaData)parcel.readParcelable(getClass().getClassLoader()));
            }
            return proxy;
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public Proxy[] newArray(int i)
        {
            return new Proxy[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private Proxy.ParcelableCreator()
        {
        }

    }

    public static class String extends Value
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        public static final String EMPTY = new String("");
        private java.lang.String fValue;

        public java.lang.String getValue()
        {
            return fValue;
        }

        public Object getValueAsObject()
        {
            return fValue;
        }

        public boolean pushTo(LuaState luastate)
        {
            luastate.pushString(getValue());
            return true;
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "string");
            xmlserializer.text(fValue);
            xmlserializer.endTag("", "string");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            parcel.writeString(fValue);
        }


        public String(java.lang.String s)
        {
            if (s == null)
            {
                s = "";
            }
            fValue = s;
        }
    }

    private static class String.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public String createFromParcel(Parcel parcel)
        {
            return new String(parcel.readString());
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public String[] newArray(int i)
        {
            return new String[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private String.ParcelableCreator()
        {
        }

    }

    public static class Table extends CoronaData
        implements Map
    {

        public static final android.os.Parcelable.Creator CREATOR = new ParcelableCreator();
        private HashMap fHashMap;

        public static Table from(Bundle bundle)
        {
            Table table;
            if (bundle == null)
            {
                table = null;
            } else
            {
                table = new Table();
                Iterator iterator = bundle.keySet().iterator();
                while (iterator.hasNext()) 
                {
                    java.lang.String s = (java.lang.String)iterator.next();
                    table.put(new String(s), CoronaData.from(bundle.get(s)));
                }
            }
            return table;
        }

        public static Table from(JSONObject jsonobject)
            throws JSONException
        {
            if (jsonobject != null) goto _L2; else goto _L1
_L1:
            Table table = null;
_L4:
            return table;
_L2:
            table = new Table();
            Iterator iterator = jsonobject.keys();
            if (iterator != null)
            {
                while (iterator.hasNext()) 
                {
                    java.lang.String s = (java.lang.String)iterator.next();
                    table.put(new String(s), CoronaData.from(jsonobject.get(s)));
                }
            }
            if (true) goto _L4; else goto _L3
_L3:
        }

        public void clear()
        {
            fHashMap.clear();
        }

        public Table clone()
        {
            Table table = (Table)clone();
            table.fHashMap = new HashMap();
            Iterator iterator = entrySet().iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                if (entry.getKey() != null)
                {
                    Value value = (Value)((Value)entry.getKey()).clone();
                    CoronaData coronadata = (CoronaData)entry.getValue();
                    if (coronadata != null)
                    {
                        coronadata = coronadata.clone();
                    }
                    table.put(value, coronadata);
                }
            } while (true);
            return table;
        }

        public volatile CoronaData clone()
        {
            return clone();
        }

        public volatile Object clone()
            throws CloneNotSupportedException
        {
            return clone();
        }

        public boolean containsKey(Object obj)
        {
            if (obj == null)
            {
                return false;
            } else
            {
                return fHashMap.containsKey(obj);
            }
        }

        public boolean containsValue(Object obj)
        {
            return fHashMap.containsValue(obj);
        }

        public Set entrySet()
        {
            return fHashMap.entrySet();
        }

        public boolean equals(Object obj)
        {
            if (!(obj instanceof Table))
            {
                return false;
            } else
            {
                return fHashMap.equals(((Table)obj).fHashMap);
            }
        }

        public CoronaData get(Object obj)
        {
            if (obj == null)
            {
                return null;
            } else
            {
                return (CoronaData)fHashMap.get(obj);
            }
        }

        public volatile Object get(Object obj)
        {
            return get(obj);
        }

        public int hashCode()
        {
            return fHashMap.hashCode();
        }

        public boolean isEmpty()
        {
            return fHashMap.isEmpty();
        }

        public Set keySet()
        {
            return fHashMap.keySet();
        }

        public boolean pushTo(LuaState luastate)
        {
            int i = fHashMap.size();
            if (i <= 0)
            {
                luastate.newTable();
            } else
            {
                luastate.newTable(0, i);
                int j = luastate.getTop();
                Iterator iterator = entrySet().iterator();
                while (iterator.hasNext()) 
                {
                    java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                    if (entry.getKey() != null && entry.getValue() != null)
                    {
                        ((Value)entry.getKey()).pushTo(luastate);
                        ((CoronaData)entry.getValue()).pushTo(luastate);
                        luastate.rawSet(j);
                    }
                }
            }
            return true;
        }

        public CoronaData put(Value value, CoronaData coronadata)
        {
            if (value == null)
            {
                return null;
            } else
            {
                return (CoronaData)fHashMap.put(value, coronadata);
            }
        }

        public volatile Object put(Object obj, Object obj1)
        {
            return put((Value)obj, (CoronaData)obj1);
        }

        public void putAll(Map map)
        {
            if (map != null)
            {
                fHashMap.putAll(map);
            }
        }

        public CoronaData remove(Object obj)
        {
            if (obj == null)
            {
                return null;
            } else
            {
                return (CoronaData)fHashMap.remove(obj);
            }
        }

        public volatile Object remove(Object obj)
        {
            return remove(obj);
        }

        public int size()
        {
            return fHashMap.size();
        }

        public Collection values()
        {
            return fHashMap.values();
        }

        public void writeTo(XmlSerializer xmlserializer)
            throws IOException
        {
            xmlserializer.startTag("", "table");
            Iterator iterator = entrySet().iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                if (entry.getKey() != null && entry.getValue() != null)
                {
                    xmlserializer.startTag("", "entry");
                    xmlserializer.startTag("", "key");
                    ((Value)entry.getKey()).writeTo(xmlserializer);
                    xmlserializer.endTag("", "key");
                    xmlserializer.startTag("", "value");
                    ((CoronaData)entry.getValue()).writeTo(xmlserializer);
                    xmlserializer.endTag("", "value");
                    xmlserializer.endTag("", "entry");
                }
            } while (true);
            xmlserializer.endTag("", "table");
        }

        public void writeToParcel(Parcel parcel, int i)
        {
            parcel.writeInt(size());
            Iterator iterator = entrySet().iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break;
                }
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                if (entry != null && entry.getKey() != null)
                {
                    parcel.writeParcelable((Parcelable)entry.getKey(), i);
                    boolean flag;
                    int j;
                    if (entry.getValue() != null)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (flag)
                    {
                        j = 1;
                    } else
                    {
                        j = 0;
                    }
                    parcel.writeByte((byte)j);
                    if (flag)
                    {
                        parcel.writeParcelable((Parcelable)entry.getValue(), i);
                    }
                }
            } while (true);
        }


        public Table()
        {
            fHashMap = new HashMap();
        }
    }

    private static class Table.ParcelableCreator
        implements android.os.Parcelable.Creator
    {

        public Table createFromParcel(Parcel parcel)
        {
            Table table = new Table();
            ClassLoader classloader = getClass().getClassLoader();
            int i = parcel.readInt();
            for (int j = 0; j < i; j++)
            {
                Value value = (Value)parcel.readParcelable(classloader);
                byte byte0 = parcel.readByte();
                CoronaData coronadata = null;
                if (byte0 != 0)
                {
                    coronadata = (CoronaData)parcel.readParcelable(classloader);
                }
                table.put(value, coronadata);
            }

            return table;
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public Table[] newArray(int i)
        {
            return new Table[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

        private Table.ParcelableCreator()
        {
        }

    }

    public static abstract class Value extends CoronaData
    {

        public volatile Object clone()
            throws CloneNotSupportedException
        {
            return clone();
        }

        public boolean equals(Object obj)
        {
            if (obj instanceof Value)
            {
                Object obj1 = getValueAsObject();
                Object obj2 = ((Value)obj).getValueAsObject();
                if (obj1 == obj2)
                {
                    return true;
                }
                if (obj1 != null)
                {
                    return obj1.equals(obj2);
                }
            }
            return false;
        }

        public abstract Object getValueAsObject();

        public int hashCode()
        {
            Object obj = getValueAsObject();
            if (obj == null)
            {
                return 0;
            } else
            {
                return obj.hashCode();
            }
        }

        public Value()
        {
        }
    }


    public CoronaData()
    {
    }

    public static CoronaData from(LuaState luastate, int i)
    {
        if (luastate != null)
        {
            LuaType luatype = luastate.type(i);
            if (luatype == LuaType.BOOLEAN)
            {
                return Boolean.from(luastate.toBoolean(i));
            }
            if (luatype == LuaType.NUMBER)
            {
                return new Double(luastate.toNumber(i));
            }
            if (luatype == LuaType.STRING)
            {
                return new String(luastate.toString(i));
            }
            if (luatype == LuaType.TABLE)
            {
                if (i < 0)
                {
                    i = luastate.getTop() + (i + 1);
                }
                Table table = new Table();
                luastate.pushNil();
                while (luastate.next(i)) 
                {
                    CoronaData coronadata = from(luastate, -2);
                    if (coronadata instanceof Value)
                    {
                        CoronaData coronadata1 = from(luastate, -1);
                        table.put((Value)coronadata, coronadata1);
                    }
                    luastate.pop(1);
                }
                return table;
            }
        }
        return null;
    }

    public static CoronaData from(Object obj)
    {
        if (obj == null)
        {
            return null;
        }
        if (obj instanceof CoronaData)
        {
            return (CoronaData)obj;
        }
        if (!(obj instanceof java.lang.Boolean)) goto _L2; else goto _L1
_L1:
        Object obj1 = Boolean.from(((java.lang.Boolean)obj).booleanValue());
_L4:
        return ((CoronaData) (obj1));
_L2:
        if (obj instanceof Number)
        {
            obj1 = new Double(((Number)obj).doubleValue());
            continue; /* Loop/switch isn't completed */
        }
        if ((obj instanceof Character) || (obj instanceof CharSequence))
        {
            obj1 = new String(obj.toString());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof File)
        {
            obj1 = new String(((File)obj).getAbsolutePath());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Uri)
        {
            obj1 = new String(obj.toString());
            continue; /* Loop/switch isn't completed */
        }
        if (obj instanceof Bundle)
        {
            obj1 = Table.from((Bundle)obj);
            continue; /* Loop/switch isn't completed */
        }
        if (!(obj instanceof JSONArray))
        {
            break MISSING_BLOCK_LABEL_203;
        }
        List list2 = List.from((JSONArray)obj);
        obj1 = list2;
        continue; /* Loop/switch isn't completed */
        Exception exception2;
        exception2;
        String s1 = new String(((JSONArray)obj).toString());
        obj1 = s1;
        continue; /* Loop/switch isn't completed */
        if (obj instanceof JSONObject)
        {
            Table table1;
            try
            {
                table1 = Table.from((JSONObject)obj);
            }
            catch (Exception exception)
            {
                List list;
                int i;
                int j;
                Table table;
                Iterator iterator;
                java.util.Map.Entry entry;
                CoronaData coronadata;
                boolean flag;
                List list1;
                Iterator iterator1;
                String s;
                try
                {
                    s = new String(((JSONObject)obj).toString());
                }
                catch (Exception exception1)
                {
                    obj1 = null;
                    continue; /* Loop/switch isn't completed */
                }
                obj1 = s;
                continue; /* Loop/switch isn't completed */
            }
            obj1 = table1;
            continue; /* Loop/switch isn't completed */
        } else
        {
            if (obj.getClass().isArray())
            {
                list = new List();
                i = Array.getLength(obj);
                for (j = 0; j < i; j++)
                {
                    list.add(from(Array.get(obj, j)));
                }

                obj1 = list;
            } else
            if (obj instanceof Map)
            {
                table = new Table();
                iterator = ((Map)obj).entrySet().iterator();
                do
                {
                    if (!iterator.hasNext())
                    {
                        break;
                    }
                    entry = (java.util.Map.Entry)iterator.next();
                    coronadata = from(entry.getKey());
                    if (coronadata instanceof Value)
                    {
                        table.put((Value)coronadata, from(entry.getValue()));
                    }
                } while (true);
                obj1 = table;
            } else
            {
                flag = obj instanceof Iterable;
                obj1 = null;
                if (flag)
                {
                    list1 = new List();
                    for (iterator1 = ((Iterable)obj).iterator(); iterator1.hasNext(); list1.add(from(iterator1.next()))) { }
                    obj1 = list1;
                }
            }
            continue; /* Loop/switch isn't completed */
        }
        Exception exception3;
        exception3;
        obj1 = null;
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static CoronaData from(XmlPullParser xmlpullparser)
        throws IOException, XmlPullParserException
    {
        Object obj = null;
        if (xmlpullparser != null) goto _L2; else goto _L1
_L1:
        return ((CoronaData) (obj));
_L2:
        java.lang.String s;
        int i = xmlpullparser.nextTag();
        obj = null;
        if (i != 2)
        {
            continue; /* Loop/switch isn't completed */
        }
        s = xmlpullparser.getName();
        obj = null;
        if (s == null)
        {
            continue; /* Loop/switch isn't completed */
        }
        int j = s.length();
        obj = null;
        if (j <= 0)
        {
            continue; /* Loop/switch isn't completed */
        }
        if (!"boolean".equals(s))
        {
            break; /* Loop/switch isn't completed */
        }
        obj = Boolean.from(java.lang.Boolean.parseBoolean(xmlpullparser.getAttributeValue("", "value")));
_L4:
        while (xmlpullparser.getEventType() != 3 || !s.equals(xmlpullparser.getName())) 
        {
            xmlpullparser.nextTag();
        }
        if (true) goto _L1; else goto _L3
_L3:
        if ("double".equals(s))
        {
            obj = new Double(java.lang.Double.parseDouble(xmlpullparser.getAttributeValue("", "value")));
        } else
        if ("string".equals(s))
        {
            obj = String.EMPTY;
            if (xmlpullparser.next() == 4)
            {
                java.lang.String s1 = xmlpullparser.getText();
                if (s1 != null)
                {
                    obj = new String(s1);
                }
            }
        } else
        if ("proxy".equals(s))
        {
            obj = new Proxy(from(xmlpullparser));
        } else
        if ("list".equals(s))
        {
            List list = new List();
            CoronaData coronadata;
            do
            {
                coronadata = from(xmlpullparser);
                list.add(coronadata);
            } while (coronadata != null);
            obj = list;
        } else
        {
            boolean flag = "table".equals(s);
            obj = null;
            if (flag)
            {
                Table table = new Table();
                int k;
                do
                {
                    do
                    {
                        k = xmlpullparser.nextTag();
                        if (k != 2 || !"entry".equals(xmlpullparser.getName()))
                        {
                            break;
                        }
                        Value value = null;
                        CoronaData coronadata1 = null;
                        int l;
                        do
                        {
                            do
                            {
                                l = xmlpullparser.nextTag();
                                if (l != 2)
                                {
                                    break;
                                }
                                if ("key".equals(xmlpullparser.getName()))
                                {
                                    CoronaData coronadata2 = from(xmlpullparser);
                                    if (coronadata2 instanceof Value)
                                    {
                                        value = (Value)coronadata2;
                                    }
                                } else
                                if ("value".equals(xmlpullparser.getName()))
                                {
                                    coronadata1 = from(xmlpullparser);
                                }
                            } while (true);
                        } while (l != 3 || !"entry".equals(xmlpullparser.getName()));
                        if (value != null && coronadata1 != null)
                        {
                            table.put(value, coronadata1);
                        }
                    } while (true);
                } while (k != 3 || !"table".equals(xmlpullparser.getName()));
                obj = table;
            }
        }
          goto _L4
        if (true) goto _L1; else goto _L5
_L5:
    }

    public CoronaData clone()
    {
        CoronaData coronadata;
        try
        {
            coronadata = (CoronaData)super.clone();
        }
        catch (Exception exception)
        {
            return null;
        }
        return coronadata;
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public int describeContents()
    {
        return 0;
    }

    public abstract boolean pushTo(LuaState luastate);

    public abstract void writeTo(XmlSerializer xmlserializer)
        throws IOException;
}
