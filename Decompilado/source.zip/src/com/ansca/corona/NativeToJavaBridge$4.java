// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            NativeToJavaBridge, Controller, CoronaActivity

static final class val.mode
    implements Runnable
{

    final int val$mode;

    public void run()
    {
        this;
        JVM INSTR monitorenter ;
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity == null)
        {
            break MISSING_BLOCK_LABEL_18;
        }
        coronaactivity.setStatusBarMode(val$mode);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    (int i)
    {
        val$mode = i;
        super();
    }
}
