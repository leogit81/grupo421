// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.AlertDialog;
import android.content.DialogInterface;

// Referenced classes of package com.ansca.corona:
//            CoronaLuaErrorHandler, CoronaEnvironment

class val.errorMessage
    implements Runnable
{

    final CoronaLuaErrorHandler this$0;
    final String val$errorMessage;
    final RuntimeException val$exception;

    public void run()
    {
        CoronaActivity coronaactivity = CoronaEnvironment.getCoronaActivity();
        if (coronaactivity == null)
        {
            throw val$exception;
        } else
        {
            android.content.Listener listener = new android.content.DialogInterface.OnCancelListener() {

                final CoronaLuaErrorHandler._cls2 this$1;

                public void onCancel(DialogInterface dialoginterface)
                {
                    throw exception;
                }

            
            {
                this$1 = CoronaLuaErrorHandler._cls2.this;
                super();
            }
            };
            android.app.ncelListener ncellistener = new android.app.t>(coronaactivity);
            ncellistener.itle("Runtime Error");
            ncellistener.essage(val$errorMessage);
            ncellistener.nCancelListener(listener);
            AlertDialog alertdialog = ncellistener.te();
            alertdialog.setCanceledOnTouchOutside(false);
            alertdialog.show();
            return;
        }
    }

    _cls1.this._cls1()
    {
        this$0 = final_coronaluaerrorhandler;
        val$exception = runtimeexception;
        val$errorMessage = String.this;
        super();
    }
}
