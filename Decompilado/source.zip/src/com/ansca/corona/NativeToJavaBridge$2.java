// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            NativeToJavaBridge, Controller, CoronaActivity

static final class 
    implements Runnable
{

    public void run()
    {
        CoronaActivity coronaactivity = Controller.getActivity();
        if (coronaactivity != null)
        {
            coronaactivity.moveTaskToBack(true);
        }
    }

    ()
    {
    }
}
