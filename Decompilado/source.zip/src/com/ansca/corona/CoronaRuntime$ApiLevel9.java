// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.content.Context;
import android.content.pm.ApplicationInfo;

// Referenced classes of package com.ansca.corona:
//            CoronaRuntime

private static class 
{

    public static String getNativeLibraryDirectoryFrom(Context context)
    {
        if (context == null)
        {
            throw new NullPointerException();
        } else
        {
            return context.getApplicationInfo().nativeLibraryDir;
        }
    }

    private ()
    {
    }
}
