// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;

// Referenced classes of package com.ansca.corona:
//            CameraActivity, CameraView, CameraServices

class this._cls0
    implements android.view.ner
{

    final CameraActivity this$0;

    public void onClick(View view)
    {
        int i = (1 + CameraActivity.access$200(CameraActivity.this).getSelectedCameraIndex()) % CameraServices.getCameraCount();
        CameraActivity.access$200(CameraActivity.this).selectCameraByIndex(i);
    }

    ()
    {
        this$0 = CameraActivity.this;
        super();
    }
}
