// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            CoronaSensorManager, Controller

private class <init>
    implements LocationListener
{

    private boolean fHasReceivedData;
    private boolean fSupportsGps;
    private boolean fSupportsNetwork;
    final CoronaSensorManager this$0;

    public void onLocationChanged(Location location)
    {
        if (location.getProvider().equals("gps") || !fHasReceivedData || !fSupportsGps || !CoronaSensorManager.access$900(CoronaSensorManager.this).isProviderEnabled("gps"))
        {
            fHasReceivedData = true;
            EventManager eventmanager = Controller.getEventManager();
            if (eventmanager != null)
            {
                eventmanager.locationEvent(location.getLatitude(), location.getLongitude(), location.getAltitude(), location.getAccuracy(), location.getSpeed(), location.getBearing(), (double)location.getTime() / 1000D);
                return;
            }
        }
    }

    public void onProviderDisabled(String s)
    {
    }

    public void onProviderEnabled(String s)
    {
    }

    public void onStatusChanged(String s, int i, Bundle bundle)
    {
    }

    public void setSupportsGps()
    {
        fSupportsGps = true;
    }

    public void setSupportsNetwork()
    {
        fSupportsNetwork = true;
    }

    private A()
    {
        this$0 = CoronaSensorManager.this;
        super();
        fHasReceivedData = false;
        fSupportsGps = false;
        fSupportsNetwork = false;
    }

    fSupportsNetwork(fSupportsNetwork fsupportsnetwork)
    {
        this();
    }
}
