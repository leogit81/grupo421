// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.ansca.corona.maps.MapView;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.view
    implements Runnable
{

    final ViewManager this$0;
    final View val$view;

    public void run()
    {
        android.view.ViewParent viewparent = val$view.getParent();
        if (viewparent != null && (viewparent instanceof ViewGroup))
        {
            ((ViewGroup)viewparent).removeView(val$view);
        }
        if (!(val$view instanceof WebView)) goto _L2; else goto _L1
_L1:
        ((WebView)val$view).stopLoading();
        ((WebView)val$view).destroy();
_L4:
        val$view.setId(0);
        return;
_L2:
        if (val$view instanceof MapView)
        {
            ((MapView)val$view).destroy();
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    ()
    {
        this$0 = final_viewmanager;
        val$view = View.this;
        super();
    }
}
