// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaWebView

class val.id
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;

    public void run()
    {
        CoronaWebView coronawebview = (CoronaWebView)getDisplayObjectById(com/ansca/corona/CoronaWebView, val$id);
        if (coronawebview != null)
        {
            coronawebview.stopLoading();
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = I.this;
        super();
    }
}
