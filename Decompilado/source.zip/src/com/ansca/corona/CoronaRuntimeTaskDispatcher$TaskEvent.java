// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import com.ansca.corona.events.Event;

// Referenced classes of package com.ansca.corona:
//            Controller, CoronaRuntime, CoronaRuntimeTask, CoronaRuntimeTaskDispatcher

private static class fTask extends Event
{

    private CoronaRuntimeTask fTask;

    public void Send()
    {
        CoronaRuntime coronaruntime;
        if (fTask != null && Controller.isValid())
        {
            if ((coronaruntime = Controller.getRuntime()) != null && !coronaruntime.wasDisposed())
            {
                fTask.executeUsing(coronaruntime);
                return;
            }
        }
    }

    public (CoronaRuntimeTask coronaruntimetask)
    {
        if (coronaruntimetask == null)
        {
            throw new NullPointerException();
        } else
        {
            fTask = coronaruntimetask;
            return;
        }
    }
}
