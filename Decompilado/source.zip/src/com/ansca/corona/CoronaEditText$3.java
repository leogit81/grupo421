// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.text.Editable;
import android.text.TextWatcher;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            CoronaEditText, Controller

class this._cls0
    implements TextWatcher
{

    final CoronaEditText this$0;

    public void afterTextChanged(Editable editable)
    {
        CoronaEditText.access$302(CoronaEditText.this, editable.toString());
        if (CoronaEditText.access$300(CoronaEditText.this) == null)
        {
            CoronaEditText.access$302(CoronaEditText.this, "");
        }
        if (CoronaEditText.access$000(CoronaEditText.this) && Controller.isValid() && getId() != 0)
        {
            String s = null;
            String s1 = null;
            if (editable != null)
            {
                s1 = CoronaEditText.access$300(CoronaEditText.this);
                s = editable.subSequence(CoronaEditText.access$400(CoronaEditText.this), CoronaEditText.access$400(CoronaEditText.this) + CoronaEditText.access$500(CoronaEditText.this)).toString();
            }
            Controller.getEventManager().textEditingEvent(getId(), CoronaEditText.access$400(CoronaEditText.this), CoronaEditText.access$200(CoronaEditText.this), s, CoronaEditText.access$100(CoronaEditText.this), s1);
        }
    }

    public void beforeTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        if (CoronaEditText.access$000(CoronaEditText.this))
        {
            CoronaEditText.access$102(CoronaEditText.this, new String(charsequence.toString()));
            CoronaEditText.access$202(CoronaEditText.this, j);
        }
    }

    public void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        if (CoronaEditText.access$000(CoronaEditText.this))
        {
            CoronaEditText.access$402(CoronaEditText.this, i);
            CoronaEditText.access$602(CoronaEditText.this, j);
            CoronaEditText.access$502(CoronaEditText.this, k);
        }
    }

    er()
    {
        this$0 = CoronaEditText.this;
        super();
    }
}
