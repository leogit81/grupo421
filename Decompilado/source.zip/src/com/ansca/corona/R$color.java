// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            R

public static final class 
{

    public static final int com_facebook_blue = 0x7f070000;
    public static final int com_facebook_loginview_text_color = 0x7f070004;
    public static final int com_facebook_usersettingsfragment_connected_shadow_color = 0x7f070002;
    public static final int com_facebook_usersettingsfragment_connected_text_color = 0x7f070001;
    public static final int com_facebook_usersettingsfragment_not_connected_text_color = 0x7f070003;

    public ()
    {
    }
}
