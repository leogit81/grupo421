// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.location.Address;
import android.location.Geocoder;
import com.naef.jnlua.LuaState;
import java.util.List;

// Referenced classes of package com.ansca.corona:
//            CoronaRuntimeTask, CoronaRuntime, CoronaLua, NativeToJavaBridge, 
//            CoronaEnvironment, CoronaRuntimeTaskDispatcher

class val.addressFinal
    implements CoronaRuntimeTask
{

    final l.functionListenerFinal this$0;
    final Address val$addressFinal;

    public void executeUsing(CoronaRuntime coronaruntime)
    {
        LuaState luastate = coronaruntime.getLuaState();
        CoronaLua.newEvent(luastate, "nearestAddress");
        if (val$addressFinal != null)
        {
            try
            {
                if (val$addressFinal.getThoroughfare() != null)
                {
                    luastate.pushString(val$addressFinal.getThoroughfare());
                    luastate.setField(-2, "street");
                }
                if (val$addressFinal.getSubThoroughfare() != null)
                {
                    luastate.pushString(val$addressFinal.getSubThoroughfare());
                    luastate.setField(-2, "streetDetail");
                }
                if (val$addressFinal.getLocality() != null)
                {
                    luastate.pushString(val$addressFinal.getLocality());
                    luastate.setField(-2, "city");
                }
                if (val$addressFinal.getSubLocality() != null)
                {
                    luastate.pushString(val$addressFinal.getSubLocality());
                    luastate.setField(-2, "cityDetail");
                }
                if (val$addressFinal.getAdminArea() != null)
                {
                    luastate.pushString(val$addressFinal.getAdminArea());
                    luastate.setField(-2, "region");
                }
                if (val$addressFinal.getSubAdminArea() != null)
                {
                    luastate.pushString(val$addressFinal.getSubAdminArea());
                    luastate.setField(-2, "regionDetail");
                }
                if (val$addressFinal.getPostalCode() != null)
                {
                    luastate.pushString(val$addressFinal.getPostalCode());
                    luastate.setField(-2, "postalCode");
                }
                if (val$addressFinal.getCountryName() != null)
                {
                    luastate.pushString(val$addressFinal.getCountryName());
                    luastate.setField(-2, "country");
                }
                if (val$addressFinal.getCountryCode() != null)
                {
                    luastate.pushString(val$addressFinal.getCountryCode());
                    luastate.setField(-2, "countryCode");
                }
                CoronaLua.dispatchEvent(luastate, functionListenerFinal, 0);
            }
            catch (Exception exception1)
            {
                exception1.printStackTrace();
            }
        } else
        {
            try
            {
                luastate.pushBoolean(true);
                luastate.setField(-2, "isError");
                CoronaLua.dispatchEvent(luastate, functionListenerFinal, 0);
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }
        CoronaLua.deleteRef(luastate, functionListenerFinal);
    }

    l.dispatcher()
    {
        this$0 = final_dispatcher;
        val$addressFinal = Address.this;
        super();
    }

    // Unreferenced inner class com/ansca/corona/NativeToJavaBridge$5

/* anonymous class */
    static final class NativeToJavaBridge._cls5
        implements Runnable
    {

        final CoronaRuntimeTaskDispatcher val$dispatcher;
        final int val$functionListenerFinal;
        final double val$latitudeFinal;
        final double val$longitudeFinal;

        public void run()
        {
            List list = (new Geocoder(CoronaEnvironment.getApplicationContext())).getFromLocation(latitudeFinal, longitudeFinal, 1);
            if (list == null) goto _L2; else goto _L1
_L1:
            if (list.size() <= 0) goto _L2; else goto _L3
_L3:
            Address address = (Address)list.get(0);
_L5:
            NativeToJavaBridge._cls5._cls1 _lcls1 = address. new NativeToJavaBridge._cls5._cls1();
            dispatcher.send(_lcls1);
            return;
_L2:
            address = null;
            continue; /* Loop/switch isn't completed */
            Exception exception;
            exception;
            exception.getMessage();
            address = null;
            if (true) goto _L5; else goto _L4
_L4:
        }

            
            {
                latitudeFinal = d;
                longitudeFinal = d1;
                functionListenerFinal = i;
                dispatcher = coronaruntimetaskdispatcher;
                super();
            }
    }

}
