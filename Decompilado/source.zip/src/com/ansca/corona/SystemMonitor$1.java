// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            SystemMonitor, Controller, JavaToNativeShim

class this._cls0
    implements Runnable
{

    final SystemMonitor this$0;

    public void run()
    {
        if (Controller.isValid())
        {
            JavaToNativeShim.memoryWarningEvent();
        }
    }

    ()
    {
        this$0 = SystemMonitor.this;
        super();
    }
}
