// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaEditText

class val.color
    implements Runnable
{

    final ViewManager this$0;
    final int val$color;
    final int val$id;

    public void run()
    {
        CoronaEditText coronaedittext = (CoronaEditText)getDisplayObjectById(com/ansca/corona/CoronaEditText, val$id);
        if (coronaedittext == null)
        {
            return;
        } else
        {
            coronaedittext.setTextViewColor(val$color);
            return;
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$color = I.this;
        super();
    }
}
