// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;


// Referenced classes of package com.ansca.corona:
//            ViewManager, CoronaVideoView

class val.time
    implements Runnable
{

    final ViewManager this$0;
    final int val$id;
    final int val$time;

    public void run()
    {
        CoronaVideoView coronavideoview = (CoronaVideoView)getDisplayObjectById(com/ansca/corona/CoronaVideoView, val$id);
        if (coronavideoview != null)
        {
            coronavideoview.seekTo(1000 * val$time);
        }
    }

    ()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$time = I.this;
        super();
    }
}
