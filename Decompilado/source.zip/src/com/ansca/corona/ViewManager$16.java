// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;
import android.view.animation.AlphaAnimation;
import android.webkit.WebView;
import com.ansca.corona.maps.MapView;

// Referenced classes of package com.ansca.corona:
//            ViewManager

class val.alpha
    implements Runnable
{

    final ViewManager this$0;
    final float val$alpha;
    final int val$id;

    public void run()
    {
        View view = getDisplayObjectById(val$id);
        if (view == null) goto _L2; else goto _L1
_L1:
        float f = val$alpha;
        if (f >= 0.0F) goto _L4; else goto _L3
_L3:
        f = 0.0F;
_L6:
        Object obj = view.getTag();
        if (obj instanceof ingObjectHashMap)
        {
            ((ingObjectHashMap)obj).put("alpha", Float.valueOf(f));
        }
        if (f >= 0.9999F || view.getVisibility() != 0)
        {
            break; /* Loop/switch isn't completed */
        }
        if ((view instanceof WebView) || (view instanceof MapView))
        {
            ViewManager.access$500(ViewManager.this, view, false);
        }
        AlphaAnimation alphaanimation = new AlphaAnimation(1.0F, f);
        alphaanimation.setDuration(0L);
        alphaanimation.setFillAfter(true);
        view.startAnimation(alphaanimation);
_L2:
        return;
_L4:
        if (f > 1.0F)
        {
            f = 1.0F;
        }
        if (true) goto _L6; else goto _L5
_L5:
        view.setAnimation(null);
        return;
    }

    ation()
    {
        this$0 = final_viewmanager;
        val$id = i;
        val$alpha = F.this;
        super();
    }
}
