// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import java.nio.ByteBuffer;

// Referenced classes of package com.ansca.corona:
//            AudioRecorder

public static class myBuffer
{

    ByteBuffer myBuffer;
    int myValidBytes;

    (int i)
    {
        myValidBytes = 0;
        myBuffer = ByteBuffer.allocateDirect(i);
    }
}
