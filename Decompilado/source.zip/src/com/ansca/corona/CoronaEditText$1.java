// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.view.View;
import com.ansca.corona.events.EventManager;

// Referenced classes of package com.ansca.corona:
//            CoronaEditText, Controller

class this._cls0
    implements android.view.eListener
{

    final CoronaEditText this$0;

    public void onFocusChange(View view, boolean flag)
    {
        if (Controller.isValid() && getId() != 0)
        {
            if (flag)
            {
                CoronaEditText.access$002(CoronaEditText.this, true);
            }
            Controller.getEventManager().textEvent(getId(), flag, false);
        }
    }

    er()
    {
        this$0 = CoronaEditText.this;
        super();
    }
}
