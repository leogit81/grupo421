// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.widget.ProgressBar;

public class ActivityIndicatorDialog extends Dialog
{

    private boolean fIsCancelable;

    public ActivityIndicatorDialog(Context context)
    {
        this(context, getDefaultDialogThemeId());
    }

    public ActivityIndicatorDialog(Context context, int i)
    {
        super(context, i);
        fIsCancelable = true;
        requestWindowFeature(1);
        ProgressBar progressbar = new ProgressBar(context);
        int j = progressbar.getIndeterminateDrawable().getMinimumWidth() / 2;
        int k = progressbar.getIndeterminateDrawable().getMinimumHeight() / 2;
        progressbar.setPadding(j, j, k, k);
        addContentView(progressbar, new android.view.ViewGroup.LayoutParams(-2, -2));
    }

    private static int getDefaultDialogThemeId()
    {
        return android.os.Build.VERSION.SDK_INT < 11 ? 0x103000b : 0x103006f;
    }

    public boolean isCancelable()
    {
        return fIsCancelable;
    }

    public boolean onKeyUp(int i, KeyEvent keyevent)
    {
        if (!fIsCancelable && i == 84)
        {
            return true;
        } else
        {
            return super.onKeyUp(i, keyevent);
        }
    }

    public void setCancelable(boolean flag)
    {
        fIsCancelable = flag;
        super.setCancelable(flag);
    }
}
