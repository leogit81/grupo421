// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ansca.corona;

import android.webkit.WebChromeClient;

// Referenced classes of package com.ansca.corona:
//            CoronaWebView

class nit> extends WebChromeClient
{

    final CoronaWebView this$0;

    public void onGeolocationPermissionsShowPrompt(String s, android.webkit.ssions.Callback callback)
    {
        if (callback != null)
        {
            callback.invoke(s, true, false);
        }
    }

    ions.Callback()
    {
        this$0 = CoronaWebView.this;
        super();
    }
}
